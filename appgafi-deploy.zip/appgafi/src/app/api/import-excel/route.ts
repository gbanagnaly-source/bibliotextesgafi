import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';

const EXPECTED_PASSWORD = 'Cleobule1980@';

// Mapping of compliance codes
function parseCompliance(value: string): { compliance: string; ratingCode: string } {
  const v = (value || '').toString().trim().toUpperCase();
  const map: Record<string, { compliance: string; ratingCode: string }> = {
    'C': { compliance: 'Conforme', ratingCode: 'C' },
    'CONFORME': { compliance: 'Conforme', ratingCode: 'C' },
    'LC': { compliance: 'Largement Conforme', ratingCode: 'LC' },
    'LARGEMENT CONFORME': { compliance: 'Largement Conforme', ratingCode: 'LC' },
    'PC': { compliance: 'Partiellement Conforme', ratingCode: 'PC' },
    'PARTIELLEMENT CONFORME': { compliance: 'Partiellement Conforme', ratingCode: 'PC' },
    'NC': { compliance: 'Non Conforme', ratingCode: 'NC' },
    'NON CONFORME': { compliance: 'Non Conforme', ratingCode: 'NC' },
    'N/A': { compliance: 'Non évalué', ratingCode: 'N/A' },
    'NA': { compliance: 'Non évalué', ratingCode: 'N/A' },
  };
  return map[v] || { compliance: 'Non évalué', ratingCode: 'N/A' };
}

// Mapping of effectiveness codes (IO columns use HE/SE/ME/LE)
function parseEffectiveness(value: string): { effectiveness: string; effectivenessCode: string } {
  const v = (value || '').toString().trim().toUpperCase();
  const map: Record<string, { effectiveness: string; effectivenessCode: string }> = {
    'HE': { effectiveness: 'Élevé', effectivenessCode: 'HE' },
    'ÉLEVÉ': { effectiveness: 'Élevé', effectivenessCode: 'HE' },
    'SE': { effectiveness: 'Significatif', effectivenessCode: 'SE' },
    'SIGNIFICATIF': { effectiveness: 'Significatif', effectivenessCode: 'SE' },
    'ME': { effectiveness: 'Modéré', effectivenessCode: 'ME' },
    'MODÉRÉ': { effectiveness: 'Modéré', effectivenessCode: 'ME' },
    'LE': { effectiveness: 'Faible', effectivenessCode: 'LE' },
    'FAIBLE': { effectiveness: 'Faible', effectivenessCode: 'LE' },
    'N/A': { effectiveness: 'Non évalué', effectivenessCode: 'N/A' },
  };
  return map[v] || { effectiveness: 'Non évalué', effectivenessCode: 'N/A' };
}

const COMPLIANCE_SCORE: Record<string, number> = { 'C': 100, 'LC': 75, 'PC': 50, 'NC': 0, 'N/A': 0 };
const EFFECTIVENESS_SCORE: Record<string, number> = { 'HE': 4, 'SE': 3, 'ME': 2, 'LE': 1, 'N/A': 0 };

function getGlobalRating(compPct: number, effPct: number): string {
  const avg = (compPct + effPct) / 2;
  if (avg >= 70) return 'Satisfaisant';
  if (avg >= 50) return 'Suffisant';
  if (avg >= 35) return 'Non Satisfaisant';
  return 'Insuffisant';
}

function parseDate(val: unknown): string | null {
  if (!val) return null;
  if (typeof val === 'number') {
    // Excel serial date
    const d = XLSX.SSF.parse_date_code(val);
    if (d) return `${d.y}-${String(d.m).padStart(2, '0')}`;
    return null;
  }
  const s = String(val).trim();
  const match = s.match(/(\d{4})[-/](\d{1,2})/);
  if (match) return `${match[1]}-${match[2].padStart(2, '0')}`;
  return s.slice(0, 7) || null;
}

function isFootnote(name: string): boolean {
  return name.startsWith('*');
}

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const password = formData.get('password') as string;
    const file = formData.get('file') as File;

    if (password !== EXPECTED_PASSWORD) {
      return NextResponse.json({ error: 'Mot de passe incorrect.' }, { status: 403 });
    }

    if (!file) {
      return NextResponse.json({ error: 'Aucun fichier fourni.' }, { status: 400 });
    }

    // Read and parse Excel
    const buffer = Buffer.from(await file.arrayBuffer());
    const workbook = XLSX.read(buffer, { type: 'buffer' });

    // Support both "Ratings only" (official FATF format) and "Données" (custom format)
    const sheetName = workbook.SheetNames.includes('Ratings only')
      ? 'Ratings only'
      : workbook.SheetNames.includes('Données')
        ? 'Données'
        : workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rawRows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });

    if (rawRows.length === 0) {
      return NextResponse.json({ error: 'Le fichier Excel est vide.' }, { status: 400 });
    }

    // Detect format: "Ratings only" has "Jurisdiction" column, "Données" has "Pays"
    const isOfficialFormat = rawRows.some(r => {
      const keys = Object.keys(r);
      return keys.some(k => String(k).includes('Jurisdiction'));
    });

    // Load existing data
    const dataPath = path.join(process.cwd(), 'src', 'data', 'gafi-data.json');
    const existingData = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
    const countriesMap = new Map(existingData.countries.map((c: any) => [c.countryName, c]));

    // Collect all rows per country with their evaluations
    interface EvalRow {
      date: string;
      reportType: string;
      body: string;
      ios: string[];   // IO1-IO11 codes
      recs: string[];  // R.1-R.40 codes
    }
    const countryEvals = new Map<string, EvalRow[]>();

    for (const row of rawRows) {
      // Determine country name based on format
      let countryName = '';
      if (isOfficialFormat) {
        // Official FATF format: first column header contains "Jurisdiction"
        const firstKey = Object.keys(row)[0];
        countryName = String(row[firstKey] || '').trim();
      } else {
        // Custom format: look for "Pays", "pays", "Country"
        countryName = String(row['Pays'] || row['pays'] || row['Country'] || '').trim();
      }

      if (!countryName || isFootnote(countryName)) continue;

      const date = parseDate(row['Report \nDate'] || row['Report Date'] || row['Date']);
      if (!date) continue;

      const reportType = String(row['Report \nType'] || row['Report Type'] || '').trim();
      const body = String(row['Assessment body/bodies '] || row['Assessment body/bodies'] || row['Body'] || '').trim();

      // Parse IO1-IO11
      const ios: string[] = [];
      for (let i = 1; i <= 11; i++) {
        const val = String(
          row[`IO${i}`] || row[`IO.${i}`] || row[`RI.${i}`] || row[`RI${i}`] || ''
        ).trim().toUpperCase();
        ios.push(val || 'N/A');
      }

      // Parse R.1-R.40
      const recs: string[] = [];
      for (let i = 1; i <= 40; i++) {
        const val = String(
          row[`R.${i}`] || row[`R${i}`] || row[`Recommandation ${i}`] || ''
        ).trim().toUpperCase();
        recs.push(val || 'N/A');
      }

      if (!countryEvals.has(countryName)) {
        countryEvals.set(countryName, []);
      }
      countryEvals.get(countryName)!.push({ date, reportType, body, ios, recs });
    }

    let updatedCount = 0;

    for (const [countryName, evaluations] of countryEvals) {
      const existing = countriesMap.get(countryName);
      if (!existing) continue;

      // Sort by date descending
      evaluations.sort((a, b) => b.date.localeCompare(a.date));

      // Latest: prefer MER or MER+FUR, skip FUAR
      let latest: EvalRow | null = null;
      const remaining: EvalRow[] = [];
      for (const ev of evaluations) {
        if (!latest && ev.reportType !== 'FUAR') {
          latest = ev;
        } else {
          remaining.push(ev);
        }
      }
      if (!latest) continue;

      // Previous: prefer earliest MER
      const merEvals = remaining.filter(e => e.reportType.includes('MER'));
      const previous = merEvals[merEvals.length - 1] || remaining[remaining.length - 1] || null;

      // Update recommendations (R.1-R.40)
      for (let i = 0; i < 40 && i < latest.recs.length; i++) {
        const code = latest.recs[i];
        const parsed = parseCompliance(code);
        const recIndex = existing.recommendations.findIndex((r: any) => r.id === i + 1);
        if (recIndex >= 0) {
          existing.recommendations[recIndex].compliance = parsed.compliance;
          existing.recommendations[recIndex].ratingCode = parsed.ratingCode;
        }
      }

      // Update immediate results (IO1-IO11)
      for (let i = 0; i < 11 && i < latest.ios.length; i++) {
        const code = latest.ios[i];
        const parsed = parseEffectiveness(code);
        const riIndex = existing.immediateResults.findIndex((r: any) => r.id === i + 1);
        if (riIndex >= 0) {
          existing.immediateResults[riIndex].effectiveness = parsed.effectiveness;
          existing.immediateResults[riIndex].effectivenessCode = parsed.effectivenessCode;
        }
      }

      // Recalculate compliance score
      const compTotal = existing.recommendations.reduce((sum: number, r: any) => {
        return sum + (COMPLIANCE_SCORE[r.ratingCode] || 0);
      }, 0);
      const overallCompliance = Math.round(compTotal / 40);

      // Recalculate effectiveness score
      const effTotal = existing.immediateResults.reduce((sum: number, r: any) => {
        return sum + (EFFECTIVENESS_SCORE[r.effectivenessCode] || 0);
      }, 0);
      const effectivenessPct = Math.round((effTotal / 44) * 100);

      const globalRating = getGlobalRating(overallCompliance, effectivenessPct);

      existing.latestEvaluation = {
        date: latest.date,
        globalRating,
        overallCompliance,
        overallEffectiveness: effectivenessPct,
        reportType: latest.reportType,
        assessmentBody: latest.body,
      };
      existing.reportType = latest.reportType;
      existing.assessmentBody = latest.body;
      existing.overallCompliance = overallCompliance;

      // Update previous evaluation
      if (previous) {
        const prevComp = previous.recs.reduce((sum: number, code: string) => sum + (COMPLIANCE_SCORE[code] || 0), 0);
        const prevEff = previous.ios.reduce((sum: number, code: string) => sum + (EFFECTIVENESS_SCORE[code] || 0), 0);
        const prevCompPct = Math.round(prevComp / 40);
        const prevEffPct = Math.round((prevEff / 44) * 100);
        const prevGlobal = getGlobalRating(prevCompPct, prevEffPct);

        existing.previousEvaluation = {
          date: previous.date,
          globalRating: prevGlobal,
          overallCompliance: prevCompPct,
          overallEffectiveness: prevEffPct,
          reportType: previous.reportType,
          assessmentBody: previous.body,
        };
      }

      // Update summary
      if (existing.summary) {
        existing.summary.technicalComplianceScore = overallCompliance;
        existing.summary.effectivenessScore = effectivenessPct;
      }

      updatedCount++;
    }

    // Save updated data
    existingData.countries = existingData.countries.map((c: any) => countriesMap.get(c.countryName) || c);
    fs.writeFileSync(dataPath, JSON.stringify(existingData, null, 2), 'utf-8');

    // Also copy to public/data
    const publicPath = path.join(process.cwd(), 'public', 'data', 'gafi-data.json');
    if (fs.existsSync(path.dirname(publicPath))) {
      fs.writeFileSync(publicPath, JSON.stringify(existingData, null, 2), 'utf-8');
    }

    return NextResponse.json({
      success: true,
      updatedCountries: updatedCount,
      totalRows: rawRows.length,
      format: isOfficialFormat ? 'FATF Official (Ratings only)' : 'Custom',
    });
  } catch (error) {
    console.error('Excel import error:', error);
    return NextResponse.json(
      { error: 'Erreur lors du traitement du fichier Excel.' },
      { status: 500 }
    );
  }
}