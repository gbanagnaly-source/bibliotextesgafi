import { NextResponse } from "next/server";
import gafiData from "@/data/gafi-data.json";

// Normalize apostrophe-like characters to a canonical form for matching
function normalize(str: string): string {
  return str
    .replace(/[\u2019\u2018\u201A\u201B\uFF07]/g, "'")
    .toLowerCase();
}

// Lightweight list for overview and selector
function buildCountryList() {
  return gafiData.countries.map((c: any) => ({
    countryName: c.countryName,
    countryCode: c.countryCode || "",
    region: c.region,
    reportType: c.reportType,
    assessmentBody: c.assessmentBody,
    latestEvaluation: c.latestEvaluation,
    previousEvaluation: c.previousEvaluation,
    summary: c.summary,
  }));
}

let countryListCache: any[] | null = null;

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const name = searchParams.get("country");

  if (name) {
    const decoded = decodeURIComponent(name);
    const country = gafiData.countries.find(
      (c: any) => normalize(c.countryName) === normalize(decoded)
    );
    if (!country) {
      return NextResponse.json({ error: "Pays non trouvé" }, { status: 404 });
    }
    return NextResponse.json(country);
  }

  // Return lightweight list
  if (!countryListCache) {
    countryListCache = buildCountryList();
  }
  return NextResponse.json(countryListCache);
}