import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "BiblioGAFI — Bibliothèque de visualisation GAFI",
  description: "Consultez les résultats des évaluations mutuelles du GAFI : conformité technique aux 40 Recommandations et efficacité du système LBC/FT.",
  keywords: ["GAFI", "FATF", "LBC", "FT", "évaluation", "recommandations", "résultats immédiats", "blanchiment", "terrorisme"],
  icons: {
    icon: "/icon-192x192.png",
    apple: "/icon-180x180.png",
  },
  openGraph: {
    title: "BiblioGAFI — Bibliothèque de visualisation GAFI",
    description: "Consultez les résultats des évaluations mutuelles du GAFI : conformité technique aux 40 Recommandations et efficacité du système LBC/FT.",
    type: "website",
  },
  twitter: {
    card: "summary",
    title: "BiblioGAFI — Bibliothèque de visualisation GAFI",
    description: "Consultez les résultats des évaluations mutuelles du GAFI.",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
