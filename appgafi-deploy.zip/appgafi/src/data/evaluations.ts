// Types GAFI
export type ComplianceLevel = 'Conforme' | 'Partiellement Conforme' | 'Non Conforme' | 'Largement Non Conforme';
export type EffectivenessLevel = 'Remarquable' | 'Substantiel' | 'Modéré' | 'Faible';
export type GlobalRating = 'Satisfaisant' | 'Suffisant' | 'Non Satisfaisant' | 'Insuffisant';

export interface Recommendation {
  id: number;
  title: string;
  description: string;
  compliance: ComplianceLevel;
  keyIssues: string[];
}

export interface ImmediateResult {
  id: number;
  title: string;
  shortTitle: string;
  description: string;
  effectiveness: EffectivenessLevel;
  fundamental: boolean;
}

export interface CountryEvaluation {
  countryCode: string;
  countryName: string;
  flagEmoji: string;
  flagColors: [string, string, string];
  region: string;
  previousEvaluation: {
    date: string;
    globalRating: GlobalRating;
    overallCompliance: number;
    overallEffectiveness: number;
  };
  latestEvaluation: {
    date: string;
    globalRating: GlobalRating;
    overallCompliance: number;
    overallEffectiveness: number;
  };
  recommendations: Recommendation[];
  immediateResults: ImmediateResult[];
  summary: {
    technicalComplianceScore: number;
    effectivenessScore: number;
    strengths: string[];
    areasForImprovement: string[];
    highRiskAreas: string[];
  };
}

// Helper: levels to score
const complianceScore: Record<ComplianceLevel, number> = {
  'Conforme': 4,
  'Partiellement Conforme': 3,
  'Non Conforme': 2,
  'Largement Non Conforme': 1,
};

const effectivenessScore: Record<EffectivenessLevel, number> = {
  'Remarquable': 4,
  'Substantiel': 3,
  'Modéré': 2,
  'Faible': 1,
};

// --- Côte d'Ivoire ---
const coteDIvoire: CountryEvaluation = {
  countryCode: 'CI',
  countryName: 'Côte d\'Ivoire',
  flagEmoji: '🇨🇮',
  flagColors: ['#F77F00', '#FFFFFF', '#009E60'],
  region: 'Afrique de l\'Ouest',
  previousEvaluation: {
    date: '2022-05',
    globalRating: 'Non Satisfaisant',
    overallCompliance: 54,
    overallEffectiveness: 38,
  },
  latestEvaluation: {
    date: '2025-05',
    globalRating: 'Non Satisfaisant',
    overallCompliance: 61,
    overallEffectiveness: 44,
  },
  recommendations: [
    { id: 1, title: 'Risques et politique BLT/FT', description: 'Évaluation des risques, politique nationale et coordination', compliance: 'Partiellement Conforme', keyIssues: ['Mise à jour de l\'ANR incomplète', 'Coordination inter-institutionnelle à renforcer'] },
    { id: 2, title: 'Coopération internationale', description: 'Assistance juridique mutuelle et extradition', compliance: 'Partiellement Conforme', keyIssues: ['Délais de réponse aux commissions rogatoires'] },
    { id: 3, title: 'Blanchiment d\'argent', description: 'Infraction de blanchiment de capitaux', compliance: 'Conforme', keyIssues: [] },
    { id: 4, title: 'Confiscation et mesures provisoires', description: 'Pouvoirs de confiscation et gel des avoirs', compliance: 'Partiellement Conforme', keyIssues: ['Confiscation en valeur limitée'] },
    { id: 5, title: 'Terrorisme et financement du terrorisme', description: 'Infraction de financement du terrorisme', compliance: 'Conforme', keyIssues: [] },
    { id: 6, title: 'Financement de la prolifération', description: 'Obligations liées à la prolifération des armes', compliance: 'Non Conforme', keyIssues: ['Absence de cadre législatif spécifique'] },
    { id: 7, title: 'Mesures ciblées liées à la prolifération', description: 'Sanctions financières ciblées', compliance: 'Partiellement Conforme', keyIssues: ['Listes de sanctions non intégralement implémentées'] },
    { id: 8, title: 'Obligations BLT des OBP', description: 'Obligations de diligence pour les organismes bancaires', compliance: 'Partiellement Conforme', keyIssues: ['Contrôle périodique insuffisant'] },
    { id: 9, title: 'Obligations BLT des professions NC', description: 'Avocats, notaires, comptables', compliance: 'Non Conforme', keyIssues: ['Manque de formation et de supervision'] },
    { id: 10, title: 'Transparence des personnes morales', description: 'Bénéficiaires effectifs et registres', compliance: 'Partiellement Conforme', keyIssues: ['Registre des bénéficiaires effectifs incomplet'] },
    { id: 11, title: 'Comptes et registres', description: 'Tenue des comptes et enregistrements', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 12, title: 'Déclarations de soupçon', description: 'Obligation de déclaration des transactions suspectes', compliance: 'Conforme', keyIssues: [] },
    { id: 13, title: 'Signalement des opérations inhabituelles', description: 'Déclarations d\'opérations inhabituelles', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 15, title: 'Nouvelles technologies', description: 'BLT lié aux nouvelles technologies', compliance: 'Non Conforme', keyIssues: ['Cadre réglementaire crypto-monnaies absent'] },
    { id: 16, title: 'Transferts électroniques de fonds', description: 'Informations sur les transferts électroniques', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 17, title: 'Coopération entre autorités de supervision', description: 'Échange d\'informations entre superviseurs', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 18, title: 'Contrôle externe des OBP', description: 'Supervision et contrôle des entités assujetties', compliance: 'Partiellement Conforme', keyIssues: ['Ressources de supervision limitées'] },
    { id: 20, title: 'Déclaration d\'opérations en espèces', description: 'Seuils et déclaration des opérations en espèces', compliance: 'Conforme', keyIssues: [] },
    { id: 21, title: 'Contrôle des opérations transfrontalières', description: 'Déclaration des transferts transfrontaliers', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 22, title: 'Douanes', description: 'Rôle des douanes dans la lutte anti-blanchiment', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 24, title: 'Personnes morales écrans', description: 'Transparence et accès à l\'information', compliance: 'Non Conforme', keyIssues: ['Anonymat des sociétés écrans'] },
    { id: 25, title: 'Responsabilité des personnes morales', description: 'Responsabilité pénale des entités', compliance: 'Conforme', keyIssues: [] },
    { id: 26, title: 'Compétences des autorités chargées de l\'enquête', description: 'Pouvoirs d\'investigation', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 28, title: 'Autorités de régulation et de supervision', description: 'Contrôle et supervision du secteur financier', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 29, title: 'CENTIF', description: 'Cellule de Traitement des Informations Financières', compliance: 'Conforme', keyIssues: [] },
    { id: 30, title: 'Responsabilités des autorités de détection', description: 'Obligations de détection et de signalement', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 32, title: 'Transferts de fonds', description: 'Statistiques sur les transferts de fonds', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 33, title: 'Statistiques sur les enquêtes', description: 'Données statistiques sur les dossiers BLT', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 34, title: 'Échange d\'informations avec d\'autres pays', description: 'Coopération internationale et échange de données', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 35, title: 'Sanctions et mesures dissuasives', description: 'Sanctions applicables en cas de non-conformité', compliance: 'Non Conforme', keyIssues: ['Sanctions peu appliquées'] },
    { id: 36, title: 'Organismes internationaux', description: 'Instruments internationaux et conventions', compliance: 'Conforme', keyIssues: [] },
    { id: 37, title: 'Assistance juridique mutuelle', description: 'Entraide judiciaire en matière pénale', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 38, title: 'Entraide judiciaire (FT)', description: 'Coopération en matière de financement du terrorisme', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 39, title: 'Extradition', description: 'Procédures d\'extradition', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 40, title: 'Autres formes de coopération', description: 'Coopération informelle et échange d\'informations', compliance: 'Conforme', keyIssues: [] },
  ],
  immediateResults: [
    { id: 1, title: 'Compréhension des risques BLT/FT/FP', shortTitle: 'Risques', description: 'Compréhension et évaluation des risques de blanchiment, financement du terrorisme et de la prolifération', effectiveness: 'Modéré', fundamental: true },
    { id: 2, title: 'Coopération internationale', shortTitle: 'Coopération', description: 'Efficacité de la coopération internationale en matière de BLT/FT', effectiveness: 'Substantiel', fundamental: true },
    { id: 3, title: 'Supervision et surveillance', shortTitle: 'Supervision', description: 'Supervision et surveillance du respect des obligations BLT/FT', effectiveness: 'Modéré', fundamental: true },
    { id: 4, title: 'Mesures préventives', shortTitle: 'Prévention', description: 'Application des mesures préventives par les entités assujetties', effectiveness: 'Faible', fundamental: true },
    { id: 5, title: 'Détection et signalement', shortTitle: 'Détection', description: 'Détection et signalement des opérations suspectes', effectiveness: 'Modéré', fundamental: true },
    { id: 6, title: 'Poursuites pénales', shortTitle: 'Poursuites', description: 'Poursuites pénales efficaces en matière de BLT/FT', effectiveness: 'Faible', fundamental: true },
    { id: 7, title: 'Mesures restrictives et confiscation', shortTitle: 'Confiscation', description: 'Application de mesures restrictives et confiscation d\'avoirs', effectiveness: 'Faible', fundamental: true },
    { id: 8, title: 'Accompagnement des personnes vulnérables', shortTitle: 'Victimes', description: 'Protection et accompagnement des victimes de terrorisme', effectiveness: 'Modéré', fundamental: false },
    { id: 9, title: 'Transparence juridique', shortTitle: 'Transparence', description: 'Accès aux informations sur les personnes morales et constructions juridiques', effectiveness: 'Faible', fundamental: true },
    { id: 10, title: 'Résultats opérationnels', shortTitle: 'Résultats', description: 'Statistiques et résultats des investigations BLT/FT', effectiveness: 'Modéré', fundamental: true },
    { id: 11, title: 'Sanctions et mesures dissuasives', shortTitle: 'Sanctions', description: 'Application effective de sanctions proportionnelles et dissuasives', effectiveness: 'Faible', fundamental: true },
  ],
  summary: {
    technicalComplianceScore: 61,
    effectivenessScore: 44,
    strengths: [
      'Cadre législatif solide pour les infractions de blanchiment et de financement du terrorisme',
      'CENTIF opérationnelle et performante',
      'Coopération internationale active',
      'Système de déclaration de soupçon bien établi',
    ],
    areasForImprovement: [
      'Transparence des bénéficiaires effectifs à renforcer',
      'Confiscation d\'avoirs insuffisante',
      'Poursuites pénales à intensifier',
      'Ressources de supervision limitées',
    ],
    highRiskAreas: [
      'Secteur immobilier',
      'Transferts informels de fonds',
      'Commerce de métaux précieux',
      'Sociétés écrans et constructions juridiques complexes',
    ],
  },
};

// --- Sénégal ---
const senegal: CountryEvaluation = {
  countryCode: 'SN',
  countryName: 'Sénégal',
  flagEmoji: '🇸🇳',
  flagColors: ['#00853F', '#FCD116', '#E31B23'],
  region: 'Afrique de l\'Ouest',
  previousEvaluation: {
    date: '2021-03',
    globalRating: 'Suffisant',
    overallCompliance: 62,
    overallEffectiveness: 49,
  },
  latestEvaluation: {
    date: '2025-03',
    globalRating: 'Suffisant',
    overallCompliance: 68,
    overallEffectiveness: 55,
  },
  recommendations: [
    { id: 1, title: 'Risques et politique BLT/FT', description: 'Évaluation des risques, politique nationale et coordination', compliance: 'Conforme', keyIssues: [] },
    { id: 2, title: 'Coopération internationale', description: 'Assistance juridique mutuelle et extradition', compliance: 'Conforme', keyIssues: [] },
    { id: 3, title: 'Blanchiment d\'argent', description: 'Infraction de blanchiment de capitaux', compliance: 'Conforme', keyIssues: [] },
    { id: 4, title: 'Confiscation et mesures provisoires', description: 'Pouvoirs de confiscation et gel des avoirs', compliance: 'Partiellement Conforme', keyIssues: ['Confiscation en valeur à renforcer'] },
    { id: 5, title: 'Terrorisme et financement du terrorisme', description: 'Infraction de financement du terrorisme', compliance: 'Conforme', keyIssues: [] },
    { id: 6, title: 'Financement de la prolifération', description: 'Obligations liées à la prolifération des armes', compliance: 'Partiellement Conforme', keyIssues: ['Cadre en cours de mise en place'] },
    { id: 7, title: 'Mesures ciblées liées à la prolifération', description: 'Sanctions financières ciblées', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 8, title: 'Obligations BLT des OBP', description: 'Obligations de diligence pour les organismes bancaires', compliance: 'Conforme', keyIssues: [] },
    { id: 9, title: 'Obligations BLT des professions NC', description: 'Avocats, notaires, comptables', compliance: 'Partiellement Conforme', keyIssues: ['Sensibilisation des professions réglementées'] },
    { id: 10, title: 'Transparence des personnes morales', description: 'Bénéficiaires effectifs et registres', compliance: 'Partiellement Conforme', keyIssues: ['Accès au registre limité'] },
    { id: 11, title: 'Comptes et registres', description: 'Tenue des comptes et enregistrements', compliance: 'Conforme', keyIssues: [] },
    { id: 12, title: 'Déclarations de soupçon', description: 'Obligation de déclaration des transactions suspectes', compliance: 'Conforme', keyIssues: [] },
    { id: 13, title: 'Signalement des opérations inhabituelles', description: 'Déclarations d\'opérations inhabituelles', compliance: 'Conforme', keyIssues: [] },
    { id: 15, title: 'Nouvelles technologies', description: 'BLT lié aux nouvelles technologies', compliance: 'Non Conforme', keyIssues: ['Absence de réglementation crypto'] },
    { id: 16, title: 'Transferts électroniques de fonds', description: 'Informations sur les transferts électroniques', compliance: 'Conforme', keyIssues: [] },
    { id: 17, title: 'Coopération entre autorités de supervision', description: 'Échange d\'informations entre superviseurs', compliance: 'Conforme', keyIssues: [] },
    { id: 18, title: 'Contrôle externe des OBP', description: 'Supervision et contrôle des entités assujetties', compliance: 'Conforme', keyIssues: [] },
    { id: 20, title: 'Déclaration d\'opérations en espèces', description: 'Seuils et déclaration des opérations en espèces', compliance: 'Conforme', keyIssues: [] },
    { id: 21, title: 'Contrôle des opérations transfrontalières', description: 'Déclaration des transferts transfrontaliers', compliance: 'Conforme', keyIssues: [] },
    { id: 22, title: 'Douanes', description: 'Rôle des douanes dans la lutte anti-blanchiment', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 24, title: 'Personnes morales écrans', description: 'Transparence et accès à l\'information', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 25, title: 'Responsabilité des personnes morales', description: 'Responsabilité pénale des entités', compliance: 'Conforme', keyIssues: [] },
    { id: 26, title: 'Compétences des autorités chargées de l\'enquête', description: 'Pouvoirs d\'investigation', compliance: 'Conforme', keyIssues: [] },
    { id: 28, title: 'Autorités de régulation et de supervision', description: 'Contrôle et supervision du secteur financier', compliance: 'Conforme', keyIssues: [] },
    { id: 29, title: 'CENTIF', description: 'Cellule de Traitement des Informations Financières', compliance: 'Conforme', keyIssues: [] },
    { id: 30, title: 'Responsabilités des autorités de détection', description: 'Obligations de détection et de signalement', compliance: 'Conforme', keyIssues: [] },
    { id: 32, title: 'Transferts de fonds', description: 'Statistiques sur les transferts de fonds', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 33, title: 'Statistiques sur les enquêtes', description: 'Données statistiques sur les dossiers BLT', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 34, title: 'Échange d\'informations avec d\'autres pays', description: 'Coopération internationale et échange de données', compliance: 'Conforme', keyIssues: [] },
    { id: 35, title: 'Sanctions et mesures dissuasives', description: 'Sanctions applicables en cas de non-conformité', compliance: 'Partiellement Conforme', keyIssues: ['Application inégale des sanctions'] },
    { id: 36, title: 'Organismes internationaux', description: 'Instruments internationaux et conventions', compliance: 'Conforme', keyIssues: [] },
    { id: 37, title: 'Assistance juridique mutuelle', description: 'Entraide judiciaire en matière pénale', compliance: 'Conforme', keyIssues: [] },
    { id: 38, title: 'Entraide judiciaire (FT)', description: 'Coopération en matière de financement du terrorisme', compliance: 'Conforme', keyIssues: [] },
    { id: 39, title: 'Extradition', description: 'Procédures d\'extradition', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 40, title: 'Autres formes de coopération', description: 'Coopération informelle et échange d\'informations', compliance: 'Conforme', keyIssues: [] },
  ],
  immediateResults: [
    { id: 1, title: 'Compréhension des risques BLT/FT/FP', shortTitle: 'Risques', description: 'Compréhension et évaluation des risques', effectiveness: 'Substantiel', fundamental: true },
    { id: 2, title: 'Coopération internationale', shortTitle: 'Coopération', description: 'Efficacité de la coopération internationale', effectiveness: 'Substantiel', fundamental: true },
    { id: 3, title: 'Supervision et surveillance', shortTitle: 'Supervision', description: 'Supervision et surveillance du respect des obligations', effectiveness: 'Substantiel', fundamental: true },
    { id: 4, title: 'Mesures préventives', shortTitle: 'Prévention', description: 'Application des mesures préventives', effectiveness: 'Modéré', fundamental: true },
    { id: 5, title: 'Détection et signalement', shortTitle: 'Détection', description: 'Détection et signalement des opérations suspectes', effectiveness: 'Substantiel', fundamental: true },
    { id: 6, title: 'Poursuites pénales', shortTitle: 'Poursuites', description: 'Poursuites pénales efficaces', effectiveness: 'Modéré', fundamental: true },
    { id: 7, title: 'Mesures restrictives et confiscation', shortTitle: 'Confiscation', description: 'Application de mesures restrictives', effectiveness: 'Modéré', fundamental: true },
    { id: 8, title: 'Accompagnement des victimes', shortTitle: 'Victimes', description: 'Protection des victimes de terrorisme', effectiveness: 'Modéré', fundamental: false },
    { id: 9, title: 'Transparence juridique', shortTitle: 'Transparence', description: 'Accès aux informations sur les personnes morales', effectiveness: 'Modéré', fundamental: true },
    { id: 10, title: 'Résultats opérationnels', shortTitle: 'Résultats', description: 'Statistiques et résultats des investigations', effectiveness: 'Modéré', fundamental: true },
    { id: 11, title: 'Sanctions et mesures dissuasives', shortTitle: 'Sanctions', description: 'Application effective de sanctions', effectiveness: 'Modéré', fundamental: true },
  ],
  summary: {
    technicalComplianceScore: 68,
    effectivenessScore: 55,
    strengths: [
      'Cadre juridique complet et à jour',
      'CENTIF très performante',
      'Bonne coopération internationale',
      'Système de supervision robuste',
    ],
    areasForImprovement: [
      'Régulation des crypto-monnaies',
      'Confiscation en valeur',
      'Accès aux registres de bénéficiaires effectifs',
    ],
    highRiskAreas: [
      'Transferts informels (hawala)',
      'Secteur immobilier',
      'Commerce des métaux précieux',
    ],
  },
};

// --- Cameroun ---
const cameroun: CountryEvaluation = {
  countryCode: 'CM',
  countryName: 'Cameroun',
  flagEmoji: '🇨🇲',
  flagColors: ['#007A53', '#FCD116', '#CE1026'],
  region: 'Afrique Centrale',
  previousEvaluation: {
    date: '2020-06',
    globalRating: 'Non Satisfaisant',
    overallCompliance: 48,
    overallEffectiveness: 32,
  },
  latestEvaluation: {
    date: '2024-06',
    globalRating: 'Non Satisfaisant',
    overallCompliance: 55,
    overallEffectiveness: 38,
  },
  recommendations: [
    { id: 1, title: 'Risques et politique BLT/FT', description: 'Évaluation des risques, politique nationale et coordination', compliance: 'Partiellement Conforme', keyIssues: ['ANR pas à jour', 'Coordination faible'] },
    { id: 2, title: 'Coopération internationale', description: 'Assistance juridique mutuelle et extradition', compliance: 'Partiellement Conforme', keyIssues: ['Délais excessifs'] },
    { id: 3, title: 'Blanchiment d\'argent', description: 'Infraction de blanchiment de capitaux', compliance: 'Partiellement Conforme', keyIssues: ['Infraction de blanchiment autonome à renforcer'] },
    { id: 4, title: 'Confiscation et mesures provisoires', description: 'Pouvoirs de confiscation et gel des avoirs', compliance: 'Non Conforme', keyIssues: ['Peu de confiscations effectives'] },
    { id: 5, title: 'Terrorisme et financement du terrorisme', description: 'Infraction de financement du terrorisme', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 6, title: 'Financement de la prolifération', description: 'Obligations liées à la prolifération des armes', compliance: 'Largement Non Conforme', keyIssues: ['Cadre absent'] },
    { id: 7, title: 'Mesures ciblées liées à la prolifération', description: 'Sanctions financières ciblées', compliance: 'Non Conforme', keyIssues: ['Pas de mécanisme de gel'] },
    { id: 8, title: 'Obligations BLT des OBP', description: 'Obligations de diligence pour les organismes bancaires', compliance: 'Partiellement Conforme', keyIssues: ['Application inégale'] },
    { id: 9, title: 'Obligations BLT des professions NC', description: 'Avocats, notaires, comptables', compliance: 'Non Conforme', keyIssues: ['Professions non assujetties'] },
    { id: 10, title: 'Transparence des personnes morales', description: 'Bénéficiaires effectifs et registres', compliance: 'Non Conforme', keyIssues: ['Registre inexistant'] },
    { id: 11, title: 'Comptes et registres', description: 'Tenue des comptes et enregistrements', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 12, title: 'Déclarations de soupçon', description: 'Obligation de déclaration des transactions suspectes', compliance: 'Partiellement Conforme', keyIssues: ['Taux de déclaration faible'] },
    { id: 15, title: 'Nouvelles technologies', description: 'BLT lié aux nouvelles technologies', compliance: 'Largement Non Conforme', keyIssues: ['Aucun cadre'] },
    { id: 16, title: 'Transferts électroniques de fonds', description: 'Informations sur les transferts électroniques', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 17, title: 'Coopération entre autorités', description: 'Échange d\'informations entre superviseurs', compliance: 'Non Conforme', keyIssues: ['Échanges limités'] },
    { id: 18, title: 'Contrôle externe des OBP', description: 'Supervision des entités assujetties', compliance: 'Non Conforme', keyIssues: ['Ressources très limitées'] },
    { id: 20, title: 'Déclaration d\'opérations en espèces', description: 'Seuils et déclaration des opérations en espèces', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 21, title: 'Contrôle transfrontalier', description: 'Déclaration des transferts transfrontaliers', compliance: 'Non Conforme', keyIssues: [] },
    { id: 22, title: 'Douanes', description: 'Rôle des douanes', compliance: 'Non Conforme', keyIssues: [] },
    { id: 24, title: 'Personnes morales écrans', description: 'Transparence et accès à l\'information', compliance: 'Largement Non Conforme', keyIssues: [] },
    { id: 25, title: 'Responsabilité des personnes morales', description: 'Responsabilité pénale des entités', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 26, title: 'Compétences des autorités', description: 'Pouvoirs d\'investigation', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 28, title: 'Autorités de régulation', description: 'Contrôle du secteur financier', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 29, title: 'ANIF', description: 'Cellule nationale de traitement des informations financières', compliance: 'Partiellement Conforme', keyIssues: ['Ressources humaines insuffisantes'] },
    { id: 30, title: 'Responsabilités de détection', description: 'Obligations de détection et de signalement', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 32, title: 'Transferts de fonds', description: 'Statistiques sur les transferts', compliance: 'Non Conforme', keyIssues: [] },
    { id: 33, title: 'Statistiques sur les enquêtes', description: 'Données statistiques', compliance: 'Non Conforme', keyIssues: [] },
    { id: 34, title: 'Échange d\'informations', description: 'Coopération internationale', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 35, title: 'Sanctions et mesures dissuasives', description: 'Sanctions pour non-conformité', compliance: 'Largement Non Conforme', keyIssues: ['Aucune sanction effective'] },
    { id: 36, title: 'Organismes internationaux', description: 'Instruments internationaux', compliance: 'Conforme', keyIssues: [] },
    { id: 37, title: 'Assistance juridique mutuelle', description: 'Entraide judiciaire', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 38, title: 'Entraide judiciaire (FT)', description: 'Coopération en matière de FT', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 39, title: 'Extradition', description: 'Procédures d\'extradition', compliance: 'Non Conforme', keyIssues: [] },
    { id: 40, title: 'Autres formes de coopération', description: 'Coopération informelle', compliance: 'Partiellement Conforme', keyIssues: [] },
  ],
  immediateResults: [
    { id: 1, title: 'Compréhension des risques', shortTitle: 'Risques', description: 'Compréhension et évaluation des risques', effectiveness: 'Faible', fundamental: true },
    { id: 2, title: 'Coopération internationale', shortTitle: 'Coopération', description: 'Coopération internationale', effectiveness: 'Modéré', fundamental: true },
    { id: 3, title: 'Supervision et surveillance', shortTitle: 'Supervision', description: 'Supervision du respect des obligations', effectiveness: 'Faible', fundamental: true },
    { id: 4, title: 'Mesures préventives', shortTitle: 'Prévention', description: 'Mesures préventives', effectiveness: 'Faible', fundamental: true },
    { id: 5, title: 'Détection et signalement', shortTitle: 'Détection', description: 'Détection des opérations suspectes', effectiveness: 'Modéré', fundamental: true },
    { id: 6, title: 'Poursuites pénales', shortTitle: 'Poursuites', description: 'Poursuites pénales', effectiveness: 'Faible', fundamental: true },
    { id: 7, title: 'Confiscation', shortTitle: 'Confiscation', description: 'Confiscation d\'avoirs', effectiveness: 'Faible', fundamental: true },
    { id: 8, title: 'Victimes', shortTitle: 'Victimes', description: 'Protection des victimes', effectiveness: 'Faible', fundamental: false },
    { id: 9, title: 'Transparence juridique', shortTitle: 'Transparence', description: 'Transparence des personnes morales', effectiveness: 'Faible', fundamental: true },
    { id: 10, title: 'Résultats opérationnels', shortTitle: 'Résultats', description: 'Résultats des investigations', effectiveness: 'Faible', fundamental: true },
    { id: 11, title: 'Sanctions', shortTitle: 'Sanctions', description: 'Application des sanctions', effectiveness: 'Faible', fundamental: true },
  ],
  summary: {
    technicalComplianceScore: 55,
    effectivenessScore: 38,
    strengths: [
      'Adhésion aux conventions internationales',
      'Cellule ANIF opérationnelle malgré des ressources limitées',
      'Volonté politique affichée de réforme',
    ],
    areasForImprovement: [
      'Cadre législatif incomplet (prolifération, nouvelles technologies)',
      'Supervision et sanctions quasi inexistantes',
      'Transparence des personnes morales',
      'Ressources humaines et financières insuffisantes',
    ],
    highRiskAreas: [
      'Secteur extractif (pétrole, minerais)',
      'Transferts informels',
      'Corruption systémique',
      'Commerce transfrontalier informel',
    ],
  },
};

// --- Maroc ---
const maroc: CountryEvaluation = {
  countryCode: 'MA',
  countryName: 'Maroc',
  flagEmoji: '🇲🇦',
  flagColors: ['#C1272D', '#006233', '#C1272D'],
  region: 'Afrique du Nord',
  previousEvaluation: {
    date: '2021-09',
    globalRating: 'Satisfaisant',
    overallCompliance: 72,
    overallEffectiveness: 58,
  },
  latestEvaluation: {
    date: '2025-09',
    globalRating: 'Satisfaisant',
    overallCompliance: 78,
    overallEffectiveness: 65,
  },
  recommendations: [
    { id: 1, title: 'Risques et politique BLT/FT', description: 'Évaluation des risques et coordination', compliance: 'Conforme', keyIssues: [] },
    { id: 2, title: 'Coopération internationale', description: 'Assistance juridique mutuelle', compliance: 'Conforme', keyIssues: [] },
    { id: 3, title: 'Blanchiment d\'argent', description: 'Infraction de blanchiment', compliance: 'Conforme', keyIssues: [] },
    { id: 4, title: 'Confiscation', description: 'Pouvoirs de confiscation', compliance: 'Conforme', keyIssues: [] },
    { id: 5, title: 'Terrorisme et FT', description: 'Infraction de FT', compliance: 'Conforme', keyIssues: [] },
    { id: 6, title: 'Financement de la prolifération', description: 'Prolifération des armes', compliance: 'Partiellement Conforme', keyIssues: ['Mise en œuvre partielle'] },
    { id: 7, title: 'Mesures ciblées', description: 'Sanctions ciblées', compliance: 'Conforme', keyIssues: [] },
    { id: 8, title: 'Obligations BLT des OBP', description: 'Diligence des organismes bancaires', compliance: 'Conforme', keyIssues: [] },
    { id: 9, title: 'Obligations BLT professions NC', description: 'Professions non financières', compliance: 'Partiellement Conforme', keyIssues: ['Sensibilisation en cours'] },
    { id: 10, title: 'Transparence personnes morales', description: 'Bénéficiaires effectifs', compliance: 'Conforme', keyIssues: [] },
    { id: 11, title: 'Comptes et registres', description: 'Tenue des comptes', compliance: 'Conforme', keyIssues: [] },
    { id: 12, title: 'Déclarations de soupçon', description: 'Transactions suspectes', compliance: 'Conforme', keyIssues: [] },
    { id: 15, title: 'Nouvelles technologies', description: 'BLT et nouvelles technologies', compliance: 'Partiellement Conforme', keyIssues: ['Réglementation crypto en développement'] },
    { id: 16, title: 'Transferts électroniques', description: 'Transferts électroniques de fonds', compliance: 'Conforme', keyIssues: [] },
    { id: 17, title: 'Coopération superviseurs', description: 'Échange entre superviseurs', compliance: 'Conforme', keyIssues: [] },
    { id: 18, title: 'Contrôle externe', description: 'Supervision des entités', compliance: 'Conforme', keyIssues: [] },
    { id: 20, title: 'Opérations en espèces', description: 'Déclaration espèces', compliance: 'Conforme', keyIssues: [] },
    { id: 21, title: 'Transferts transfrontaliers', description: 'Contrôle transfrontalier', compliance: 'Conforme', keyIssues: [] },
    { id: 22, title: 'Douanes', description: 'Rôle des douanes', compliance: 'Conforme', keyIssues: [] },
    { id: 24, title: 'Personnes morales écrans', description: 'Transparence', compliance: 'Conforme', keyIssues: [] },
    { id: 25, title: 'Responsabilité morale', description: 'Responsabilité pénale', compliance: 'Conforme', keyIssues: [] },
    { id: 26, title: 'Compétences d\'enquête', description: 'Pouvoirs d\'investigation', compliance: 'Conforme', keyIssues: [] },
    { id: 28, title: 'Autorités de régulation', description: 'Supervision financière', compliance: 'Conforme', keyIssues: [] },
    { id: 29, title: 'CTMF', description: 'Cellule de traitement des informations financières', compliance: 'Conforme', keyIssues: [] },
    { id: 30, title: 'Responsabilités de détection', description: 'Détection et signalement', compliance: 'Conforme', keyIssues: [] },
    { id: 32, title: 'Transferts de fonds', description: 'Statistiques', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 33, title: 'Statistiques enquêtes', description: 'Données statistiques', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 34, title: 'Échange d\'informations', description: 'Coopération', compliance: 'Conforme', keyIssues: [] },
    { id: 35, title: 'Sanctions', description: 'Sanctions et mesures dissuasives', compliance: 'Conforme', keyIssues: [] },
    { id: 36, title: 'Organismes internationaux', description: 'Instruments internationaux', compliance: 'Conforme', keyIssues: [] },
    { id: 37, title: 'Assistance juridique', description: 'Entraide judiciaire', compliance: 'Conforme', keyIssues: [] },
    { id: 38, title: 'Entraide FT', description: 'Coopération FT', compliance: 'Conforme', keyIssues: [] },
    { id: 39, title: 'Extradition', description: 'Procédures d\'extradition', compliance: 'Conforme', keyIssues: [] },
    { id: 40, title: 'Autres coopération', description: 'Coopération informelle', compliance: 'Conforme', keyIssues: [] },
  ],
  immediateResults: [
    { id: 1, title: 'Compréhension des risques', shortTitle: 'Risques', description: 'Compréhension des risques', effectiveness: 'Substantiel', fundamental: true },
    { id: 2, title: 'Coopération internationale', shortTitle: 'Coopération', description: 'Coopération internationale', effectiveness: 'Remarquable', fundamental: true },
    { id: 3, title: 'Supervision', shortTitle: 'Supervision', description: 'Supervision', effectiveness: 'Substantiel', fundamental: true },
    { id: 4, title: 'Prévention', shortTitle: 'Prévention', description: 'Mesures préventives', effectiveness: 'Substantiel', fundamental: true },
    { id: 5, title: 'Détection', shortTitle: 'Détection', description: 'Détection et signalement', effectiveness: 'Substantiel', fundamental: true },
    { id: 6, title: 'Poursuites', shortTitle: 'Poursuites', description: 'Poursuites pénales', effectiveness: 'Substantiel', fundamental: true },
    { id: 7, title: 'Confiscation', shortTitle: 'Confiscation', description: 'Confiscation d\'avoirs', effectiveness: 'Modéré', fundamental: true },
    { id: 8, title: 'Victimes', shortTitle: 'Victimes', description: 'Victimes de terrorisme', effectiveness: 'Substantiel', fundamental: false },
    { id: 9, title: 'Transparence', shortTitle: 'Transparence', description: 'Transparence juridique', effectiveness: 'Substantiel', fundamental: true },
    { id: 10, title: 'Résultats', shortTitle: 'Résultats', description: 'Résultats opérationnels', effectiveness: 'Substantiel', fundamental: true },
    { id: 11, title: 'Sanctions', shortTitle: 'Sanctions', description: 'Sanctions', effectiveness: 'Substantiel', fundamental: true },
  ],
  summary: {
    technicalComplianceScore: 78,
    effectivenessScore: 65,
    strengths: [
      'Cadre juridique très complet et régulièrement mis à jour',
      'CTMF performante et bien dotée en ressources',
      'Excellente coopération internationale',
      'Système de supervision avancé',
      'Engagement politique fort',
    ],
    areasForImprovement: [
      'Réglementation des actifs virtuels à finaliser',
      'Confiscation en valeur à renforcer',
      'Statistiques à améliorer',
    ],
    highRiskAreas: [
      'Secteur immobilier informel',
      'Réseaux de transferts informels',
      'Contrebande transfrontalière',
    ],
  },
};

// --- Mali ---
const mali: CountryEvaluation = {
  countryCode: 'ML',
  countryName: 'Mali',
  flagEmoji: '🇲🇱',
  flagColors: ['#14B53A', '#FCD116', '#CE1126'],
  region: 'Afrique de l\'Ouest',
  previousEvaluation: {
    date: '2020-02',
    globalRating: 'Non Satisfaisant',
    overallCompliance: 42,
    overallEffectiveness: 25,
  },
  latestEvaluation: {
    date: '2025-02',
    globalRating: 'Insuffisant',
    overallCompliance: 45,
    overallEffectiveness: 28,
  },
  recommendations: [
    { id: 1, title: 'Risques et politique BLT/FT', description: 'Évaluation des risques et coordination', compliance: 'Non Conforme', keyIssues: ['ANR inexistante'] },
    { id: 2, title: 'Coopération internationale', description: 'Assistance juridique mutuelle', compliance: 'Non Conforme', keyIssues: ['Coopération très limitée'] },
    { id: 3, title: 'Blanchiment d\'argent', description: 'Infraction de blanchiment', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 4, title: 'Confiscation', description: 'Pouvoirs de confiscation', compliance: 'Largement Non Conforme', keyIssues: ['Confiscation quasi inexistante'] },
    { id: 5, title: 'Terrorisme et FT', description: 'Infraction de FT', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 6, title: 'Financement de la prolifération', description: 'Prolifération', compliance: 'Largement Non Conforme', keyIssues: ['Cadre absent'] },
    { id: 7, title: 'Mesures ciblées', description: 'Sanctions ciblées', compliance: 'Largement Non Conforme', keyIssues: ['Aucun mécanisme opérationnel'] },
    { id: 8, title: 'Obligations BLT des OBP', description: 'Diligence bancaire', compliance: 'Partiellement Conforme', keyIssues: ['Application très inégale'] },
    { id: 9, title: 'Obligations professions NC', description: 'Professions non financières', compliance: 'Largement Non Conforme', keyIssues: ['Aucune obligation'] },
    { id: 10, title: 'Transparence personnes morales', description: 'Bénéficiaires effectifs', compliance: 'Largement Non Conforme', keyIssues: [] },
    { id: 11, title: 'Comptes et registres', description: 'Tenue des comptes', compliance: 'Non Conforme', keyIssues: [] },
    { id: 12, title: 'Déclarations de soupçon', description: 'Transactions suspectes', compliance: 'Non Conforme', keyIssues: ['Taux de déclaration très faible'] },
    { id: 15, title: 'Nouvelles technologies', description: 'Nouvelles technologies', compliance: 'Largement Non Conforme', keyIssues: ['Aucun cadre'] },
    { id: 16, title: 'Transferts électroniques', description: 'Transferts électroniques', compliance: 'Non Conforme', keyIssues: [] },
    { id: 17, title: 'Coopération superviseurs', description: 'Échange entre superviseurs', compliance: 'Largement Non Conforme', keyIssues: [] },
    { id: 18, title: 'Contrôle externe', description: 'Supervision', compliance: 'Largement Non Conforme', keyIssues: ['Absence de supervision effective'] },
    { id: 20, title: 'Opérations en espèces', description: 'Déclaration espèces', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 21, title: 'Transferts transfrontaliers', description: 'Contrôle transfrontalier', compliance: 'Largement Non Conforme', keyIssues: [] },
    { id: 22, title: 'Douanes', description: 'Douanes', compliance: 'Non Conforme', keyIssues: [] },
    { id: 24, title: 'Personnes morales écrans', description: 'Transparence', compliance: 'Largement Non Conforme', keyIssues: [] },
    { id: 25, title: 'Responsabilité morale', description: 'Responsabilité pénale', compliance: 'Partiellement Conforme', keyIssues: [] },
    { id: 26, title: 'Compétences d\'enquête', description: 'Pouvoirs d\'investigation', compliance: 'Non Conforme', keyIssues: [] },
    { id: 28, title: 'Autorités de régulation', description: 'Supervision financière', compliance: 'Non Conforme', keyIssues: [] },
    { id: 29, title: 'CTCF', description: 'Cellule de renseignement financier', compliance: 'Partiellement Conforme', keyIssues: ['Ressources extrêmement limitées'] },
    { id: 30, title: 'Responsabilités détection', description: 'Détection', compliance: 'Non Conforme', keyIssues: [] },
    { id: 32, title: 'Transferts de fonds', description: 'Statistiques', compliance: 'Largement Non Conforme', keyIssues: [] },
    { id: 33, title: 'Statistiques enquêtes', description: 'Données statistiques', compliance: 'Largement Non Conforme', keyIssues: [] },
    { id: 34, title: 'Échange d\'informations', description: 'Coopération', compliance: 'Non Conforme', keyIssues: [] },
    { id: 35, title: 'Sanctions', description: 'Sanctions', compliance: 'Largement Non Conforme', keyIssues: ['Aucune sanction appliquée'] },
    { id: 36, title: 'Organismes internationaux', description: 'Instruments internationaux', compliance: 'Conforme', keyIssues: [] },
    { id: 37, title: 'Assistance juridique', description: 'Entraide', compliance: 'Non Conforme', keyIssues: [] },
    { id: 38, title: 'Entraide FT', description: 'Coopération FT', compliance: 'Non Conforme', keyIssues: [] },
    { id: 39, title: 'Extradition', description: 'Extradition', compliance: 'Non Conforme', keyIssues: [] },
    { id: 40, title: 'Autres coopération', description: 'Coopération', compliance: 'Partiellement Conforme', keyIssues: [] },
  ],
  immediateResults: [
    { id: 1, title: 'Compréhension des risques', shortTitle: 'Risques', description: 'Risques BLT/FT', effectiveness: 'Faible', fundamental: true },
    { id: 2, title: 'Coopération internationale', shortTitle: 'Coopération', description: 'Coopération', effectiveness: 'Faible', fundamental: true },
    { id: 3, title: 'Supervision', shortTitle: 'Supervision', description: 'Supervision', effectiveness: 'Faible', fundamental: true },
    { id: 4, title: 'Prévention', shortTitle: 'Prévention', description: 'Prévention', effectiveness: 'Faible', fundamental: true },
    { id: 5, title: 'Détection', shortTitle: 'Détection', description: 'Détection', effectiveness: 'Faible', fundamental: true },
    { id: 6, title: 'Poursuites', shortTitle: 'Poursuites', description: 'Poursuites', effectiveness: 'Faible', fundamental: true },
    { id: 7, title: 'Confiscation', shortTitle: 'Confiscation', description: 'Confiscation', effectiveness: 'Faible', fundamental: true },
    { id: 8, title: 'Victimes', shortTitle: 'Victimes', description: 'Victimes', effectiveness: 'Faible', fundamental: false },
    { id: 9, title: 'Transparence', shortTitle: 'Transparence', description: 'Transparence', effectiveness: 'Faible', fundamental: true },
    { id: 10, title: 'Résultats', shortTitle: 'Résultats', description: 'Résultats', effectiveness: 'Faible', fundamental: true },
    { id: 11, title: 'Sanctions', shortTitle: 'Sanctions', description: 'Sanctions', effectiveness: 'Faible', fundamental: true },
  ],
  summary: {
    technicalComplianceScore: 45,
    effectivenessScore: 28,
    strengths: [
      'Adhésion formelle aux conventions internationales',
      'Infractions de blanchiment et FT inscrites au code pénal',
    ],
    areasForImprovement: [
      'Quasi-totalité du cadre à revoir',
      'Ressources humaines et financières très insuffisantes',
      'Instabilité politique impactant la gouvernance',
      'Absence de supervision effective',
      'Système de sanctions inexistant',
    ],
    highRiskAreas: [
      'Terrorisme et groupes armés',
      'Transferts informels massifs',
      'Contrebande et trafic',
      'Secteur extractif non régulé',
      'Corruption endémique',
    ],
  },
};

// All countries
export const countries: CountryEvaluation[] = [coteDIvoire, senegal, maroc, cameroun, mali];

export function getCountryByCode(code: string): CountryEvaluation | undefined {
  return countries.find(c => c.code === code);
}

export function getCountryByIndex(index: number): CountryEvaluation | undefined {
  return countries[index];
}

export const complianceLevels: ComplianceLevel[] = ['Conforme', 'Partiellement Conforme', 'Non Conforme', 'Largement Non Conforme'];
export const effectivenessLevels: EffectivenessLevel[] = ['Remarquable', 'Substantiel', 'Modéré', 'Faible'];

export { complianceScore, effectivenessScore };