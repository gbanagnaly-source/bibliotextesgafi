// GAFI Knowledge Base — descriptions des 40 Recommandations et 11 Résultats Immédiats
// Contenu conforme aux 40 Recommandations consolidées du GAFI (2023)
// et aux Lignes Directrices sur les données et statistiques LBC/FT (2015)

export interface RecommandationInfo {
  id: number;
  title: string;
  fullTitle: string;
  description: string;
  keyCriteria: string[];
  statisticsIndicators: string[];
}

export interface ResultatImmédiatInfo {
  id: number;
  title: string;
  shortTitle: string;
  description: string;
  keyQuestions: string[];
  statisticsIndicators: string[];
  fundamental: boolean;
}

export const RECOMMANDATIONS: RecommandationInfo[] = [
  {
    id: 1,
    title: 'Évaluation des risques et application d\'une approche fondée sur les risques',
    fullTitle: 'Évaluation des risques et application d\'une approche fondée sur les risques',
    description: 'Les pays devraient identifier, évaluer et comprendre les risques de blanchiment de capitaux (BC) et de financement du terrorisme (FT) auxquels ils sont exposés, ainsi que les risques de financement de la prolifération (FP). Sur la base de cette évaluation, les pays devraient adopter une approche fondée sur les risques (AFR) pour garantir que les mesures adoptées soient proportionnées aux risques identifiés. Les pays doivent régulièrement réévaluer les risques et les réviser en fonction de l\'évolution du contexte national et international.',
    keyCriteria: [
      'Identification et évaluation des risques de BC/FT/FP au niveau national',
      'Désignation d\'une autorité ou d\'un mécanisme de coordination compétent',
      'Application d\'une approche fondée sur les risques (AFR) à tous les niveaux',
      'Réévaluation régulière des risques (au minimum annuelle)',
      'Diffusion des résultats de l\'évaluation aux autorités compétentes et aux entités assujetties',
    ],
    statisticsIndicators: [
      'Nombre et types de risques identifiés dans l\'évaluation nationale',
      'Fréquence de mise à jour de l\'évaluation nationale des risques (ENR)',
      'Nombre de secteurs couverts par l\'ENR',
      'Nombre de rapports de typologie produits sur la base de l\'ENR',
    ],
  },

  {
    id: 2,
    title: 'Coopération et coordination nationales',
    fullTitle: 'Coopération et coordination nationales',
    description: 'Les pays devraient mettre en place des mécanismes de coopération et de coordination entre les autorités compétentes en matière de LBC/FT/FP au niveau national. Une coopération efficace entre les autorités de poursuite pénale, les autorités de surveillance prudentielle, les cellules de renseignement financier (CRF) et les autorités douanières est essentielle pour lutter efficacement contre le BC, le FT et la FP.',
    keyCriteria: [
      'Mise en place d\'un comité ou mécanisme national de coordination LBC/FT',
      'Désignation d\'un point de contact central pour la coopération internationale',
      'Coopération opérationnelle entre toutes les autorités compétentes',
      'Échange régulier d\'informations entre les autorités (CRF, parquets, douanes, superviseurs)',
      'Coordination des politiques et stratégies nationales de lutte contre BC/FT/FP',
    ],
    statisticsIndicators: [
      'Nombre de réunions du comité national de coordination par an',
      'Nombre de demandes d\'entraide internationale reçues et envoyées',
      'Nombre de cas de BC/FT traités en coordination multi-agences',
    ],
  },

  {
    id: 3,
    title: 'Infraction de blanchiment de capitaux',
    fullTitle: 'Infraction de blanchiment de capitaux',
    description: 'Les pays devraient incriminer le blanchiment de capitaux en tant qu\'infraction autonome. Le blanchiment doit couvrir les actes de conversion, de transfert, de dissimulation et de masquage de la nature, de l\'origine, de l\'emplacement, de la disposition, du mouvement ou de la propriété de biens, sachant qu\'ils proviennent d\'un crime. Les pays doivent aussi incriminer la tentative, la complicité et la participation.',
    keyCriteria: [
      'Incrimination du blanchiment comme infraction principale et autonome',
      'Couverture de tous les actes de blanchiment (dissimulation, conversion, transfert, détention)',
      'Application aux produits de toutes les infractions graves (infraction pénale principale)',
      'Possibilité de poursuivre lorsque l\'infraction sous-jacente est commise à l\'étranger',
      'Responsabilité pénale des personnes physiques (intentions, tentative, complicité)',
    ],
    statisticsIndicators: [
      'Nombre de poursuites pour blanchiment de capitaux',
      'Nombre de condamnations pour blanchiment de capitaux',
      'Montant total des avoirs confisqués liés au blanchiment',
    ],
  },

  {
    id: 4,
    title: 'Confiscation et mesures provisoires',
    fullTitle: 'Confiscation et mesures provisoires',
    description: 'Les pays devraient adopter des mesures semblables à celles énoncées dans la Convention de Vienne et la Convention de Palerme, y compris des mesures de confiscation et de gel provisoire. Les mesures doivent permettre la confiscation de produits, d\'instruments et de biens de remplacement d\'une valeur équivalente. La confiscation doit être possible sans condamnation pénale préalable (confiscation en valeur) dans les cas où le bien ne peut être saisi.',
    keyCriteria: [
      'Pouvoir de confiscation des produits du crime et des instruments',
      'Mesures provisoires (gel/saisie) pour empêcher le transfert ou la dissipation des biens',
      'Confiscation de biens de remplacement d\'une valeur équivalente',
      'Possibilité de confiscation sans condamnation préalable (confiscation en valeur)',
      'Gestion et disposition des biens confisqués',
    ],
    statisticsIndicators: [
      'Valeur totale des biens confisqués',
      'Valeur des biens gelés/faisant l\'objet de mesures provisoires',
      'Taux de confiscation effective par rapport aux biens identifiés',
    ],
  },

  {
    id: 5,
    title: 'Infraction de financement du terrorisme',
    fullTitle: 'Infraction de financement du terrorisme',
    description: 'Les pays devraient incriminer le financement du terrorisme conformément à la Convention internationale pour la répression du financement du terrorisme (1999). L\'infraction doit couvrir la collecte et la fourniture de fonds ou d\'autres actifs dans l\'intention de les utiliser ou en sachant qu\'ils seront utilisés pour commettre des actes de terrorisme. Les pays doivent aussi incriminer la tentative, la complicité et la participation.',
    keyCriteria: [
      'Incrimination du financement du terrorisme (collecte et fourniture)',
      'Couverture de tous les actes terroristes visés par les conventions internationales',
      'Incrimination de la tentative, de la complicité et de la participation',
      'Possibilité de poursuite même si l\'acte terroriste n\'est pas commis ou échoue',
      'Déconnexion entre l\'infraction de FT et l\'infraction terroriste sous-jacente',
    ],
    statisticsIndicators: [
      'Nombre de poursuites pour financement du terrorisme',
      'Nombre de condamnations pour financement du terrorisme',
      'Montant des avoirs liés au FT gelés et confisqués',
    ],
  },

  {
    id: 6,
    title: 'Sanctions financières ciblées liées au terrorisme et au financement du terrorisme',
    fullTitle: 'Sanctions financières ciblées liées au terrorisme et au financement du terrorisme',
    description: 'Les pays doivent mettre en oeuvre des mesures de gel sans délai des fonds ou autres actifs des personnes et entités désignées conformément aux résolutions du Conseil de sécurité de l\'ONU relatives au terrorisme. Les pays doivent également disposer de mécanismes efficaces pour le gel des avoirs sur la base de désignations nationales, dans le respect des garanties procédurales appropriées.',
    keyCriteria: [
      'Gel sans délai des fonds des personnes/entités désignées par l\'ONU pour le terrorisme',
      'Mise en oeuvre effective des résolutions 1267, 1373 et ultérieures',
      'Mécanismes de gel sur la base de désignations nationales',
      'Garanties procédurales appropriées (dégel, recours)',
      'Capacité de gérer et de disposer des avoirs gelés',
    ],
    statisticsIndicators: [
      'Montant total des avoirs gelés liés au terrorisme',
      'Nombre de personnes/entités sur les listes nationales de gel (terrorisme)',
      'Délai moyen entre la désignation et l\'effectivité du gel',
    ],
  },

  {
    id: 7,
    title: 'Sanctions financières ciblées liées à la prolifération',
    fullTitle: 'Sanctions financières ciblées liées à la prolifération',
    description: 'Les pays doivent mettre en oeuvre des mesures de gel sans délai des fonds ou autres actifs des personnes et entités désignées conformément aux résolutions du Conseil de sécurité de l\'ONU relatives à la prolifération des armes de destruction massive. Les institutions financières doivent vérifier systématiquement les transactions et les relations d\'affaires contre les listes de sanctions de la prolifération.',
    keyCriteria: [
      'Gel sans délai des fonds liés à la prolifération (résolutions 1718, 1737, etc.)',
      'Vérification systématique des transactions contre les listes de sanctions de l\'ONU',
      'Mise à jour rapide des listes de sanctions et diffusion aux entités assujetties',
      'Inspections et contrôles pour vérifier la conformité des institutions financières',
      'Sanctions effectives en cas de violation des mesures de gel liées à la prolifération',
    ],
    statisticsIndicators: [
      'Montant des avoirs gelés liés à la prolifération',
      'Nombre de vérifications effectuées contre les listes ONU de prolifération',
      'Nombre de violations des sanctions de prolifération détectées et poursuivies',
    ],
  },

  {
    id: 8,
    title: 'Organismes à but non lucratif',
    fullTitle: 'Organismes à but non lucratif',
    description: 'Les pays devraient examiner les vulnérabilités des organismes à but non lucratif (OBNL) face à un abus à des fins de financement du terrorisme. Les pays devraient appliquer des mesures ciblées et proportionnées, conformément à l\'approche fondée sur les risques, aux OBNL identifiés comme étant vulnérables, sans entraver de manière disproportionnée les activités légitimes de ces organismes.',
    keyCriteria: [
      'Identification et évaluation des vulnérabilités des OBNL face à l\'abus à des fins de FT',
      'Application de mesures ciblées et proportionnées aux OBNL vulnérables',
      'Absence d\'entrave disproportionnée aux activités légitimes des OBNL',
      'Coopération entre les autorités compétentes et les organisations faîtières d\'OBNL',
      'Surveillance et contrôle des flux financiers des OBNL à risque',
    ],
    statisticsIndicators: [
      'Nombre d\'OBNL enregistrés et évalués pour les risques de FT',
      'Nombre d\'OBNL soumis à des mesures renforcées',
      'Nombre de cas d\'abus d\'OBNL détectés et signalés',
    ],
  },

  {
    id: 9,
    title: 'Lois sur le secret professionnel des institutions financières',
    fullTitle: 'Lois sur le secret professionnel des institutions financières',
    description: 'Les pays doivent veiller à ce que les obligations de secret professionnel n\'empêchent pas les institutions financières de déclarer les opérations suspectes à la cellule de renseignement financier (CRF). Si une institution financière fait une déclaration de soupçon en bonne foi, elle doit être protégée par la loi contre toute responsabilité civile ou pénale pour violation du secret professionnel.',
    keyCriteria: [
      'Protection légale des déclarants contre les poursuites pour violation du secret professionnel',
      'Clarté des dispositions permettant de surmonter les obligations de confidentialité',
      'Absence de responsabilité civile ou pénale pour les déclarations de bonne foi',
      'Information aux institutions financières sur leurs obligations de déclaration',
      'Mécanismes de protection contre les représailles à l\'égard des déclarants',
    ],
    statisticsIndicators: [
      'Nombre de cas de protection invoquée par les déclarants',
      'Nombre de poursuites évitées grâce à la protection légale',
      'Taux de conformité des institutions financières aux obligations de déclaration',
    ],
  },

  {
    id: 10,
    title: 'Devoir de vigilance relatif à la clientèle',
    fullTitle: 'Devoir de vigilance relatif à la clientèle',
    description: 'Les institutions financières doivent appliquer des mesures de diligence à la clientèle (DEC) lorsqu\'elles établissent des relations d\'affaires, effectuent des transactions occasionnelles dépassant les seuils définis, ou lorsqu\'elles soupçonnent des opérations de BC/FT. La DEC comprend l\'identification du client, la vérification de son identité, l\'identification du bénéficiaire effectif, et la détermination de l\'objet et de la nature de la relation d\'affaires.',
    keyCriteria: [
      'Identification et vérification de l\'identité du client',
      'Identification et vérification du bénéficiaire effectif',
      'Détermination de l\'objet et de la nature de la relation d\'affaires',
      'Conduite d\'une diligence raisonnable continue sur la relation d\'affaires',
      'Application de mesures simplifiées, ordinaires ou renforcées selon le niveau de risque',
    ],
    statisticsIndicators: [
      'Nombre de relations d\'affaires avec DEC complète',
      'Taux de vérification des bénéficiaires effectifs',
      'Nombre de relations d\'affaires refusées ou clôturées pour risque LBC/FT',
    ],
  },

  {
    id: 11,
    title: 'Conservation des documents',
    fullTitle: 'Conservation des documents',
    description: 'Les institutions financières doivent conserver des registres complets et suffisants sur toutes les transactions, nationales et internationales, pendant au minimum cinq ans. Ces registres doivent être suffisamment détaillés pour permettre la reconstruction de transactions individuelles, de déterminer si une déclaration de soupçon est nécessaire, et de fournir des preuves en cas de poursuites pénales.',
    keyCriteria: [
      'Conservation des registres de transactions pendant au minimum 5 ans',
      'Registres suffisamment détaillés pour reconstruire les transactions',
      'Conservation des pièces justificatives de la diligence à la clientèle (DEC)',
      'Accessibilité des registres aux autorités compétentes sur demande',
      'Mesures de sécurité pour la conservation électronique des données',
    ],
    statisticsIndicators: [
      'Durée moyenne de conservation effective des registres',
      'Nombre d\'audits de registres réalisés par les superviseurs',
      'Pourcentage d\'entités conformes aux exigences de conservation',
    ],
  },

  {
    id: 12,
    title: 'Personnes politiquement exposées',
    fullTitle: 'Personnes politiquement exposées',
    description: 'Les institutions financières doivent appliquer des mesures de diligence renforcées à l\'égard des personnes politiquement exposées (PPE), tant nationales qu\'étrangères, ainsi qu\'à l\'égard de leurs familiaux et de leurs proches associés. Les mesures doivent comprendre l\'obtention d\'une autorisation de haut niveau pour établir la relation d\'affaires, la détermination de l\'origine des fonds et une surveillance continue renforcée.',
    keyCriteria: [
      'Identification des PPE nationales, étrangères et des organisations internationales',
      'Application de mesures de diligence renforcées (DRE) aux PPE et à leur entourage',
      'Obtention d\'une autorisation de haut niveau pour les relations d\'affaires avec les PPE',
      'Détermination de l\'origine des fonds et de la source de la richesse',
      'Surveillance continue et renforcée de la relation d\'affaires',
    ],
    statisticsIndicators: [
      'Nombre de relations d\'affaires avec des PPE identifiées',
      'Nombre de déclarations de soupçon liées à des PPE',
      'Taux de mise en oeuvre de la DRE pour les relations PPE',
    ],
  },

  {
    id: 13,
    title: 'Correspondance bancaire',
    fullTitle: 'Correspondance bancaire',
    description: 'Les institutions financières doivent appliquer des mesures de diligence à la clientèle renforcées lorsqu\'elles entretiennent des relations de correspondance bancaire transfrontalière avec d\'autres institutions financières. Elles doivent notamment s\'assurer que l\'institution correspondante dispose de mesures LBC/FT adéquates, recueillir des informations suffisantes sur la nature de l\'activité de l\'institution, et documenter les responsabilités respectives de chaque institution.',
    keyCriteria: [
      'Évaluation préalable de la réputation et du cadre LBC/FT de la banque correspondante',
      'Documentation écrite des responsabilités de chaque partie',
      'Évaluation des contrôles anti-blanchiment de la banque correspondante',
      'Obligation d\'obtenir des informations avant d\'ouvrir le compte de correspondant',
      'Possibilité de refuser ou de mettre fin à la relation de correspondance si nécessaire',
    ],
    statisticsIndicators: [
      'Nombre de relations de correspondant bancaire actives',
      'Nombre d\'évaluations de diligence réalisées sur les correspondants',
      'Nombre de relations de correspondant clôturées pour raisons LBC/FT',
    ],
  },

  {
    id: 14,
    title: 'Services de transfert de fonds ou de valeurs',
    fullTitle: 'Services de transfert de fonds ou de valeurs',
    description: 'Les pays doivent veiller à ce que les prestataires de services de transfert de fonds ou de valeurs soient soumis à la réglementation ou à l\'enregistrement, et soient effectivement contrôlés ou surveillés. Les transferts doivent inclure des informations exactes sur l\'expéditeur et le bénéficiaire, transmises tout au long de la chaîne de paiement.',
    keyCriteria: [
      'Enregistrement ou agrément obligatoire des prestataires de services de transfert de fonds',
      'Inclusion des informations sur l\'expéditeur dans le transfert',
      'Transmission des informations tout au long de la chaîne de paiement',
      'Mesures de contrôle des transferts transfrontaliers d\'espèces',
      'Possibilité de bloquer ou d\'intercepter les transferts suspects',
    ],
    statisticsIndicators: [
      'Volume des transferts transfrontaliers traités',
      'Nombre de prestataires de services de transfert enregistrés/surveillés',
      'Nombre de transferts interceptés ou bloqués pour suspicion LBC/FT',
    ],
  },

  {
    id: 15,
    title: 'Nouvelles technologies',
    fullTitle: 'Nouvelles technologies',
    description: 'Les pays et les institutions financières doivent identifier et évaluer les risques de BC/FT liés au développement de nouveaux produits, de nouvelles pratiques commerciales, de l\'utilisation de nouvelles technologies et de la livraison de nouveaux services. Ils doivent prendre les mesures appropriées pour atténuer ces risques avant le lancement de ces produits ou services. Cela inclut les crypto-actifs et les technologies de chaîne de blocs.',
    keyCriteria: [
      'Évaluation des risques LBC/FT liés aux nouveaux produits et technologies',
      'Mesures d\'atténuation mises en place avant le lancement de nouveaux services',
      'Réglementation applicable aux prestataires de services sur crypto-actifs (PSAV)',
      'Obligation de licence/enregistrement pour les PSAV',
      'Coopération internationale sur les risques liés aux crypto-actifs',
    ],
    statisticsIndicators: [
      'Nombre de PSAV enregistrés/autorisés',
      'Nombre de déclarations de soupçon liées aux crypto-actifs',
      'Volume de transactions en crypto-actifs déclarées',
    ],
  },

  {
    id: 16,
    title: 'Virements électroniques',
    fullTitle: 'Virements électroniques',
    description: 'Les pays doivent veiller à ce que les institutions financières incluent des informations requises sur l\'expéditeur et le bénéficiaire dans les virements électroniques et les messages qui les accompagnent. Ces informations doivent accompagner le virement tout au long de la chaîne de paiement et être disponibles aux autorités compétentes. Les virements électroniques sans informations complètes doivent être rejetés ou soumis à un examen approfondi.',
    keyCriteria: [
      'Inclusion du nom, numéro de compte et adresse de l\'expéditeur',
      'Inclusion du nom et numéro de compte du bénéficiaire',
      'Transmission des informations à travers toute la chaîne de paiement',
      'Rejet ou examen approfondi des virements sans informations complètes',
      'Exigences de dépistage contre les listes de sanctions',
    ],
    statisticsIndicators: [
      'Volume total des virements électroniques (montant et nombre)',
      'Taux de virements avec informations complètes sur l\'expéditeur',
      'Nombre de virements suspendus ou rejetés pour informations incomplètes',
    ],
  },

  {
    id: 17,
    title: 'Recours à des tiers',
    fullTitle: 'Recours à des tiers',
    description: 'Les institutions financières peuvent recourir à des tiers pour effectuer des éléments des mesures de diligence à la clientèle (identification, vérification), sous réserve de critères stricts. L\'institution financière reste pleinement responsable des mesures de DEC effectuées par le tiers. Les pays doivent veiller à ce que les tiers soient soumis à une réglementation et une supervision adéquates.',
    keyCriteria: [
      'Responsabilité pleine et entière de l\'institution pour les DEC effectuées par des tiers',
      'Agrément ou supervision des tiers effectuant des mesures de DEC',
      'Accès immédiat aux informations détenues par le tiers sur demande',
      'Contrats ou accords écrits entre l\'institution et le tiers',
      'Vérification de la conformité du tiers aux normes LBC/FT',
    ],
    statisticsIndicators: [
      'Nombre de tiers utilisés pour les mesures de DEC',
      'Taux de conformité des contrats avec les tiers aux exigences réglementaires',
      'Nombre d\'audits réalisés sur les tiers prestataires de DEC',
    ],
  },

  {
    id: 18,
    title: 'Contrôles internes et succursales et filiales à l\'étranger',
    fullTitle: 'Contrôles internes et succursales et filiales à l\'étranger',
    description: 'Les institutions financières doivent être soumises à une réglementation et une supervision adéquates. Elles doivent mettre en place des programmes de conformité LBC/FT incluant des contrôles internes, la désignation d\'un responsable de la conformité à un niveau de direction approprié, des procédures de sélection et de formation du personnel, ainsi que des mécanismes d\'audit indépendant. Des normes équivalentes doivent s\'appliquer aux succursales et filiales étrangères.',
    keyCriteria: [
      'Programme de conformité LBC/FT documenté et approuvé par la direction',
      'Désignation d\'un responsable de la conformité à un niveau de direction senior',
      'Audit interne indépendant des mesures LBC/FT',
      'Formation continue du personnel à tous les niveaux',
      'Application de normes LBC/FT équivalentes aux succursales et filiales étrangères',
    ],
    statisticsIndicators: [
      'Pourcentage d\'établissements disposant d\'un programme de conformité documenté',
      'Nombre d\'audits internes LBC/FT réalisés',
      'Taux de formation du personnel (pourcentage d\'employés formés)',
    ],
  },

  {
    id: 19,
    title: 'Pays présentant un risque plus élevé',
    fullTitle: 'Pays présentant un risque plus élevé',
    description: 'Les pays doivent exiger des institutions financières qu\'elles appliquent des mesures de diligence renforcées à l\'égard des relations d\'affaires et des transactions impliquant des pays ou territoires à haut risque identifiés par le GAFI. Ces mesures incluent l\'obtention d\'informations supplémentaires sur le client et la transaction, une surveillance renforcée et l\'obtention de l\'approbation de la haute direction.',
    keyCriteria: [
      'Liste publique des pays et territoires à haut risque (listes GAFI)',
      'Mesures de diligence renforcées obligatoires pour les pays à haut risque',
      'Contre-mesures pour les pays identifiés par le GAFI comme présentant des carences stratégiques',
      'Information des institutions financières sur les listes mises à jour',
      'Surveillance et contrôle du respect des obligations renforcées',
    ],
    statisticsIndicators: [
      'Nombre de relations d\'affaires avec des pays à haut risque identifiés',
      'Nombre de transactions soumises à des mesures renforcées',
      'Nombre de relations clôturées en raison du risque pays',
    ],
  },

  {
    id: 20,
    title: 'Déclaration des opérations suspectes',
    fullTitle: 'Déclaration des opérations suspectes',
    description: 'Les institutions financières et les entités assujetties doivent déclarer à la cellule de renseignement financier (CRF) les opérations suspectes lorsqu\'elles ont des motifs raisonnables de soupçonner que les fonds proviennent d\'une activité criminelle ou sont liés au financement du terrorisme. La déclaration doit être effectuée promptement et ne doit pas révéler au client l\'existence de la déclaration (interdiction de \'tipping off\').',
    keyCriteria: [
      'Obligation de déclaration des opérations suspectes à la CRF',
      'Protection contre la divulgation (\'tipping off\') au client',
      'Formation du personnel pour identifier les opérations suspectes',
      'Déclarations basées sur les indicateurs de risques et les typologies',
      'Système de filtrage des transactions contre les listes de sanctions',
    ],
    statisticsIndicators: [
      'Nombre de déclarations de soupçon (DS) reçues par la CRF',
      'Délai moyen entre la détection et la déclaration',
      'Taux de DS donnant lieu à des enquêtes',
      'Nombre d\'établissements déclarants actifs',
    ],
  },

  {
    id: 21,
    title: 'Divulgation et confidentialité',
    fullTitle: 'Divulgation et confidentialité',
    description: 'Les institutions financières, leurs dirigeants et employés doivent être protégés par la loi contre toute responsabilité civile ou pénale pour avoir effectué de bonne foi des déclarations de soupçon à la CRF, même si elles s\'avèrent infondées. Les pays doivent interdire la divulgation (\'tipping off\') au client concerné ou à des tiers que des informations ont été transmises à la CRF.',
    keyCriteria: [
      'Protection légale complète des déclarants de bonne foi contre toute responsabilité',
      'Interdiction légale du \'tipping off\' (divulgation au client de la déclaration)',
      'Protection contre les représailles professionnelles à l\'égard des déclarants',
      'Étendue de la protection aux dirigeants et employés des entités assujetties',
      'Mécanismes de mise en oeuvre effective de la protection légale',
    ],
    statisticsIndicators: [
      'Nombre de cas de protection invoquée par les déclarants',
      'Nombre de poursuites évitées grâce à la protection légale',
      'Nombre de cas de \'tipping off\' détectés et poursuivis',
    ],
  },

  {
    id: 22,
    title: 'Entreprises et professions non financières désignées – Devoir de vigilance relatif à la clientèle',
    fullTitle: 'Entreprises et professions non financières désignées – Devoir de vigilance relatif à la clientèle',
    description: 'Les entreprises et professions non financières désignées (EPNFD) telles que les casinos, les agents immobiliers, les négociants en métaux précieux et pierres précieuses, les avocats, notaires, comptables et autres professionnels du droit doivent être soumis à des obligations de diligence à la clientèle adaptées à leur niveau de risque lorsqu\'ils participent à des transactions financières au nom de leurs clients.',
    keyCriteria: [
      'Définition claire du périmètre des obligations de DEC pour les EPNFD',
      'Application de la diligence à la clientèle pour les transactions financières',
      'Obligation de déclaration de soupçon par les EPNFD',
      'Formation continue sur les risques LBC/FT spécifiques aux professions',
      'Supervision et contrôle effectif par un organe professionnel ou une autorité compétente',
    ],
    statisticsIndicators: [
      'Nombre de professionnels et EPNFD soumis aux obligations de DEC',
      'Nombre de DS émises par les EPNFD soumises à la DEC',
      'Taux de conformité aux obligations de diligence des EPNFD',
    ],
  },

  {
    id: 23,
    title: 'Entreprises et professions non financières désignées – Autres mesures',
    fullTitle: 'Entreprises et professions non financières désignées – Autres mesures',
    description: 'Les autres professions non financières désignées (EPNFD) qui ne sont pas soumises au devoir de vigilance relatif à la clientèle doivent néanmoins être soumises à des obligations LBC/FT adaptées, notamment la déclaration des opérations suspectes. Les pays doivent veiller à ce que ces professions soient effectivement contrôlées ou surveillées par une autorité compétente.',
    keyCriteria: [
      'Identification de toutes les EPNFD soumises aux obligations LBC/FT',
      'Application de l\'obligation de déclaration de soupçon pour les EPNFD',
      'Conservation des registres et documents pertinents',
      'Supervision et contrôle effectif par une autorité compétente',
      'Formation continue du personnel sur les risques LBC/FT',
    ],
    statisticsIndicators: [
      'Nombre d\'EPNFD enregistrées et soumises aux obligations LBC/FT',
      'Nombre de DS émises par les EPNFD non soumises à la DEC',
      'Taux de couverture sectoriel par les programmes de supervision',
    ],
  },

  {
    id: 24,
    title: 'Transparence et bénéficiaires effectifs des personnes morales',
    fullTitle: 'Transparence et bénéficiaires effectifs des personnes morales',
    description: 'Les pays devraient prendre des mesures pour empêcher l\'utilisation abusive des personnes morales pour le blanchiment de capitaux. Des informations adéquates, exactes et actualisées sur les bénéficiaires effectifs et les structures de propriété et de contrôle doivent être disponibles aux autorités compétentes de manière opportune. Les pays devraient mettre en place des registres de bénéficiaires effectifs ou des mécanismes équivalents.',
    keyCriteria: [
      'Obligation pour les personnes morales de connaître et conserver les informations sur les bénéficiaires effectifs',
      'Mise en place de registres de bénéficiaires effectifs accessibles aux autorités',
      'Disponibilité des informations pour les autorités compétentes de manière opportune',
      'Mesures de vérification de l\'exactitude des informations déclarées',
      'Sanctions en cas de non-respect des obligations de transparence',
    ],
    statisticsIndicators: [
      'Taux de personnes morales enregistrées disposant d\'informations de bénéficiaires effectifs',
      'Nombre de demandes d\'accès aux informations par les autorités compétentes',
      'Pourcentage de vérifications effectuées sur les déclarations de bénéficiaires effectifs',
    ],
  },

  {
    id: 25,
    title: 'Transparence et bénéficiaires effectifs des constructions juridiques',
    fullTitle: 'Transparence et bénéficiaires effectifs des constructions juridiques',
    description: 'Les pays devraient prendre des mesures pour empêcher l\'utilisation abusive des constructions juridiques (tels que les fiducies, les fondations et autres structures similaires) pour le blanchiment de capitaux. Des informations adéquates sur le constituant, le trustee, le protecteur, les bénéficiaires ou toute autre personne physique détenant le contrôle doivent être disponibles aux autorités compétentes.',
    keyCriteria: [
      'Identification du constituant, du trustee, du protecteur et des bénéficiaires',
      'Conservation d\'informations adéquates et à jour sur les constructions juridiques',
      'Disponibilité des informations pour les autorités compétentes',
      'Mesures pour empêcher l\'utilisation abusive des fiducies et fondations',
      'Obligations de transparence applicables aux trustees et aux gestionnaires de trusts',
    ],
    statisticsIndicators: [
      'Nombre de constructions juridiques enregistrées dans le pays',
      'Taux de constructions juridiques disposant d\'informations de transparence complètes',
      'Nombre de demandes d\'informations sur les constructions juridiques par les autorités',
    ],
  },

  {
    id: 26,
    title: 'Réglementation et contrôle des institutions financières',
    fullTitle: 'Réglementation et contrôle des institutions financières',
    description: 'Les autorités de contrôle et de surveillance doivent avoir des pouvoirs adéquats pour superviser et surveiller le respect des exigences LBC/FT par les institutions financières. Elles doivent disposer de pouvoirs d\'enquête, de sanction et de révocation d\'agrément. La supervision doit être basée sur les risques et couvrir tous les secteurs soumis aux obligations LBC/FT.',
    keyCriteria: [
      'Pouvoirs adéquats de supervision et de surveillance LBC/FT des institutions financières',
      'Pouvoirs d\'enquête et de sanction effectifs',
      'Possibilité de révoquer ou suspendre les agréments et licences',
      'Supervision fondée sur les risques (SFR)',
      'Ressources humaines et techniques suffisantes pour assurer la supervision',
    ],
    statisticsIndicators: [
      'Nombre d\'inspections et de contrôles sur site réalisés',
      'Nombre de sanctions administratives et pécuniaires infligées',
      'Taux de couverture sectorielle par les programmes de supervision',
    ],
  },

  {
    id: 27,
    title: 'Pouvoirs des autorités de contrôle',
    fullTitle: 'Pouvoirs des autorités de contrôle',
    description: 'Les autorités de contrôle doivent disposer de pouvoirs de supervision étendus pour surveiller le respect des obligations LBC/FT. Ces pouvoirs doivent inclure la capacité de contraindre les institutions financières à fournir toutes les informations nécessaires, de réaliser des inspections sur place, de prélever des échantillons de données et de prendre des mesures de sanction effectives et proportionnées en cas de non-conformité.',
    keyCriteria: [
      'Pouvoirs d\'inspection sur place et hors site',
      'Capacité à contraindre la production de documents et d\'informations',
      'Pouvoirs de sanction administrative et pécuniaire effectifs',
      'Possibilité de suspendre ou révoquer les agréments',
      'Mécanismes de recours et de sauvegarde des droits des entités contrôlées',
    ],
    statisticsIndicators: [
      'Nombre d\'inspections sur site par an',
      'Montant total des sanctions pécuniaires infligées',
      'Nombre d\'agréments suspendus ou révoqués pour non-conformité LBC/FT',
    ],
  },

  {
    id: 28,
    title: 'Réglementation et contrôle des entreprises et professions non financières désignées',
    fullTitle: 'Réglementation et contrôle des entreprises et professions non financières désignées',
    description: 'Les autorités compétentes doivent superviser et surveiller efficacement le respect des obligations LBC/FT par les entreprises et professions non financières désignées (EPNFD). La supervision doit être fondée sur les risques et les autorités doivent disposer de pouvoirs de sanction adéquats pour garantir la conformité effective.',
    keyCriteria: [
      'Désignation d\'autorités compétentes pour la supervision des EPNFD',
      'Pouvoirs de supervision et de contrôle adéquats sur les EPNFD',
      'Supervision fondée sur les risques (SFR) des EPNFD',
      'Pouvoirs de sanction effectifs en cas de non-conformité',
      'Ressources suffisantes pour assurer une supervision efficace des EPNFD',
    ],
    statisticsIndicators: [
      'Nombre d\'inspections d\'EPNFD réalisées par an',
      'Nombre de sanctions infligées aux EPNFD pour non-conformité LBC/FT',
      'Taux de couverture sectorielle par les programmes de supervision des EPNFD',
    ],
  },

  {
    id: 29,
    title: 'Cellules de renseignements financiers',
    fullTitle: 'Cellules de renseignements financiers',
    description: 'Les pays doivent mettre en place une cellule de renseignements financiers (CRF) qui fonctionne comme un centre national de réception, d\'analyse et de transmission des déclarations de soupçon (DS) et d\'autres informations pertinentes concernant les potentiels blanchiments de capitaux, financements du terrorisme et de la prolifération. La CRF doit avoir accès, directement ou indirectement, aux informations financières, administratives et opérationnelles nécessaires.',
    keyCriteria: [
      'Existence d\'une CRF opérationnelle comme centre national de réception et d\'analyse des DS',
      'Accès de la CRF aux informations financières, administratives et opérationnelles nécessaires',
      'Indépendance opérationnelle de la CRF',
      'Capacité d\'analyse opérationnelle et stratégique de la CRF',
      'Coopération efficace de la CRF avec les autorités de poursuite et les CRF étrangères',
    ],
    statisticsIndicators: [
      'Nombre de DS reçues par la CRF',
      'Délai moyen d\'analyse des DS',
      'Taux de DS transmises aux autorités de poursuite',
      'Nombre de rapports d\'analyse stratégique produits',
    ],
  },

  {
    id: 30,
    title: 'Responsabilités des autorités de poursuite pénale et des autorités chargées des enquêtes',
    fullTitle: 'Responsabilités des autorités de poursuite pénale et des autorités chargées des enquêtes',
    description: 'Les pays doivent veiller à ce que les autorités de poursuite pénale et les autorités chargées des enquêtes disposent des responsabilités, des pouvoirs et des ressources nécessaires pour mener des enquêtes et des poursuites efficaces en matière de BC/FT/FP. Les autorités compétentes doivent pouvoir enquêter, identifier et traquer les produits du crime, geler et confisquer les avoirs illicites.',
    keyCriteria: [
      'Responsabilités claires des autorités de poursuite et d\'enquête en matière de BC/FT/FP',
      'Ressources humaines et financières suffisantes pour les enquêtes',
      'Formation spécialisée des enquêteurs et des magistrats',
      'Procédures de coordination entre les autorités de poursuite et la CRF',
      'Obligation de poursuivre les affaires de BC/FT/FP de manière diligente',
    ],
    statisticsIndicators: [
      'Nombre d\'enquêtes BC/FT/FP ouvertes et clôturées',
      'Nombre de procureurs et enquêteurs spécialisés en LBC/FT',
      'Budget alloué aux unités spécialisées de lutte contre le BC/FT/FP',
    ],
  },

  {
    id: 31,
    title: 'Pouvoirs des autorités de poursuite pénale et des autorités chargées des enquêtes',
    fullTitle: 'Pouvoirs des autorités de poursuite pénale et des autorités chargées des enquêtes',
    description: 'Les autorités de répression (services de police, parquets, autorités douanières) doivent disposer de pouvoirs d\'enquête adéquats pour identifier, traquer, geler, saisir et confisquer les produits du blanchiment de capitaux, du financement du terrorisme et du financement de la prolifération. Les pouvoirs doivent inclure la capacité de recueillir des preuves, d\'interroger des témoins et de mener des perquisitions.',
    keyCriteria: [
      'Pouvoirs d\'enquête adéquats pour les autorités de répression en matière de BC/FT/FP',
      'Capacité de recueillir des preuves et de mener des perquisitions',
      'Pouvoirs de gel et de saisie des biens suspects',
      'Techniques d\'enquête spéciales (écoutes, infiltration, surveillance)',
      'Coordination entre les autorités de répression et la CRF',
    ],
    statisticsIndicators: [
      'Nombre d\'enquêtes BC/FT ouvertes',
      'Valeur des biens gelés et saisis lors des enquêtes',
      'Nombre d\'enquêtes utilisant des techniques spéciales d\'investigation',
    ],
  },

  {
    id: 32,
    title: 'Passeurs de fonds',
    fullTitle: 'Passeurs de fonds',
    description: 'Les pays doivent prendre des mesures pour détecter les flux financiers illicites, y compris l\'activité de passeurs de fonds (personnes physiques transportant physiquement des espèces, des instruments négociables ou des métaux précieux à travers les frontières). Les pays doivent exiger la déclaration des mouvements transfrontaliers d\'espèces et d\'instruments négociables dépassant les seuils fixés.',
    keyCriteria: [
      'Incrimination de l\'activité de passeur de fonds',
      'Déclaration obligatoire des mouvements transfrontaliers d\'espèces',
      'Détection et interception des passeurs de fonds',
      'Pouvoirs de fouille et de retenue des espèces non déclarées',
      'Formation des agents des douanes et des frontières',
    ],
    statisticsIndicators: [
      'Volume des déclarations de mouvements transfrontaliers d\'espèces',
      'Montant des espèces saisies aux frontières',
      'Nombre d\'interceptions de passeurs de fonds',
    ],
  },

  {
    id: 33,
    title: 'Statistiques',
    fullTitle: 'Statistiques',
    description: 'Les pays doivent maintenir des statistiques complètes et exactes sur les questions pertinentes liées à l\'efficacité et au fonctionnement de leur régime LBC/FT/FP. Ces statistiques doivent inclure les données sur les déclarations de soupçon reçues par la CRF, les enquêtes, les poursuites et les condamnations pour BC/FT/FP, les avoirs gelés et confisqués, et la coopération internationale.',
    keyCriteria: [
      'Collecte systématique de statistiques sur les DS reçues par la CRF',
      'Statistiques sur les enquêtes, poursuites et condamnations pour BC/FT/FP',
      'Données sur les avoirs gelés et confisqués',
      'Statistiques sur la coopération internationale (entraide, extradition)',
      'Publication régulière des statistiques LBC/FT/FP',
    ],
    statisticsIndicators: [
      'Nombre total de DS reçues par la CRF par an',
      'Nombre d\'enquêtes, de poursuites et de condamnations pour BC/FT/FP',
      'Valeur totale des avoirs gelés et confisqués',
    ],
  },

  {
    id: 34,
    title: 'Lignes directrices et retour d\'informations',
    fullTitle: 'Lignes directrices et retour d\'informations',
    description: 'Les autorités compétentes (superviseurs, CRF, autorités de poursuite) doivent élaborer et diffuser des lignes directrices et des retours d\'informations pour aider les entités assujetties à identifier et à signaler les opérations suspectes. Les lignes directrices doivent être régulièrement mises à jour pour refléter l\'évolution des risques, des typologies et des méthodes de blanchiment et de financement du terrorisme.',
    keyCriteria: [
      'Élaboration de lignes directrices sur l\'identification et le signalement des opérations suspectes',
      'Diffusion régulière des typologies et des tendances de BC/FT aux entités assujetties',
      'Mécanismes de retour d\'informations de la CRF vers les déclarants',
      'Mise à jour régulière des lignes directrices en fonction de l\'évolution des risques',
      'Consultation des entités assujetties dans l\'élaboration des lignes directrices',
    ],
    statisticsIndicators: [
      'Nombre de lignes directrices publiées par an',
      'Nombre de rapports de typologie diffusés',
      'Fréquence des retours d\'information de la CRF aux déclarants',
    ],
  },

  {
    id: 35,
    title: 'Sanctions',
    fullTitle: 'Sanctions',
    description: 'Les pays doivent veiller à ce que des sanctions effectives, proportionnées et dissuasives soient applicables, que ce soit au niveau des personnes physiques ou des personnes morales, en cas de non-respect des recommandations du GAFI. Les sanctions doivent inclure des sanctions pénales, civiles ou administratives, et doivent pouvoir être appliquées de manière effective par les autorités compétentes.',
    keyCriteria: [
      'Existence de sanctions pénales, civiles et administratives pour non-conformité LBC/FT',
      'Sanctions applicables aux personnes physiques et morales',
      'Caractère effectif, proportionné et dissuasif des sanctions',
      'Application effective des sanctions par les autorités compétentes',
      'Publication des sanctions imposées pour renforcer l\'effet dissuasif',
    ],
    statisticsIndicators: [
      'Nombre de sanctions pénales prononcées pour infractions LBC/FT',
      'Montant total des sanctions administratives et pécuniaires',
      'Nombre de personnes morales sanctionnées pour non-conformité LBC/FT',
    ],
  },

  {
    id: 36,
    title: 'Instruments internationaux',
    fullTitle: 'Instruments internationaux',
    description: 'Les pays devraient adhérer à et mettre en oeuvre efficacement les conventions internationales pertinentes en matière de LBC/FT/FP, notamment la Convention de Vienne de 1988, la Convention de Palerme de 2000, la Convention de Terrorisme Financier de 1999, et la Convention des Nations Unies contre la corruption (UNCAC). L\'adhésion à ces instruments est essentielle pour une coopération internationale efficace.',
    keyCriteria: [
      'Adhésion à la Convention de Vienne de 1988 (stupéfiants)',
      'Adhésion à la Convention de Palerme de 2000 (criminalité transnationale organisée)',
      'Adhésion à la Convention de 1999 (financement du terrorisme)',
      'Adhésion à la Convention des Nations Unies contre la corruption (UNCAC)',
      'Mise en oeuvre effective des obligations conventionnelles dans le droit interne',
    ],
    statisticsIndicators: [
      'Nombre de conventions internationales ratifiées',
      'Statut de mise en oeuvre des conventions dans le droit interne',
      'Nombre de demandes d\'entraide reçues et exécutées au titre des conventions',
    ],
  },

  {
    id: 37,
    title: 'Entraide judiciaire',
    fullTitle: 'Entraide judiciaire',
    description: 'Les pays doivent fournir rapidement et efficacement l\'entraide judiciaire la plus large possible en matière de BC/FT/FP, y compris l\'obtention de témoignages, la perquisition et la saisie, la remise de documents et d\'éléments de preuve, et l\'identification et le gel des produits du crime. L\'entraide doit être fournie que l\'infraction sous-jacente soit ou non commise sur le territoire du pays requérant.',
    keyCriteria: [
      'Fourniture rapide d\'entraide judiciaire en matière de BC/FT/FP',
      'Absence d\'exigence de double incrimination pour les infractions de BC/FT',
      'Capacité de recueillir des preuves et des témoignages à l\'étranger',
      'Possibilité de geler et de confisquer des biens à l\'étranger',
      'Absence de refus d\'entraide fondé sur le secret bancaire',
    ],
    statisticsIndicators: [
      'Nombre de demandes d\'entraide judiciaire reçues et exécutées',
      'Délai moyen de traitement des demandes d\'entraide',
      'Nombre de demandes d\'entraide envoyées à l\'étranger',
    ],
  },

  {
    id: 38,
    title: 'Entraide judiciaire : gel et confiscation',
    fullTitle: 'Entraide judiciaire : gel et confiscation',
    description: 'Les pays doivent être en mesure de répondre rapidement aux demandes d\'entraide judiciaire visant à identifier, geler, saisir et confisquer des biens lavés, des produits du crime, des fonds destinés au financement du terrorisme ou des biens liés à la prolifération. Les pays doivent également pouvoir prendre des mesures provisoires en réponse aux demandes étrangères de confiscation.',
    keyCriteria: [
      'Capacité de répondre aux demandes de gel et de saisie provenant de l\'étranger',
      'Possibilité de prendre des mesures provisoires sur demande étrangère',
      'Procédures rapides pour l\'exécution des ordres de confiscation étrangers',
      'Gestion et disposition des biens confisqués sur demande étrangère',
      'Partage des biens confisqués avec le pays requérant',
    ],
    statisticsIndicators: [
      'Nombre de demandes de gel/confiscation reçues de l\'étranger et exécutées',
      'Valeur des biens gelés et confisqués sur demande étrangère',
      'Délai moyen de traitement des demandes de gel/confiscation étrangères',
    ],
  },

  {
    id: 39,
    title: 'Extradition',
    fullTitle: 'Extradition',
    description: 'Les pays doivent être en mesure d\'extrader des personnes accusées d\'infractions de blanchiment de capitaux, de financement du terrorisme et de financement de la prolifération, conformément à leur droit interne et aux traités d\'extradition applicables. L\'extradition ne doit pas être refusée au motif que l\'infraction est considérée comme une infraction fiscale ou liée à des questions politiques.',
    keyCriteria: [
      'Capacité d\'extrader pour les infractions de BC/FT/FP',
      'Traités d\'extradition couvrant les infractions de BC/FT/FP',
      'Non-refus d\'extradition pour les infractions fiscales',
      'Procédure d\'extradition simplifiée ou accélérée',
      'Possibilité d\'extradition provisoire en cas d\'urgence',
    ],
    statisticsIndicators: [
      'Nombre de demandes d\'extradition reçues pour infractions BC/FT/FP',
      'Nombre d\'extraditions effectuées',
      'Délai moyen de traitement des demandes d\'extradition',
    ],
  },

  {
    id: 40,
    title: 'Autres formes de coopération',
    fullTitle: 'Autres formes de coopération',
    description: 'Les pays doivent coopérer entre eux pour la restitution ou le partage des biens confisqués, la fourniture d\'assistance technique et le renforcement des capacités. Les pays doivent aussi encourager la participation active aux réseaux internationaux et régionaux de lutte contre le BC/FT/FP, et soutenir les pays en développement dans la mise en oeuvre des recommandations du GAFI.',
    keyCriteria: [
      'Mécanismes de restitution ou de partage des biens confisqués',
      'Fourniture d\'assistance technique et de renforcement des capacités',
      'Participation active aux réseaux internationaux et régionaux (GAFI, EG, GABAC, etc.)',
      'Échange de bonnes pratiques et de typologies entre pays',
      'Soutien aux pays en développement pour la mise en oeuvre des recommandations',
    ],
    statisticsIndicators: [
      'Valeur des biens restitués ou partagés avec d\'autres pays',
      'Nombre de programmes d\'assistance technique mis en oeuvre',
      'Nombre de participations aux réunions des organismes régionaux de type GAFI',
    ],
  }
];

export const RESULTATS_IMMÉDIATS: ResultatImmédiatInfo[] = [
  {
    id: 1,
    title: "Compréhension des risques de BC/FT/FP et application d'une AFR",
    shortTitle: "Risques, politique et coordination",
    description: "Les risques de BC, FT et FP sont bien compris au niveau national. Les autorités disposent d'une évaluation des risques actualisée et fondée sur des données concrètes. Cette évaluation est communiquée à toutes les autorités compétentes et aux entités assujetties, qui appliquent des mesures proportionnées aux risques identifiés. L'approche fondée sur les risques guide l'allocation des ressources et les priorités d'action de l'ensemble du système national LBC/FT/FP.",
    fundamental: true,
    keyQuestions: [
      "Le pays dispose-t-il d'une évaluation nationale des risques (ENR) complète et actualisée ?",
      "Les risques identifiés sont-ils communiqués à toutes les autorités compétentes et aux entités assujetties ?",
      "Les mesures LBC/FT sont-elles proportionnées aux risques identifiés (AFR) ?",
      "Les ressources sont-elles allouées en fonction des priorités de risques identifiées ?",
    ],
    statisticsIndicators: [
      "Fréquence de mise à jour de l'ENR",
      "Nombre de secteurs/risques couverts par l'ENR",
      "Nombre de rapports de typologie produits",
      "Taux de diffusion de l'ENR aux entités assujetties",
    ],
  },
  {
    id: 2,
    title: "Coopération internationale",
    shortTitle: "Coopération internationale",
    description: "Les autorités du pays coopèrent efficacement et en temps opportun avec leurs homologues étrangers dans le cadre d'enquêtes, de poursuites et de procédures liées au BC, FT et FP. Le pays répond rapidement aux demandes d'entraide judiciaire et administrative, fournit des informations de qualité et coopère au gel, à la confiscation et au partage des avoirs. Les obstacles juridiques et pratiques à la coopération sont minimes.",
    fundamental: true,
    keyQuestions: [
      "Les demandes d'entraide sont-elles traitées dans des délais raisonnables ?",
      "Le pays échange-t-il spontanément des informations avec les pays étrangers ?",
      "Les obstacles au partage d'informations (secret bancaire, etc.) sont-ils levés ?",
      "Le pays participe-t-il activement aux réseaux internationaux de coopération ?",
    ],
    statisticsIndicators: [
      "Délai moyen de traitement des demandes d'entraide",
      "Taux de réponse positif aux demandes de coopération",
      "Volume des échanges d'informations avec les CRF étrangères",
    ],
  },
  {
    id: 3,
    title: "Supervision et surveillance",
    shortTitle: "Supervision",
    description: "Les superviseurs surveillent, supervisent et réglementent efficacement les entités assujetties pour assurer le respect des mesures LBC/FT/FP. La supervision est fondée sur les risques et utilise un ensemble d'outils (inspections sur place, contrôles hors site, évaluation des risques sectoriels). Les superviseurs prennent des mesures correctives et imposent des sanctions en cas de non-conformité, ce qui crée un effet dissuasif.",
    fundamental: true,
    keyQuestions: [
      "Les superviseurs disposent-ils de ressources et de pouvoirs suffisants ?",
      "La supervision est-elle fondée sur les risques ?",
      "Des sanctions effectives sont-elles imposées en cas de non-conformité ?",
      "Tous les secteurs à risque sont-ils effectivement supervisés ?",
    ],
    statisticsIndicators: [
      "Nombre d'inspections réalisées par an",
      "Taux de couverture sectorielle par les programmes de supervision",
      "Nombre de mesures correctives et de sanctions imposées",
      "Ressources affectées à la supervision LBC/FT",
    ],
  },
  {
    id: 4,
    title: "Prévention du BC/FT par les institutions financières",
    shortTitle: "Mesures préventives",
    description: "Les institutions financières appliquent effectivement des mesures de prévention du BC/FT/FP fondées sur les risques. Elles identifient correctement leurs clients et leurs bénéficiaires effectifs, surveillent les transactions, déclarent les opérations suspectes et appliquent les sanctions financières ciblées. Les programmes LBC/FT sont intégrés dans la gouvernance des institutions et soutenus par la direction.",
    fundamental: true,
    keyQuestions: [
      "Les institutions financières appliquent-elles une DEC fondée sur les risques ?",
      "Les bénéficiaires effectifs sont-ils correctement identifiés et vérifiés ?",
      "Les opérations suspectes sont-elles détectées et déclarées à la CRF ?",
      "Les sanctions financières ciblées sont-elles effectivement appliquées ?",
    ],
    statisticsIndicators: [
      "Nombre de DS émises par les institutions financières",
      "Taux de conformité aux exigences de DEC",
      "Nombre de relations d'affaires refusées ou clôturées pour risque LBC/FT",
      "Résultats des programmes de supervision des institutions financières",
    ],
  },
  {
    id: 5,
    title: "Prévention du BC/FT par les professions non financières",
    shortTitle: "Transparence PM",
    description: "Les professions non financières désignées (EPNFD) appliquent effectivement des mesures de prévention du BC/FT proportionnées à leurs risques. Elles identifient les opérations à risque, déclarent les opérations suspectes et respectent les obligations de transparence. La supervision et le contrôle des EPNFD garantissent la conformité effective aux mesures LBC/FT.",
    fundamental: true,
    keyQuestions: [
      "Les EPNFD identifient-elles et évaluent-elles leurs risques LBC/FT ?",
      "Les obligations de diligence sont-elles effectivement appliquées ?",
      "Les opérations suspectes sont-elles détectées et déclarées ?",
      "Les EPNFD sont-elles effectivement supervisées ?",
    ],
    statisticsIndicators: [
      "Nombre de DS émises par les EPNFD",
      "Taux de couverture de la supervision des EPNFD",
      "Nombre d'EPNFD conformes aux obligations LBC/FT",
    ],
  },
  {
    id: 6,
    title: "Déclarations d'opérations suspectes utilisées efficacement",
    shortTitle: "Transparence CJ",
    description: "La CRF reçoit, analyse et diffuse efficacement les déclarations de soupçon (DS) et d'autres informations pertinentes. Les DS sont utilisées pour déclencher des enquêtes financières, produire des rapports d'analyse opérationnelle et stratégique, et contribuer à la compréhension des risques nationaux. La CRF coopère activement avec les autorités de poursuite et les CRF étrangères.",
    fundamental: true,
    keyQuestions: [
      "La CRF reçoit-elle un volume suffisant de DS de qualité ?",
      "Les analyses de la CRF débouchent-elles sur des enquêtes et des poursuites ?",
      "La CRF produit-elle des rapports stratégiques utiles pour les autorités ?",
      "La CRF coopère-t-elle efficacement avec les CRF étrangères ?",
    ],
    statisticsIndicators: [
      "Nombre de DS reçues par la CRF",
      "Taux de DS donnant lieu à des enquêtes",
      "Nombre de rapports d'analyse opérationnelle produits",
      "Délai moyen d'analyse des DS",
    ],
  },
  {
    id: 7,
    title: "Enquêtes et poursuites en matière de BC",
    shortTitle: "Blanchiment de capitaux",
    description: "Les autorités de poursuite mènent des enquêtes efficaces et des poursuites proportionnées en matière de blanchiment de capitaux. Les enquêtes sont fondées sur les renseignements financiers, utilisent des techniques d'enquête spécialisées et visent à confisquer les produits du crime. Le taux de condamnation reflète l'efficacité du système de poursuite et le nombre d'enquêtes est proportionné aux risques identifiés.",
    fundamental: true,
    keyQuestions: [
      "Les enquêtes BC sont-elles fondées sur les renseignements financiers de la CRF ?",
      "Les techniques d'enquête spécialisées sont-elles utilisées efficacement ?",
      "Le nombre d'enquêtes et de poursuites est-il proportionné aux risques ?",
      "Les produits du crime sont-ils effectivement confisqués ?",
    ],
    statisticsIndicators: [
      "Nombre d'enquêtes BC ouvertes",
      "Nombre de condamnations pour blanchiment",
      "Valeur des avoirs confisqués dans les affaires de BC",
      "Taux de condamnation par rapport aux poursuites engagées",
    ],
  },
  {
    id: 8,
    title: "Enquêtes et poursuites en matière de FT",
    shortTitle: "Confiscation",
    description: "Les autorités compétentes mènent des enquêtes et des poursuites efficaces en matière de financement du terrorisme. Les enquêtes ciblent les réseaux de financement du terrorisme, identifient les sources et les canaux de financement, et contribuent à la prévention des actes terroristes. La coopération entre les services de renseignement, la police et la justice est essentielle pour la détection et la neutralisation des menaces.",
    fundamental: true,
    keyQuestions: [
      "Les autorités enquêtent-elles efficacement sur les réseaux de financement du terrorisme ?",
      "La coopération entre les services de renseignement et les autorités judiciaires est-elle effective ?",
      "Le nombre d'enquêtes FT est-il proportionné aux risques terroristes identifiés ?",
      "Les avoirs liés au terrorisme sont-ils effectivement gelés et confisqués ?",
    ],
    statisticsIndicators: [
      "Nombre d'enquêtes FT ouvertes",
      "Nombre d'arrestations et de condamnations pour FT",
      "Montant des avoirs liés au FT gelés et confisqués",
      "Nombre d'opérations terroristes déjouées grâce aux enquêtes financières",
    ],
  },
  {
    id: 9,
    title: "Mesures de gel et de confiscation",
    shortTitle: "FT et prolifération",
    description: "Les autorités compétentes prennent rapidement des mesures de gel et de confiscation des produits du crime, des fonds liés au terrorisme et des biens liés à la prolifération. Les mécanismes de gel fonctionnent de manière efficace et rapide, y compris pour les listes de sanctions de l'ONU. La confiscation est utilisée comme outil essentiel de lutte contre le crime organisé et le terrorisme, avec des résultats tangibles en termes de montants confisqués.",
    fundamental: false,
    keyQuestions: [
      "Les ordres de gel sont-ils exécutés rapidement après la désignation ?",
      "Les mécanismes de confiscation sont-ils effectifs et proportionnés ?",
      "Les biens confisqués sont-ils correctement gérés et redistribués ?",
      "La coopération internationale sur le gel et la confiscation fonctionne-t-elle ?",
    ],
    statisticsIndicators: [
      "Montant total des avoirs gelés (BC, FT, FP)",
      "Montant total des avoirs confisqués",
      "Délai moyen de mise en œuvre des ordres de gel",
      "Valeur des avoirs restitués aux pays d'origine",
    ],
  },
  {
    id: 10,
    title: "Sanctions financières ciblées en matière de prolifération",
    shortTitle: "Entraide judiciaire",
    description: "Les mesures de sanctions financières ciblées liées à la prolifération sont effectivement mises en œuvre. Les entités et personnes désignées par le Conseil de sécurité de l'ONU font l'objet d'un gel immédiat de leurs avoirs. Les institutions financières et les autorités compétentes vérifient systématiquement les transactions et les relations d'affaires contre les listes de sanctions de la prolifération.",
    fundamental: false,
    keyQuestions: [
      "Les listes de sanctions ONL sont-elles rapidement mises à jour et diffusées ?",
      "Les institutions financières vérifient-elles systématiquement les listes de la prolifération ?",
      "Les avoirs des personnes/entités désignées sont-ils effectivement gelés ?",
      "Des inspections et contrôles sont-ils réalisés pour vérifier la conformité ?",
    ],
    statisticsIndicators: [
      "Montant des avoirs gelés liés à la prolifération",
      "Nombre de vérifications effectuées contre les listes ONL de prolifération",
      "Nombre de violations des sanctions de prolifération détectées et poursuivies",
    ],
  },
  {
    id: 11,
    title: "Entraide administrative",
    shortTitle: "Entraide administrative",
    description: "Les autorités compétentes, notamment les superviseurs, les CRF et les autorités douanières, coopèrent efficacement entre elles et avec leurs homologues étrangers en matière de LBC/FT/FP. L'échange d'informations administratives est rapide, complet et fondé sur les risques. Les mécanismes de coopération permettent de répondre aux demandes des autorités étrangères dans des délais raisonnables et de manière constructive.",
    fundamental: false,
    keyQuestions: [
      "Les autorités compétentes échangent-elles rapidement des informations entre elles ?",
      "Les demandes d'entraide administrative étrangères sont-elles traitées dans des délais raisonnables ?",
      "La CRF échange-t-elle efficacement des informations avec les CRF étrangères ?",
      "Les superviseurs coopèrent-ils avec leurs homologues étrangers ?",
    ],
    statisticsIndicators: [
      "Nombre de demandes d'entraide administrative reçues et traitées",
      "Délai moyen de réponse aux demandes d'entraide administrative",
      "Volume des échanges d'information entre CRF",
    ],
  },
];

// Helper to get info for a specific recommendation
export function getRecommandationInfo(id: number): RecommandationInfo | undefined {
  return RECOMMANDATIONS.find(r => r.id === id);
}

// Helper to get info for a specific immediate outcome
export function getResultatImmédiatInfo(id: number): ResultatImmédiatInfo | undefined {
  return RESULTATS_IMMÉDIATS.find(r => r.id === id);
}