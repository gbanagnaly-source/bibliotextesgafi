'use client';

import { useState } from 'react';

interface AnimatedLogoProps {
  size?: number;
  className?: string;
  showLabel?: boolean;
}

export default function AnimatedLogo({ size = 48, className = '', showLabel = false }: AnimatedLogoProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div
      className={`relative inline-flex items-center gap-3 cursor-pointer select-none ${className}`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Glow ring on hover */}
      <div
        className="absolute inset-0 rounded-2xl transition-all duration-700 ease-out"
        style={{
          background: isHovered
            ? 'conic-gradient(from 0deg, #0ea5e9, #6366f1, #0ea5e9)'
            : 'transparent',
          opacity: isHovered ? 0.25 : 0,
          filter: 'blur(8px)',
          transform: isHovered ? 'scale(1.3)' : 'scale(1)',
        }}
      />

      {/* Main logo container */}
      <div
        className="relative rounded-xl overflow-hidden transition-all duration-500 ease-out"
        style={{
          width: size,
          height: size,
          transform: isHovered ? 'scale(1.08) rotate(-2deg)' : 'scale(1) rotate(0deg)',
          boxShadow: isHovered
            ? '0 8px 25px -5px rgba(14,165,233,0.35), 0 4px 10px -6px rgba(99,102,241,0.2)'
            : '0 2px 8px -2px rgba(0,0,0,0.1)',
        }}
      >
        {/* Scanning magnifying glass overlay effect */}
        <div
          className="absolute inset-0 pointer-events-none z-10"
          style={{
            background: isHovered
              ? 'linear-gradient(135deg, transparent 30%, rgba(14,165,233,0.15) 50%, transparent 70%)'
              : 'transparent',
            transition: 'background 0.5s ease',
          }}
        />

        {/* Rotating border accent */}
        <div
          className="absolute -inset-[2px] rounded-xl z-0"
          style={{
            background: isHovered
              ? 'conic-gradient(from 180deg, #0ea5e9, #6366f1, #a855f7, #0ea5e9)'
              : 'linear-gradient(135deg, #e2e8f0, #cbd5e1)',
            transition: 'background 0.7s ease',
            animation: isHovered ? 'logoSpin 3s linear infinite' : 'none',
          }}
        >
          <div className="absolute inset-[2px] rounded-[10px] bg-white" />
        </div>

        {/* The actual logo image */}
        <img
          src="/logo-comite-elephant.png"
          alt="BiblioGAFI"
          width={size}
          height={size}
          className="relative z-[5] object-contain w-full h-full p-1.5 transition-all duration-500"
          style={{
            filter: isHovered ? 'drop-shadow(0 0 6px rgba(14,165,233,0.3))' : 'none',
          }}
          draggable={false}
        />
      </div>

      {/* Label with typewriter-like reveal on hover */}
      {showLabel && (
        <div className="overflow-hidden">
          <span
            className="text-sm font-bold bg-gradient-to-r from-sky-600 to-indigo-600 bg-clip-text text-transparent transition-all duration-500 inline-block"
            style={{
              maxWidth: isHovered ? '300px' : '0px',
              opacity: isHovered ? 1 : 0,
              whiteSpace: 'nowrap',
            }}
          >
            BiblioGAFI
          </span>
        </div>
      )}

      <style jsx>{`
        @keyframes logoSpin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}