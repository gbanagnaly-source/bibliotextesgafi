'use client';

import { useEffect, useRef } from 'react';

interface Props {
  className?: string;
}

export default function DotMatrixWorldMap({ className = '' }: Props) {
  const frameRef = useRef<number>(0);
  const trackRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const track = trackRef.current;
    if (!track) return;

    const img = track.querySelector('img') as HTMLImageElement;
    if (!img) return;

    let imgW = 0;
    let offset = 0;
    const speed = 0.2;
    let running = true;

    function measureAndStart() {
      imgW = img.offsetWidth;
      if (imgW > 0 && running) {
        animate();
      } else if (running) {
        requestAnimationFrame(measureAndStart);
      }
    }

    function animate() {
      if (!running) return;
      offset -= speed;
      if (Math.abs(offset) >= imgW) {
        offset += imgW;
      }
      track.style.transform = `translateX(${offset}px)`;
      frameRef.current = requestAnimationFrame(animate);
    }

    if (img.complete && img.offsetWidth > 0) {
      imgW = img.offsetWidth;
      animate();
    } else {
      img.addEventListener('load', measureAndStart, { once: true });
      requestAnimationFrame(measureAndStart);
    }

    return () => {
      running = false;
      cancelAnimationFrame(frameRef.current);
    };
  }, []);

  return (
    <div className={`absolute inset-0 overflow-hidden ${className}`}>
      <div
        ref={trackRef}
        className="flex h-full"
        style={{ willChange: 'transform' }}
      >
        {/* 3 copies to guarantee full coverage at all viewport widths */}
        <div className="h-full flex-shrink-0">
          <img src="/world-map-bg.png" alt="" className="h-full w-auto block" draggable={false} />
        </div>
        <div className="h-full flex-shrink-0">
          <img src="/world-map-bg.png" alt="" className="h-full w-auto block" draggable={false} />
        </div>
        <div className="h-full flex-shrink-0">
          <img src="/world-map-bg.png" alt="" className="h-full w-auto block" draggable={false} />
        </div>
      </div>
    </div>
  );
}