'use client';

import { useState, ReactNode, useRef, useCallback } from 'react';
import { Maximize2, Minimize2, X } from 'lucide-react';
import { t } from './settings-panel';

interface ZoomableSectionProps {
  children: ReactNode;
  title?: string;
  className?: string;
  /** Optional zoom controls shown inline before expanding */
  showInlineZoom?: boolean;
  lang?: 'fr' | 'en';
}

export default function ZoomableSection({ children, title, className, showInlineZoom = true, lang = 'fr' }: ZoomableSectionProps) {
  const [zoomed, setZoomed] = useState(false);
  const contentRef = useRef<HTMLDivElement>(null);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Escape') setZoomed(false);
  }, []);

  return (
    <>
      {/* Wrapper with zoom button */}
      <div className={`relative group ${className || ''}`}>
        {showInlineZoom && (
          <button
            type="button"
            onClick={() => setZoomed(true)}
            className="absolute top-3 right-3 z-10 flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-medium bg-white/90 hover:bg-white border border-gray-200 hover:border-sky-300 rounded-lg shadow-sm hover:shadow-md transition-all text-gray-500 hover:text-sky-600 opacity-0 group-hover:opacity-100"
            title={t(lang, 'zoom.enlarge')}
          >
            <Maximize2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t(lang, 'zoom.enlarge')}</span>
          </button>
        )}
        <div ref={contentRef}>
          {children}
        </div>
      </div>

      {/* Fullscreen Zoom Overlay */}
      {zoomed && (
        <div
          className="fixed inset-0 z-[300] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 sm:p-8 animate-in fade-in duration-200"
          onClick={(e) => { if (e.target === e.currentTarget) setZoomed(false); }}
          onKeyDown={handleKeyDown}
          tabIndex={0}
        >
          <div
            className="relative bg-white rounded-2xl shadow-2xl w-full max-w-[95vw] max-h-[95vh] flex flex-col overflow-hidden animate-in zoom-in-95 duration-200"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header bar */}
            <div className="flex items-center justify-between px-5 py-3 border-b bg-gradient-to-r from-slate-800 to-slate-900 text-white rounded-t-2xl flex-shrink-0">
              <div className="flex items-center gap-2">
                <Maximize2 className="w-4 h-4 text-sky-300" />
                <h3 className="text-sm font-bold">{title || t(lang, 'zoom.enlargedView')}</h3>
              </div>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => setZoomed(false)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
                >
                  <Minimize2 className="w-3.5 h-3.5" />
                  {t(lang, 'zoom.reduce')}
                </button>
                <button
                  onClick={() => setZoomed(false)}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Zoomed content */}
            <div className="flex-1 overflow-auto p-5 sm:p-6">
              {/* Re-render children in zoomed context — clone to override height constraints */}
              <div className="transform scale-100">
                {children}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}