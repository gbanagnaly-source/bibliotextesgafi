'use client';

import { useState, useEffect } from 'react';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle,
} from '@/components/ui/sheet';
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { ScrollText, AlertCircle, BarChart3, Link2, Info, FileQuestion, ClipboardCheck, ChevronRight, ArrowLeft, ExternalLink } from 'lucide-react';
import { ImmediateResult, EffectivenessLevel } from './types';
import { RECOMMANDATIONS } from '@/data/gafi-knowledge';
import { t, type LangCode } from '@/components/dashboard/settings-panel';

interface RIDetail {
  id: number;
  shortTitle: string;
  title: string;
  description: string;
  characteristics: string;
  essentialQuestions: string[];
  supportingInfo: string[];
  specificFactors: string[];
  statisticalData: string[];
  mainRecommendations: number[];
  partialRecommendations: { rec: number; elements: string }[];
}

const effColor: Record<string, string> = {
  'Élevé': '#22c55e',
  'Significatif': '#84cc16',
  'Modéré': '#f97316',
  'Faible': '#ef4444',
  'Non évalué': '#9ca3af',
};

const effColorLight: Record<string, string> = {
  'Élevé': '#dcfce7',
  'Significatif': '#f7fee7',
  'Modéré': '#fff7ed',
  'Faible': '#fef2f2',
  'Non évalué': '#f3f4f6',
};

/* ── Recommendation badge with tooltip + click ── */
function RecBadge({ recId, lang = 'fr', onOpenRec }: { recId: number; lang?: LangCode; onOpenRec?: (id: number) => void }) {
  const rec = RECOMMANDATIONS.find(r => r.id === recId);
  const label = `R.${recId}`;
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); onOpenRec?.(recId); }}
          className="inline-flex items-center gap-1 bg-purple-600 hover:bg-purple-700 text-[11px] px-3 py-1 shadow-sm font-medium rounded-md transition-colors cursor-pointer"
        >
          {label}
          <ExternalLink className="w-2.5 h-2.5 opacity-60" />
        </button>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="max-w-xs">
        <p className="font-semibold text-purple-900">{label} — {rec?.title || ''}</p>
        <p className="text-[11px] text-gray-500 mt-0.5">{t(lang, 'riDesc.clickToOpen')}</p>
      </TooltipContent>
    </Tooltip>
  );
}

function PartialRecBadge({ recId, elements, lang = 'fr', onOpenRec }: { recId: number; elements: string; lang?: LangCode; onOpenRec?: (id: number) => void }) {
  const rec = RECOMMANDATIONS.find(r => r.id === recId);
  const label = `R.${recId}`;
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div
          role="button"
          tabIndex={0}
          onClick={(e) => { e.stopPropagation(); onOpenRec?.(recId); }}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); onOpenRec?.(recId); } }}
          className="flex items-start gap-2.5 p-3 rounded-xl bg-purple-50/50 border border-purple-100/80 cursor-pointer hover:bg-purple-100/60 transition-colors"
        >
          <Badge variant="outline" className="text-[11px] border-purple-300 text-purple-700 bg-white flex-shrink-0 mt-0.5 font-medium">
            {label}
            <ExternalLink className="w-2.5 h-2.5 ml-1 opacity-50" />
          </Badge>
          <span className="text-[12px] text-gray-600 leading-relaxed mt-0.5">{elements}</span>
        </div>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="max-w-xs">
        <p className="font-semibold text-purple-900">{label} — {rec?.title || ''}</p>
        <p className="text-[11px] text-gray-500 mt-0.5">{t(lang, 'riDesc.clickToOpen')}</p>
      </TooltipContent>
    </Tooltip>
  );
}

/* ── Detail view for a single RI (7 sections) ── */
function RIDetailView({ ri, effectiveness, onBack, onOpenRec, lang = 'fr' }: {
  ri: RIDetail;
  effectiveness: string;
  onBack: () => void;
  onOpenRec?: (id: number) => void;
  lang?: LangCode;
}) {
  const color = effColor[effectiveness] || '#9ca3af';

  /* ── Shared section definitions (inside component to access lang) ── */
  const sections = [
    { key: 'description', label: t(lang, 'riDesc.description'), Icon: Info, color: 'sky', iconBg: 'bg-sky-100', iconColor: 'text-sky-600', numBg: 'bg-sky-100', numText: 'text-sky-700', borderHover: 'hover:border-sky-200' },
    { key: 'characteristics', label: t(lang, 'riDesc.characteristics'), Icon: ClipboardCheck, color: 'emerald', iconBg: 'bg-emerald-100', iconColor: 'text-emerald-600', numBg: 'bg-emerald-100', numText: 'text-emerald-700', borderHover: 'hover:border-emerald-200' },
    { key: 'questions', label: t(lang, 'riDesc.questions'), Icon: FileQuestion, color: 'amber', iconBg: 'bg-amber-100', iconColor: 'text-amber-600', numBg: 'bg-amber-100', numText: 'text-amber-700', borderHover: 'hover:border-amber-200' },
    { key: 'supporting-info', label: t(lang, 'riDesc.supportingInfo'), Icon: ScrollText, color: 'indigo', iconBg: 'bg-indigo-100', iconColor: 'text-indigo-600', numBg: 'bg-indigo-100', numText: 'text-indigo-700', borderHover: 'hover:border-indigo-200' },
    { key: 'specific-factors', label: t(lang, 'riDesc.specificFactors'), Icon: AlertCircle, color: 'orange', iconBg: 'bg-orange-100', iconColor: 'text-orange-600', numBg: 'bg-orange-100', numText: 'text-orange-700', borderHover: 'hover:border-orange-200' },
    { key: 'statistical-data', label: t(lang, 'riDesc.statisticalData'), Icon: BarChart3, color: 'teal', iconBg: 'bg-teal-100', iconColor: 'text-teal-600', numBg: 'bg-teal-100', numText: 'text-teal-700', borderHover: 'hover:border-teal-200' },
  ] as const;

  return (
    <>
      {/* Header with back button */}
      <SheetHeader className="px-5 py-4 sticky top-0 bg-gradient-to-r from-gray-50 via-white to-white z-10 border-b border-gray-100">
        <SheetTitle className="flex items-center gap-3 text-base">
          <button
            onClick={onBack}
            className="flex items-center justify-center w-9 h-9 rounded-xl bg-gray-100 hover:bg-gray-200 transition-colors flex-shrink-0 shadow-sm"
            title={t(lang, 'riDesc.backToList')}
          >
            <ArrowLeft className="w-4 h-4 text-gray-600" />
          </button>
          <span
            className="inline-flex items-center justify-center w-10 h-10 rounded-xl text-sm font-bold text-white flex-shrink-0 shadow-sm"
            style={{ backgroundColor: color }}
          >
            RI.{ri.id}
          </span>
          <div className="min-w-0">
            <span className="leading-tight block text-[15px] font-semibold text-gray-900">{ri.shortTitle}</span>
            <span className="text-[11px] text-gray-400 leading-snug block mt-0.5">{t(lang, 'riDesc.level')} {effectiveness}</span>
          </div>
          <Badge
            className="ml-auto text-[11px] px-3 py-1 text-white flex-shrink-0 shadow-sm font-medium"
            style={{ backgroundColor: color }}
          >
            {effectiveness}
          </Badge>
        </SheetTitle>
      </SheetHeader>

      <div className="px-5 pb-8 pt-4">
        {/* Full title */}
        <p className="text-[12px] text-gray-500 italic mb-5 leading-relaxed border-l-2 border-gray-200 pl-3">{ri.title}</p>

        <Accordion type="multiple" defaultValue={['description', 'characteristics']} className="w-full space-y-1">
          {/* Auto-generated 6 sections */}
          {sections.map((sec, secIdx) => {
            const items: string[] = (ri as any)[
              sec.key === 'description' ? 'description'
              : sec.key === 'characteristics' ? 'characteristics'
              : sec.key === 'questions' ? 'essentialQuestions'
              : sec.key === 'supporting-info' ? 'supportingInfo'
              : sec.key === 'specific-factors' ? 'specificFactors'
              : 'statisticalData'
            ];
            const isTextField = secIdx < 2;

            return (
              <AccordionItem key={sec.key} value={sec.key} className={`border rounded-xl ${sec.borderHover} transition-colors`}>
                <AccordionTrigger className="gap-3 hover:no-underline px-4 py-3.5">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg ${sec.iconBg} flex items-center justify-center flex-shrink-0`}>
                      <sec.Icon className={`w-4 h-4 ${sec.iconColor}`} />
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-bold text-gray-400">{secIdx + 1}.</span>
                      <span className="text-[13px] font-semibold text-gray-800">{sec.label}</span>
                    </div>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="pb-4">
                  <div className="px-4">
                    {isTextField ? (
                      <p className="text-[13px] text-gray-700 leading-[1.75]">{secIdx === 0 ? ri.description : ri.characteristics}</p>
                    ) : (
                      <ul className="space-y-3">
                        {items.map((item: string, i: number) => (
                          <li key={i} className="flex gap-3 text-[13px] text-gray-700 leading-[1.75]">
                            <span className={`inline-flex items-center justify-center w-5 h-5 rounded-md ${sec.numBg} ${sec.numText} text-[10px] font-bold flex-shrink-0 mt-0.5`}>
                              {i + 1}
                            </span>
                            <span>{item}</span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </AccordionContent>
              </AccordionItem>
            );
          })}

          {/* 7. Liens avec les Recommandations */}
          <AccordionItem value="recommendations" className="border rounded-xl hover:border-purple-200 transition-colors">
            <AccordionTrigger className="gap-3 hover:no-underline px-4 py-3.5">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center flex-shrink-0">
                  <Link2 className="w-4 h-4 text-purple-600" />
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-[10px] font-bold text-gray-400">7.</span>
                  <span className="text-[13px] font-semibold text-gray-800">{t(lang, 'riDesc.recommendationLinks')}</span>
                </div>
              </div>
            </AccordionTrigger>
            <AccordionContent className="pb-4">
              <div className="px-4 space-y-6">
                {ri.mainRecommendations.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2.5 mb-3">
                      <div className="h-px flex-1 bg-purple-200/80" />
                      <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-purple-600 whitespace-nowrap">
                        {t(lang, 'riDesc.mainRecs')}
                      </p>
                      <div className="h-px flex-1 bg-purple-200/80" />
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {ri.mainRecommendations.map(rec => (
                        <RecBadge key={rec} recId={rec} lang={lang} onOpenRec={onOpenRec} />
                      ))}
                    </div>
                  </div>
                )}
                {ri.partialRecommendations.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2.5 mb-3">
                      <div className="h-px flex-1 bg-purple-200/80" />
                      <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-purple-500 whitespace-nowrap">
                        {t(lang, 'riDesc.partialRecs')}
                      </p>
                      <div className="h-px flex-1 bg-purple-200/80" />
                    </div>
                    <div className="space-y-2">
                      {ri.partialRecommendations.map((pr, i) => (
                        <PartialRecBadge key={i} recId={pr.rec} elements={pr.elements} lang={lang} onOpenRec={onOpenRec} />
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </div>
    </>
  );
}

/* ── Main component: list view + detail navigation ── */
interface RISummarySheetProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  immediateResults: ImmediateResult[];
  onOpenRec?: (recId: number) => void;
  lang?: LangCode;
}

export default function RISummarySheet({ open, onOpenChange, immediateResults, onOpenRec, lang = 'fr' }: RISummarySheetProps) {
  const [riDetails, setRiDetails] = useState<Record<number, RIDetail>>({});
  const [selectedRI, setSelectedRI] = useState<number | null>(null);

  useEffect(() => {
    if (open) {
      fetch('/data/ri-details.json')
        .then(r => r.json())
        .then((items: RIDetail[]) => {
          const map: Record<number, RIDetail> = {};
          items.forEach(ri => { map[ri.id] = ri; });
          setRiDetails(map);
        })
        .catch(() => {});
    }
  }, [open]);

  useEffect(() => {
    if (!open) setSelectedRI(null);
  }, [open]);

  const selectedDetail = selectedRI ? riDetails[selectedRI] : null;
  const selectedResult = selectedRI ? immediateResults.find(r => r.id === selectedRI) : null;

  // Detail view
  if (selectedRI && selectedDetail && selectedResult) {
    return (
      <Sheet open={open} onOpenChange={onOpenChange}>
        <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto p-0">
          <TooltipProvider delayDuration={300}>
          <RIDetailView
            ri={selectedDetail}
            effectiveness={selectedResult.effectiveness}
            onBack={() => setSelectedRI(null)}
            onOpenRec={onOpenRec}
            lang={lang}
          />
          </TooltipProvider>
        </SheetContent>
      </Sheet>
    );
  }

  // List view
  return (
    <Sheet open={open} onOpenChange={onOpenChange}>
      <SheetContent side="right" className="w-full sm:max-w-3xl lg:max-w-4xl overflow-y-auto p-0">
        {/* Header */}
        <SheetHeader className="px-5 py-4 sticky top-0 bg-gradient-to-r from-sky-50 via-white to-white z-10 border-b border-sky-100/60">
          <SheetTitle className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-sky-600 flex items-center justify-center flex-shrink-0 shadow-sm">
              <span className="text-white text-sm font-bold">11</span>
            </div>
            <div>
              <p className="font-semibold leading-tight text-gray-900 text-[15px]">{t(lang, 'ri.immediateOutcomes')}</p>
              <p className="text-[11px] text-gray-500 mt-0.5">{t(lang, 'ri.clickToAccess')}</p>
            </div>
          </SheetTitle>
        </SheetHeader>

        <div className="px-5 pb-8 pt-4">
          {/* Summary pills */}
          <div className="flex flex-wrap gap-2 mb-5">
            {(['Élevé', 'Significatif', 'Modéré', 'Faible', 'Non évalué'] as EffectivenessLevel[]).map(level => {
              const count = immediateResults.filter(r => r.effectiveness === level).length;
              if (count === 0) return null;
              return (
                <div key={level} className="flex items-center gap-1.5 px-3 py-1.5 rounded-full text-[11px] font-semibold shadow-sm" style={{ backgroundColor: effColorLight[level], color: effColor[level] }}>
                  <div className="w-2.5 h-2.5 rounded-full shadow-inner" style={{ backgroundColor: effColor[level] }} />
                  {level} : {count}
                </div>
              );
            })}
          </div>

          {/* RI list */}
          <div className="space-y-2">
            {immediateResults.map((result) => {
              const color = effColor[result.effectiveness] || '#9ca3af';
              return (
                <button
                  key={result.id}
                  onClick={() => setSelectedRI(result.id)}
                  className="w-full flex items-center gap-3.5 p-3.5 rounded-xl border border-gray-200 bg-white hover:shadow-md transition-all duration-200 text-left group"
                  style={{ ['--hover-border' as any]: color }}
                >
                  {/* RI badge */}
                  <span
                    className="inline-flex items-center justify-center w-10 h-10 rounded-xl text-[11px] font-bold text-white flex-shrink-0 shadow-sm"
                    style={{ backgroundColor: color }}
                  >
                    RI.{result.id}
                  </span>
                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-[13px] font-semibold text-gray-800 group-hover:text-sky-700 transition-colors">{result.shortTitle}</span>
                      {result.fundamental && (
                        <span className="text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.5 rounded bg-amber-100 text-amber-700">{t(lang, 'ri.fundamental')}</span>
                      )}
                    </div>
                    <p className="text-[11px] text-gray-500 mt-0.5 truncate leading-snug">{result.title}</p>
                  </div>
                  {/* Level badge */}
                  <Badge
                    className="text-[10px] px-2.5 py-0.5 flex-shrink-0 text-white font-medium shadow-sm"
                    style={{ backgroundColor: color }}
                  >
                    {result.effectiveness}
                  </Badge>
                  {/* Arrow */}
                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-sky-500 flex-shrink-0 transition-all group-hover:translate-x-0.5" />
                </button>
              );
            })}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}