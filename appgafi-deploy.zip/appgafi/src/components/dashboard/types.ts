export type ComplianceLevel = 'Conforme' | 'Largement Conforme' | 'Partiellement Conforme' | 'Non Conforme' | 'Non évalué';
export type EffectivenessLevel = 'Élevé' | 'Significatif' | 'Modéré' | 'Faible' | 'Non évalué';
export type GlobalRating = 'Satisfaisant' | 'Suffisant' | 'Non Satisfaisant' | 'Insuffisant' | 'N/A';

export interface Recommendation {
  id: number;
  title: string;
  description: string;
  compliance: ComplianceLevel;
  ratingCode: string;
}

export interface ImmediateResult {
  id: number;
  title: string;
  shortTitle: string;
  description: string;
  effectiveness: EffectivenessLevel;
  effectivenessCode: string;
  fundamental: boolean;
}

export interface CountrySummary {
  technicalComplianceScore: number;
  effectivenessScore: number;
  strengths: string[];
  areasForImprovement: string[];
  highRiskAreas: string[];
}

export interface EvaluationPeriod {
  date: string;
  globalRating: GlobalRating;
  overallCompliance: number;
  overallEffectiveness: number;
}

export interface CountryData {
  countryName: string;
  countryCode: string;
  region: string;
  reportType: string;
  assessmentBody: string;
  latestEvaluation: EvaluationPeriod;
  previousEvaluation: EvaluationPeriod;
  recommendations: Recommendation[];
  immediateResults: ImmediateResult[];
  summary: CountrySummary;
}

export interface CountryListItem {
  countryName: string;
  countryCode: string;
  region: string;
  reportType: string;
  assessmentBody: string;
  latestEvaluation: EvaluationPeriod;
  previousEvaluation: EvaluationPeriod;
  summary: CountrySummary;
}