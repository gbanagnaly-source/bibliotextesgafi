'use client';

import { useState, useRef, useCallback } from 'react';
import { Settings, Globe, Upload, Lock, X, Check, AlertCircle, Loader2 } from 'lucide-react';

const LANGUAGES = [
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'en', label: 'English', flag: '🇬🇧' },
] as const;

type LangCode = (typeof LANGUAGES)[number]['code'];

const TRANSLATIONS: Record<LangCode, Record<string, string>> = {
  fr: {
    // Nav & Tabs
    'nav.title': 'Bibliothèque de visualisation des normes et Evaluations du GAFI',
    'tab.synthese': 'Synthèse',
    'tab.conformite': 'Conformité',
    'tab.efficacite': 'Efficacité',
    'tab.comparaison': 'Comparaison',
    'tab.allCountries': 'Tous les pays',
    'search.placeholder': 'Rechercher un pays...',
    'all': 'Toutes',
    'country': 'Pays',
    'region': 'Région',
    'date': 'Date',
    'rating': 'Appréciation',
    'compliance': 'Conformité',
    'effectiveness': 'Efficacité',

    // Overview table
    'overview.title': 'Vue d\'ensemble — Tous les pays',
    'overview.countries': 'pays',
    'overview.no': 'N°',

    // Compliance levels
    'level.Conforme': 'Conforme',
    'level.Largement Conforme': 'Largement Conforme',
    'level.Partiellement Conforme': 'Partiellement Conforme',
    'level.Non Conforme': 'Non Conforme',
    'level.Non évalué': 'Non évalué',
    // Compliance levels (short for small cards)
    'levelShort.Conforme': 'C',
    'levelShort.Largement Conforme': 'LC',
    'levelShort.Partiellement Conforme': 'PC',
    'levelShort.Non Conforme': 'NC',
    'levelShort.Non évalué': 'N/A',

    // Effectiveness levels
    'level.Élevé': 'Élevé',
    'level.Significatif': 'Significatif',
    'level.Modéré': 'Modéré',
    'level.Faible': 'Faible',

    // Global ratings
    'rating.Satisfaisant': 'Satisfaisant',
    'rating.Suffisant': 'Suffisant',
    'rating.Non Satisfaisant': 'Non Satisfaisant',
    'rating.Insuffisant': 'Insuffisant',

    // Recommendation detail
    'rec.40detail': 'Détail des 40 Recommandations',
    'rec.sourceGafi': 'Source GAFI',
    'rec.recommendation': 'Recommandation',
    'rec.level': 'Niveau',
    'rec.clickDetail': 'Cliquez sur une recommandation pour voir les détails',
    'rec.listOf': 'Liste des recommandations évaluées comme « {0} »',
    'rec.clickToSee': 'cliquez sur une recommandation pour voir les détails',
    'rec.total': 'Total : {0} / 40 recommandations',
    'rec.percentTotal': '{0}% du total',
    'rec.recommendation_word': 'recommandation',
    'rec.recommendations_word': 'recommandations',

    // Effectiveness / RI
    'ri.title': '11 Résultats immédiats',
    'ri.riImmediate': 'Résultat immédiat',
    'ri.radarTitle': 'Radar d\'efficacité — 11 Résultats Immédiats',
    'ri.detailTitle': 'Détail des 11 Résultats Immédiats',
    'ri.clickDetail': 'Cliquez sur un RI pour voir les détails',
    'ri.listOf': 'Liste des résultats immédiats évalués comme « {0} »',
    'ri.clickToSee': 'cliquez sur un RI pour voir les détails',
    'ri.total': 'Total : {0} / 11 résultats immédiats',
    'ri.percentTotal': '{0}% du total',
    'ri.fundamental': 'Fondamental',
    'ri.type': 'Type',
    'ri.resultat': 'résultat',
    'ri.resultats': 'résultats',
    'ri.immediat': 'immédiat',
    'ri.immediats': 'immédiats',
    'ri.effLevel': 'Niveau d\'efficacité',
    'ri.efficacy': 'Efficacité',
    'ri.immediateOutcomes': 'Résultats Immédiats',
    'ri.clickToAccess': 'Cliquez sur un RI pour accéder aux détails',

    // Radar axis labels (short)
    'ri.risk': 'Risques',
    'ri.intlCoop': 'Coop. intl.',
    'ri.supervision': 'Supervision',
    'ri.finPrev': 'Prév. fin.',
    'ri.nonFinPrev': 'Prév. non fin.',
    'ri.reports': 'Déclarations',
    'ri.mlInvestigations': 'Enquêtes BL',
    'ri.tfInvestigations': 'Enquêtes FT',
    'ri.freeze': 'Gel/Confisc.',
    'ri.proliferation': 'Prolifération',
    'ri.transpLP': 'Transp. PM',

    // Summary section
    'summary.title': 'Synthèse de l\'évaluation',
    'summary.strengths': 'Points forts',
    'summary.improvements': 'Axes d\'amélioration',
    'summary.riskAreas': 'Zones à risque',
    'summary.prev': 'Préc. :',
    'summary.pts': 'pts',
    'summary.technicalCompliance': 'Conformité Technique',
    'summary.systemEffectiveness': 'Efficacité du Système',
    'summary.evaluatedBy': 'évalué par',

    // Hero
    'hero.evalTitle': 'Évaluation Normes du GAFI — {0}',
    'hero.evalDesc': 'Consultez les résultats de l\'évaluation mutuelle incluant la conformité technique aux 40 Recommandations et l\'efficacité du système national de lutte contre le blanchiment de capitaux et le financement du terrorisme.',
    'hero.prevEval': 'Avant dernière\névaluation',
    'hero.lastEval': 'Dernière\névaluation',
    'hero.40rec': '40 Recommandations',
    'hero.40recSub': 'Conformité technique',
    'hero.11ri': '11 Résultats immédiats',
    'hero.11riSub': 'Efficacité du système',
    'hero.explorer': 'Explorer',

    // Comparison
    'comp.radarTitle': 'Comparaison par radar — Efficacité (11 résultats immédiats)',
    'comp.radarZoom': 'Comparaison radar — Efficacité',
    'comp.selectCountry': 'Sélectionner un pays',
    'comp.searchPlaceholder': 'Rechercher...',
    'comp.noResult': 'Aucun résultat',
    'comp.country1': 'Pays 1',
    'comp.selectedCountry': 'Pays sélectionné',
    'comp.countryToCompare': 'Pays à comparer',
    'comp.loading': 'Chargement...',
    'comp.selectHint': 'sélectionnez un pays à comparer',
    'comp.technicalCompliance': 'Conformité technique',
    'comp.systemEffectiveness': 'Efficacité du système',

    // Country selector
    'cs.selectCountry': 'Sélectionner un pays',
    'cs.searchPlaceholder': 'Rechercher un pays ou une région...',
    'cs.countriesShown': 'pays affichés',

    // Zoomable section
    'zoom.enlarge': 'Agrandir',
    'zoom.reduce': 'Réduire',
    'zoom.enlargedView': 'Vue agrandie',

    // Knowledge modal
    'km.rec40': '40 Recommandations',
    'km.ri11': '11 Résultats immédiats',
    'km.recSubtitle': 'Conformité technique aux normes du GAFI',
    'km.riSubtitle': 'Évaluation de l\'efficacité du système LBC/FT/FP',
    'km.keyCriteria': 'Critères clés d\'évaluation',
    'km.keyQuestions': 'Questions clés d\'évaluation',
    'km.statIndicators': 'Indicateurs statistiques (Lignes Directrices GAFI)',
    'km.previous': '← Précédent',
    'km.next': 'Suivant →',
    'km.fundamental': 'Fondamental',
    'km.complementary': 'Complémentaire',

    // RI detail sheet sections
    'riDesc.description': 'Description',
    'riDesc.characteristics': 'Caractéristiques d\'un système efficace',
    'riDesc.questions': 'Questions essentielles',
    'riDesc.supportingInfo': 'Exemples d\'informations',
    'riDesc.specificFactors': 'Facteurs spécifiques',
    'riDesc.statisticalData': 'Données statistiques',
    'riDesc.recommendationLinks': 'Liens avec les Recommandations',
    'riDesc.mainRecs': 'Recommandations principales',
    'riDesc.partialRecs': 'Avec certains éléments',
    'riDesc.clickToOpen': 'Cliquez pour ouvrir la recommandation',
    'riDesc.backToList': 'Retour à la liste',
    'riDesc.level': 'Niveau :',

    // Settings
    'settings.title': 'Réglages',
    'settings.language': 'Langue',
    'settings.import': 'Mettre à jour depuis Excel',
    'settings.importDesc': 'Importer un fichier Excel pour actualiser les données d\'évaluation',
    'settings.password': 'Mot de passe',
    'settings.passwordPlaceholder': 'Entrez le mot de passe',
    'settings.selectFile': 'Choisir un fichier Excel',
    'settings.upload': 'Importer',
    'settings.cancel': 'Annuler',
    'settings.uploading': 'Import en cours...',
    'settings.success': 'Données mises à jour avec succès !',
    'settings.error': 'Mot de passe incorrect ou erreur lors de l\'import.',
    'settings.noFile': 'Veuillez sélectionner un fichier.',
    'settings.noPassword': 'Veuillez entrer le mot de passe.',

    // Footer
    'footer.library': 'Bibliothèque de visualisation des normes et Evaluations du GAFI',
    'footer.source': 'Source : Groupe d\'Action Financière (GAFI) — 4th Round Ratings (Updated 27 May 2026)',
    'footer.disclaimer': 'Les appréciations globales sont calculées à partir des données officielles du GAFI.',
    'footer.service': 'Conçue par le Service des Statistiques Nationales LBC/FT/FP',
    'footer.contact': 'Comité LBC/FT/FP — 21 22 41 77 54/56 ou 07 07 56 46 56',
    'countries': 'pays',
  },
  en: {
    // Nav & Tabs
    'nav.title': 'GAFI Standards and Evaluations Visualization Library',
    'tab.synthese': 'Summary',
    'tab.conformite': 'Compliance',
    'tab.efficacite': 'Effectiveness',
    'tab.comparaison': 'Comparison',
    'tab.allCountries': 'All countries',
    'search.placeholder': 'Search for a country...',
    'all': 'All',
    'country': 'Country',
    'region': 'Region',
    'date': 'Date',
    'rating': 'Rating',
    'compliance': 'Compliance',
    'effectiveness': 'Effectiveness',

    // Overview table
    'overview.title': 'Overview — All countries',
    'overview.countries': 'countries',
    'overview.no': 'No.',

    // Compliance levels
    'level.Conforme': 'Compliant',
    'level.Largement Conforme': 'Largely Compliant',
    'level.Partiellement Conforme': 'Partially Compliant',
    'level.Non Conforme': 'Non-Compliant',
    'level.Non évalué': 'Not assessed',
    // Compliance levels (short for small cards)
    'levelShort.Conforme': 'C',
    'levelShort.Largement Conforme': 'LC',
    'levelShort.Partiellement Conforme': 'PC',
    'levelShort.Non Conforme': 'NC',
    'levelShort.Non évalué': 'N/A',

    // Effectiveness levels
    'level.Élevé': 'High',
    'level.Significatif': 'Substantial',
    'level.Modéré': 'Moderate',
    'level.Faible': 'Low',

    // Global ratings
    'rating.Satisfaisant': 'Satisfactory',
    'rating.Suffisant': 'Sufficient',
    'rating.Non Satisfaisant': 'Non-Satisfactory',
    'rating.Insuffisant': 'Insufficient',

    // Recommendation detail
    'rec.40detail': 'Detail of 40 Recommendations',
    'rec.sourceGafi': 'GAFI Source',
    'rec.recommendation': 'Recommendation',
    'rec.level': 'Level',
    'rec.clickDetail': 'Click on a recommendation to see details',
    'rec.listOf': 'List of recommendations rated as "{0}"',
    'rec.clickToSee': 'click on a recommendation to see details',
    'rec.total': 'Total: {0} / 40 recommendations',
    'rec.percentTotal': '{0}% of total',
    'rec.recommendation_word': 'recommendation',
    'rec.recommendations_word': 'recommendations',

    // Effectiveness / RI
    'ri.title': '11 Immediate Outcomes',
    'ri.riImmediate': 'Immediate Outcome',
    'ri.radarTitle': 'Effectiveness Radar — 11 Immediate Outcomes',
    'ri.detailTitle': 'Detail of 11 Immediate Outcomes',
    'ri.clickDetail': 'Click on an RI to see details',
    'ri.listOf': 'List of immediate outcomes rated as "{0}"',
    'ri.clickToSee': 'click on an RI to see details',
    'ri.total': 'Total: {0} / 11 immediate outcomes',
    'ri.percentTotal': '{0}% of total',
    'ri.fundamental': 'Fundamental',
    'ri.type': 'Type',
    'ri.resultat': 'outcome',
    'ri.resultats': 'outcomes',
    'ri.immediat': 'immediate',
    'ri.immediats': 'immediates',
    'ri.effLevel': 'Effectiveness level',
    'ri.efficacy': 'Effectiveness',
    'ri.immediateOutcomes': 'Immediate Outcomes',
    'ri.clickToAccess': 'Click on an RI to access details',

    // Radar axis labels (short)
    'ri.risk': 'Risks',
    'ri.intlCoop': 'Intl. coop.',
    'ri.supervision': 'Supervision',
    'ri.finPrev': 'Fin. prev.',
    'ri.nonFinPrev': 'Non-fin. prev.',
    'ri.reports': 'Reports',
    'ri.mlInvestigations': 'ML Invest.',
    'ri.tfInvestigations': 'TF Invest.',
    'ri.freeze': 'Freeze/Confisc.',
    'ri.proliferation': 'Proliferation',
    'ri.transpLP': 'Transp. LP',

    // Summary section
    'summary.title': 'Evaluation Summary',
    'summary.strengths': 'Strengths',
    'summary.improvements': 'Areas for improvement',
    'summary.riskAreas': 'Risk areas',
    'summary.prev': 'Prev.:',
    'summary.pts': 'pts',
    'summary.technicalCompliance': 'Technical Compliance',
    'summary.systemEffectiveness': 'System Effectiveness',
    'summary.evaluatedBy': 'assessed by',

    // Hero
    'hero.evalTitle': 'GAFI Standards Evaluation — {0}',
    'hero.evalDesc': 'View the mutual evaluation results including technical compliance with the 40 Recommendations and the effectiveness of the national AML/CFT system.',
    'hero.prevEval': 'Previous\nevaluation',
    'hero.lastEval': 'Latest\nevaluation',
    'hero.40rec': '40 Recommendations',
    'hero.40recSub': 'Technical compliance',
    'hero.11ri': '11 Immediate Outcomes',
    'hero.11riSub': 'System effectiveness',
    'hero.explorer': 'Explore',

    // Comparison
    'comp.radarTitle': 'Radar Comparison — Effectiveness (11 immediate outcomes)',
    'comp.radarZoom': 'Radar Comparison — Effectiveness',
    'comp.selectCountry': 'Select a country',
    'comp.searchPlaceholder': 'Search...',
    'comp.noResult': 'No results',
    'comp.country1': 'Country 1',
    'comp.selectedCountry': 'Selected country',
    'comp.countryToCompare': 'Country to compare',
    'comp.loading': 'Loading...',
    'comp.selectHint': 'select a country to compare',
    'comp.technicalCompliance': 'Technical compliance',
    'comp.systemEffectiveness': 'System effectiveness',

    // Country selector
    'cs.selectCountry': 'Select a country',
    'cs.searchPlaceholder': 'Search for a country or region...',
    'cs.countriesShown': 'countries shown',

    // Zoomable section
    'zoom.enlarge': 'Enlarge',
    'zoom.reduce': 'Reduce',
    'zoom.enlargedView': 'Enlarged view',

    // Knowledge modal
    'km.rec40': '40 Recommendations',
    'km.ri11': '11 Immediate Outcomes',
    'km.recSubtitle': 'Technical compliance with GAFI standards',
    'km.riSubtitle': 'Assessment of the effectiveness of the AML/CFT system',
    'km.keyCriteria': 'Key assessment criteria',
    'km.keyQuestions': 'Key assessment questions',
    'km.statIndicators': 'Statistical indicators (GAFI Guidelines)',
    'km.previous': '← Previous',
    'km.next': 'Next →',
    'km.fundamental': 'Fundamental',
    'km.complementary': 'Complementary',

    // RI detail sheet sections
    'riDesc.description': 'Description',
    'riDesc.characteristics': 'Characteristics of an effective system',
    'riDesc.questions': 'Essential questions',
    'riDesc.supportingInfo': 'Information examples',
    'riDesc.specificFactors': 'Specific factors',
    'riDesc.statisticalData': 'Statistical data',
    'riDesc.recommendationLinks': 'Links with Recommendations',
    'riDesc.mainRecs': 'Main recommendations',
    'riDesc.partialRecs': 'With certain elements',
    'riDesc.clickToOpen': 'Click to open the recommendation',
    'riDesc.backToList': 'Back to list',
    'riDesc.level': 'Level:',

    // Settings
    'settings.title': 'Settings',
    'settings.language': 'Language',
    'settings.import': 'Update from Excel',
    'settings.importDesc': 'Import an Excel file to update evaluation data',
    'settings.password': 'Password',
    'settings.passwordPlaceholder': 'Enter password',
    'settings.selectFile': 'Choose an Excel file',
    'settings.upload': 'Upload',
    'settings.cancel': 'Cancel',
    'settings.uploading': 'Uploading...',
    'settings.success': 'Data updated successfully!',
    'settings.error': 'Incorrect password or error during import.',
    'settings.noFile': 'Please select a file.',
    'settings.noPassword': 'Please enter the password.',

    // Footer
    'footer.library': 'GAFI Standards and Evaluations Visualization Library',
    'footer.source': 'Source: Financial Action Task Force (FATF) — 4th Round Ratings (Updated 27 May 2026)',
    'footer.disclaimer': 'Global ratings are calculated from official FATF data.',
    'footer.service': 'Designed by the National AML/CFT Statistics Service',
    'footer.contact': 'AML/CFT Committee — 21 22 41 77 54/56 or 07 07 56 46 56',
    'countries': 'countries',
  },
};

// Global translation function
export function t(lang: LangCode, key: string): string {
  const val = TRANSLATIONS[lang]?.[key] || TRANSLATIONS.fr[key];
  if (val) return val;
  // Fallback: if a level.* or levelShort.* key is not found, strip the prefix
  // to show the raw French label instead of the raw key like "level.Partiellement Conforme"
  if (key.startsWith('level.') || key.startsWith('levelShort.') || key.startsWith('rating.')) {
    const prefix = key.startsWith('levelShort.') ? 'levelShort.' : key.startsWith('rating.') ? 'rating.' : 'level.';
    return key.slice(prefix.length);
  }
  return key;
}

// Language context helpers stored on window for cross-component access
export function getCurrentLang(): LangCode {
  if (typeof window !== 'undefined') {
    return (localStorage.getItem('bibliogafi-lang') as LangCode) || 'fr';
  }
  return 'fr';
}

export function setCurrentLang(lang: LangCode) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('bibliogafi-lang', lang);
  }
}

interface SettingsPanelProps {
  onLanguageChange: (lang: LangCode) => void;
  onDataUpdate: () => void;
  currentLang: LangCode;
}

export default function SettingsPanel({ onLanguageChange, onDataUpdate, currentLang }: SettingsPanelProps) {
  const [open, setOpen] = useState(false);
  const [password, setPassword] = useState('');
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleUpload = useCallback(async () => {
    if (!file) {
      setMessage({ type: 'error', text: TRANSLATIONS[currentLang]['settings.noFile'] });
      return;
    }
    if (!password) {
      setMessage({ type: 'error', text: TRANSLATIONS[currentLang]['settings.noPassword'] });
      return;
    }

    setUploading(true);
    setMessage(null);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('password', password);

      const res = await fetch('/api/import-excel', {
        method: 'POST',
        body: formData,
      });

      if (res.ok) {
        const data = await res.json();
        setMessage({ type: 'success', text: TRANSLATIONS[currentLang]['settings.success'] });
        setPassword('');
        setFile(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        onDataUpdate();
      } else {
        const data = await res.json().catch(() => ({}));
        setMessage({
          type: 'error',
          text: data.error || TRANSLATIONS[currentLang]['settings.error'],
        });
      }
    } catch {
      setMessage({ type: 'error', text: TRANSLATIONS[currentLang]['settings.error'] });
    } finally {
      setUploading(false);
    }
  }, [file, password, currentLang, onDataUpdate]);

  return (
    <>
      {/* Settings button */}
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="p-2 rounded-lg hover:bg-gray-100 transition-colors text-gray-500 hover:text-gray-700"
        title={TRANSLATIONS[currentLang]['settings.title']}
      >
        <Settings className="w-5 h-5" />
      </button>

      {/* Settings panel overlay */}
      {open && (
        <div className="fixed inset-0 z-[300] flex items-end sm:items-center justify-center">
          <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={() => setOpen(false)} />
          <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 mb-4 sm:mb-0 overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-200">
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b bg-gray-50">
              <h2 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
                <Settings className="w-5 h-5 text-gray-500" />
                {TRANSLATIONS[currentLang]['settings.title']}
              </h2>
              <button onClick={() => setOpen(false)} className="p-1.5 hover:bg-gray-200 rounded-lg transition-colors">
                <X className="w-5 h-5 text-gray-500" />
              </button>
            </div>

            {/* Body */}
            <div className="p-6 space-y-6 max-h-[70vh] overflow-y-auto">
              {/* Language selector */}
              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-3">
                  <Globe className="w-4 h-4" />
                  {TRANSLATIONS[currentLang]['settings.language']}
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {LANGUAGES.map((lang) => (
                    <button
                      key={lang.code}
                      type="button"
                      onClick={() => {
                        onLanguageChange(lang.code);
                        setCurrentLang(lang.code);
                      }}
                      className={`flex items-center gap-2 px-4 py-3 rounded-xl border-2 transition-all duration-200 text-left ${
                        currentLang === lang.code
                          ? 'border-sky-500 bg-sky-50 text-sky-700 shadow-sm'
                          : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50 text-gray-700'
                      }`}
                    >
                      <span className="text-lg">{lang.flag}</span>
                      <span className="text-sm font-medium">{lang.label}</span>
                      {currentLang === lang.code && (
                        <Check className="w-4 h-4 text-sky-500 ml-auto" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Excel import */}
              <div>
                <label className="flex items-center gap-2 text-sm font-semibold text-gray-700 mb-1">
                  <Upload className="w-4 h-4" />
                  {TRANSLATIONS[currentLang]['settings.import']}
                </label>
                <p className="text-xs text-gray-500 mb-3 ml-6">
                  {TRANSLATIONS[currentLang]['settings.importDesc']}
                </p>

                {/* Password field */}
                <div className="relative mb-3">
                  <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder={TRANSLATIONS[currentLang]['settings.passwordPlaceholder']}
                    className="w-full pl-10 pr-4 py-2.5 text-sm border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-sky-500 focus:border-sky-500 transition-all"
                  />
                </div>

                {/* File selector */}
                <div className="mb-3">
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept=".xlsx,.xls"
                    onChange={(e) => setFile(e.target.files?.[0] || null)}
                    className="hidden"
                    id="excel-upload"
                  />
                  <label
                    htmlFor="excel-upload"
                    className="flex items-center justify-center gap-2 px-4 py-3 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:border-sky-400 hover:bg-sky-50/50 transition-all text-sm text-gray-600"
                  >
                    <Upload className="w-4 h-4" />
                    {file ? (
                      <span className="text-sky-700 font-medium truncate">{file.name}</span>
                    ) : (
                      <span>{TRANSLATIONS[currentLang]['settings.selectFile']}</span>
                    )}
                  </label>
                </div>

                {/* Upload button */}
                <button
                  type="button"
                  onClick={handleUpload}
                  disabled={uploading || !file || !password}
                  className="w-full py-2.5 px-4 bg-sky-600 hover:bg-sky-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white text-sm font-medium rounded-xl transition-colors flex items-center justify-center gap-2"
                >
                  {uploading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      {TRANSLATIONS[currentLang]['settings.uploading']}
                    </>
                  ) : (
                    <>
                      <Upload className="w-4 h-4" />
                      {TRANSLATIONS[currentLang]['settings.upload']}
                    </>
                  )}
                </button>

                {/* Message */}
                {message && (
                  <div
                    className={`mt-3 flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm ${
                      message.type === 'success'
                        ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                        : 'bg-red-50 text-red-700 border border-red-200'
                    }`}
                  >
                    {message.type === 'success' ? (
                      <Check className="w-4 h-4 flex-shrink-0" />
                    ) : (
                      <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    )}
                    {message.text}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}