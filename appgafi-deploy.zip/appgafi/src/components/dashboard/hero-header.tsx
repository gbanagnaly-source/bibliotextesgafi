'use client';

import { CountryData } from './types';
import { t } from './settings-panel';
import { InfoModal } from './gafi-knowledge-modal';
import AnimatedWorldMap from './animated-world-map';

interface HeroHeaderProps {
  data: CountryData | null;
  loading: boolean;
  onOpenKnowledge: (type: string, id: number) => void;
  onOpenRISheet: () => void;
  lang?: 'fr' | 'en';
}

function getRatingDisplay(rating: string, lang: 'fr' | 'en'): string {
  const ratingKeyMap: Record<string, string> = {
    'Satisfaisant': 'rating.Satisfaisant',
    'Suffisant': 'rating.Suffisant',
    'Non Satisfaisant': 'rating.Non Satisfaisant',
    'Insuffisant': 'rating.Insuffisant',
  };
  const key = ratingKeyMap[rating];
  return key ? t(lang, key) : rating;
}

function getRatingColor(rating: string): string {
  switch (rating) {
    case 'Satisfaisant': return 'bg-emerald-500';
    case 'Suffisant': return 'bg-amber-500';
    case 'Non Satisfaisant': return 'bg-orange-500';
    case 'Insuffisant': return 'bg-red-600';
    default: return 'bg-gray-500';
  }
}

function CountryFlag({ code, name, size = 48 }: { code?: string; name?: string; size?: number }) {
  const flagCode = code || '';
  if (!flagCode) return (
    <div
      className="rounded shadow-lg flex items-center justify-center bg-white/10"
      style={{ minWidth: size, width: size, height: Math.round(size * 0.67) }}
    >
      <span className="text-white/60 text-xs">N/A</span>
    </div>
  );
  return (
    <img
      src={`https://flagcdn.com/w80/${flagCode}.png`}
      alt={`Drapeau ${name || ''}`}
      width={size}
      height={Math.round(size * 0.67)}
      className="rounded shadow-lg object-cover"
      style={{ minWidth: size }}
      loading="lazy"
    />
  );
}

export default function HeroHeader({ data, loading, onOpenKnowledge, onOpenRISheet, lang = 'fr' }: HeroHeaderProps) {
  if (loading) {
    return (
      <header className="relative overflow-hidden animate-pulse" style={{ background: 'linear-gradient(135deg, #0a1628 0%, #0f2442 40%, #132e52 100%)', minHeight: 280 }}>
        <div className="relative z-10 px-4 sm:px-8 lg:px-12 pt-8 pb-8 space-y-6">
          <div className="h-10 w-64 bg-white/10 rounded" />
          <div className="h-6 w-96 bg-white/10 rounded" />
          <div className="h-4 w-[600px] bg-white/10 rounded" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="h-24 bg-white/5 rounded-xl" />
            <div className="h-24 bg-white/5 rounded-xl" />
            <div className="h-24 bg-white/5 rounded-xl" />
          </div>
        </div>
      </header>
    );
  }

  const prevExists = data.previousEvaluation.date !== '' && data.previousEvaluation.date !== 'N/A';
  const prevRating = prevExists ? data.previousEvaluation.globalRating : 'N/A';

  return (
    <header className="relative overflow-hidden" style={{ background: 'linear-gradient(135deg, #0a1628 0%, #0f2442 40%, #132e52 100%)' }}>
      {/* Animated World Map Background */}
      <AnimatedWorldMap />

      {/* Top: flag + country name */}
      <div className="relative z-10 px-4 sm:px-8 lg:px-12 pt-8 pb-4">
        <div className="flex flex-col md:flex-row items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <CountryFlag code={data.countryCode} name={data.countryName} size={72} />
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white tracking-tight">
              {data.countryName}
            </h1>
          </div>


        </div>
      </div>

      {/* Title & Description */}
      <div className="relative z-10 px-4 sm:px-8 lg:px-12 pb-6">
        <h2 className="text-lg sm:text-xl text-sky-200 font-semibold mb-2">
          {t(lang, 'hero.evalTitle').replace('{0}', data.latestEvaluation.date)}
        </h2>
        <p className="text-sm sm:text-base text-blue-100/80 max-w-4xl leading-relaxed">
          {t(lang, 'hero.evalDesc')}
          <span className="text-blue-200/60 ml-2">({data.reportType})</span>
        </p>
      </div>

      {/* Data Cards */}
      <div className="relative z-10 px-4 sm:px-8 lg:px-12 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          {/* Previous Evaluation — compact */}
          <div className="md:col-span-3 rounded-xl p-4 flex items-center gap-3" style={{ background: 'rgba(255,255,255,0.07)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <div className="flex items-center justify-center w-10 h-10 rounded-lg flex-shrink-0" style={{ background: 'rgba(56, 189, 248, 0.2)' }}>
              <svg className="w-5 h-5 text-sky-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
            </div>
            <div className="min-w-0">
              <p className="text-[10px] text-blue-200/70 uppercase tracking-wider font-medium leading-tight whitespace-pre-line">{t(lang, 'hero.prevEval')}</p>
              <p className="text-lg font-bold text-white mt-0.5">{prevExists ? data.previousEvaluation.date : 'N/A'}</p>
            </div>
            <div className="flex flex-col items-end flex-shrink-0">
              {prevExists && (
                <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold text-white ${getRatingColor(prevRating)}`}>
                  {getRatingDisplay(prevRating, lang)}
                </span>
              )}
              <span className="text-[9px] text-blue-200/50 mt-1 max-w-[120px] text-right leading-tight">{t(lang, 'summary.evaluatedBy')} {data.assessmentBody}</span>
            </div>
          </div>

          {/* Latest Evaluation — compact */}
          <div className="md:col-span-3 rounded-xl p-4 flex items-center gap-3" style={{ background: 'rgba(255,255,255,0.07)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.1)' }}>
            <div className="flex items-center justify-center w-10 h-10 rounded-lg flex-shrink-0" style={{ background: 'rgba(56, 189, 248, 0.2)' }}>
              <svg className="w-5 h-5 text-sky-300" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
            </div>
            <div className="min-w-0">
              <p className="text-[10px] text-blue-200/70 uppercase tracking-wider font-medium leading-tight whitespace-pre-line">{t(lang, 'hero.lastEval')}</p>
              <p className="text-lg font-bold text-white mt-0.5">{data.latestEvaluation.date}</p>
            </div>
            <div className="flex flex-col items-end flex-shrink-0">
              <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold text-white ${getRatingColor(data.latestEvaluation.globalRating)} ${data.latestEvaluation.globalRating === 'Insuffisant' ? 'blink-insuffisant' : ''}`}>
                {getRatingDisplay(data.latestEvaluation.globalRating, lang)}
              </span>
              <span className="text-[9px] text-blue-200/50 mt-1 max-w-[120px] text-right leading-tight">{t(lang, 'summary.evaluatedBy')} {data.assessmentBody}</span>
            </div>
          </div>

          {/* 40 Recommandations — clearly clickable */}
          <button
            type="button"
            onClick={() => onOpenKnowledge('rec', 0)}
            className="md:col-span-3 rounded-xl p-4 flex items-center gap-3 cursor-pointer group transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
            style={{ background: 'rgba(56, 189, 248, 0.12)', backdropFilter: 'blur(10px)', border: '1.5px solid rgba(56, 189, 248, 0.35)', boxShadow: '0 0 20px rgba(56, 189, 248, 0.1)' }}
          >
            <div className="flex items-center justify-center w-10 h-10 rounded-lg flex-shrink-0" style={{ background: 'rgba(56, 189, 248, 0.3)' }}>
              <svg className="w-5 h-5 text-sky-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253" /></svg>
            </div>
            <div className="min-w-0 flex-1 text-left">
              <p className="text-sm font-bold text-white group-hover:text-sky-200 transition-colors">{t(lang, 'hero.40rec')}</p>
              <p className="text-[10px] text-blue-200/70">{t(lang, 'hero.40recSub')}</p>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <span className="text-[9px] font-semibold text-sky-300/80 uppercase tracking-wider group-hover:text-sky-200 transition-colors">{t(lang, 'hero.explorer')}</span>
              <svg className="w-4 h-4 text-sky-300/60 group-hover:text-sky-200 group-hover:translate-x-0.5 transition-all" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
            </div>
          </button>

          {/* 11 Résultats immédiats — clearly clickable */}
          <button
            type="button"
            onClick={onOpenRISheet}
            className="md:col-span-3 rounded-xl p-4 flex items-center gap-3 cursor-pointer group transition-all duration-300 hover:scale-[1.02] active:scale-[0.98]"
            style={{ background: 'rgba(52, 211, 153, 0.12)', backdropFilter: 'blur(10px)', border: '1.5px solid rgba(52, 211, 153, 0.35)', boxShadow: '0 0 20px rgba(52, 211, 153, 0.1)' }}
          >
            <div className="flex items-center justify-center w-10 h-10 rounded-lg flex-shrink-0" style={{ background: 'rgba(52, 211, 153, 0.3)' }}>
              <svg className="w-5 h-5 text-emerald-200" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
            </div>
            <div className="min-w-0 flex-1 text-left">
              <p className="text-sm font-bold text-white group-hover:text-emerald-200 transition-colors">{t(lang, 'hero.11ri')}</p>
              <p className="text-[10px] text-blue-200/70">{t(lang, 'hero.11riSub')}</p>
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <span className="text-[9px] font-semibold text-emerald-300/80 uppercase tracking-wider group-hover:text-emerald-200 transition-colors">{t(lang, 'hero.explorer')}</span>
              <svg className="w-4 h-4 text-emerald-300/60 group-hover:text-emerald-200 group-hover:translate-x-0.5 transition-all" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
            </div>
          </button>
        </div>
      </div>
    </header>
  );
}