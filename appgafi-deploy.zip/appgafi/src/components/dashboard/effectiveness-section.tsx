'use client';

import { useState, useEffect } from 'react';
import { CountryData, EffectivenessLevel } from './types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, Tooltip,
} from 'recharts';
import { ChartContainer } from '@/components/ui/chart';
import RIDetailSheet from './ri-detail-sheet';
import ZoomableSection from './zoomable-section';
import { t, LangCode } from '@/components/dashboard/settings-panel';

interface RIData {
  id: number;
  shortTitle: string;
  title: string;
  description: string;
  characteristics: string;
  essentialQuestions: string[];
  supportingInfo: string[];
  specificFactors: string[];
  statisticalData: string[];
  mainRecommendations: number[];
  partialRecommendations: { rec: number; elements: string }[];
}

interface EffectivenessSectionProps {
  data: CountryData;
  onOpenRec?: (recId: number) => void;
  lang?: LangCode;
}

const EFFECTIVENESS_CODE_MAP: Record<string, string> = {
  'Élevé': 'Élevé',
  'Significatif': 'Significatif',
  'Modéré': 'Modéré',
  'Faible': 'Faible',
  'N/A': 'Non évalué',
};

const effScore: Record<string, number> = {
  'Élevé': 4, 'Significatif': 3, 'Modéré': 2, 'Faible': 1, 'Non évalué': 0,
};

const effColor: Record<string, string> = {
  'Élevé': '#22c55e',
  'Significatif': '#84cc16',
  'Modéré': '#f97316',
  'Faible': '#ef4444',
  'Non évalué': '#9ca3af',
};

const effColorLight: Record<string, string> = {
  'Élevé': '#dcfce7',
  'Significatif': '#f7fee7',
  'Modéré': '#fff7ed',
  'Faible': '#fef2f2',
  'Non évalué': '#f3f4f6',
};

const effColorDark: Record<string, string> = {
  'Élevé': '#16a34a',
  'Significatif': '#65a30d',
  'Modéré': '#c2410c',
  'Faible': '#b91c1c',
  'Non évalué': '#6b7280',
};

/* ── Custom angle axis tick: RI number + short label colored by level ── */
function RadarAngleTick(props: any) {
  try {
    const { x, y, payload, index } = props || {};
    if (!payload || !payload.value) return null;
    const riId = (index ?? 0) + 1;
    const cx = typeof x === 'number' ? x : 0;
    const cy = typeof y === 'number' ? y : 0;
    const level = payload.payload?.level || '';
    const color = effColor[level] || '#94a3b8';
    return (
      <g className="cursor-pointer">
        <text x={cx} y={cy - 14} textAnchor="middle" fill="#0284c7" fontSize={10} fontWeight={700}>
          {`RI.${riId}`}
        </text>
        <text x={cx} y={cy + 2} textAnchor="middle" fill={color} fontSize={10.5} fontWeight={600}>
          {payload.value}
        </text>
      </g>
    );
  } catch {
    return null;
  }
}

function EffectivenessDice({ name, count, color, colorLight, colorDark, total, onClick }: {
  name: string;
  count: number;
  color: string;
  colorLight: string;
  colorDark: string;
  total: number;
  onClick: () => void;
}) {
  const pct = Math.round((count / total) * 100);

  return (
    <div className="relative group" onClick={onClick}>
      <div
        className="relative rounded-2xl p-5 transition-all duration-300 group-hover:scale-[1.04] group-hover:shadow-xl cursor-pointer h-full"
        style={{
          background: `linear-gradient(145deg, ${colorLight} 0%, white 60%, ${colorLight} 100%)`,
          border: `1.5px solid ${color}30`,
          boxShadow: `
            0 4px 6px -1px rgba(0,0,0,0.08),
            0 2px 4px -2px rgba(0,0,0,0.06),
            inset 0 1px 0 rgba(255,255,255,0.9),
            inset 0 -2px 4px rgba(0,0,0,0.04)
          `,
        }}
      >
        <p
          className="text-[10px] sm:text-[11px] font-bold uppercase tracking-widest mt-1 mb-3 text-center"
          style={{ color: colorDark }}
        >
          {name}
        </p>
        <div className="flex items-end justify-center gap-1.5">
          <span
            className="text-4xl sm:text-5xl font-extrabold leading-none"
            style={{
              color: colorDark,
              textShadow: `0 1px 2px ${colorLight}`,
            }}
          >
            {count}
          </span>
          <span className="text-xs font-medium mb-1" style={{ color: color }}>
            / {total}
          </span>
        </div>
        <div
          className="mt-3 h-1.5 rounded-full overflow-hidden"
          style={{ backgroundColor: `${color}20` }}
        >
          <div
            className="h-full rounded-full transition-all duration-700 ease-out"
            style={{
              width: `${pct}%`,
              background: `linear-gradient(90deg, ${color}, ${colorDark})`,
            }}
          />
        </div>
        <p className="text-[10px] font-semibold mt-1.5 text-center" style={{ color: color }}>
          {pct}%
        </p>
        <div
          className="absolute bottom-3 left-4 w-2 h-2 rounded-full opacity-20"
          style={{ backgroundColor: color }}
        />
        <div
          className="absolute bottom-3 left-4 w-2 h-2 rounded-full opacity-20"
          style={{ backgroundColor: color, marginLeft: '10px' }}
        />
        <div
          className="absolute bottom-3 left-4 w-2 h-2 rounded-full opacity-20"
          style={{ backgroundColor: color, marginLeft: '20px' }}
        />
      </div>
    </div>
  );
}

export default function EffectivenessSection({ data, onOpenRec, lang = 'fr' }: EffectivenessSectionProps) {
  const [riDetails, setRiDetails] = useState<Record<number, RIData>>({});
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);
  const [dialogSelectedRI, setDialogSelectedRI] = useState<number | null>(null);

  useEffect(() => {
    fetch('/data/ri-details.json')
      .then(r => r.json())
      .then((items: RIData[]) => {
        const map: Record<number, RIData> = {};
        items.forEach(ri => { map[ri.id] = ri; });
        setRiDetails(map);
      })
      .catch(() => {});
  }, []);

  const radarData = data.immediateResults.map((r) => ({
    name: r.shortTitle,
    value: effScore[r.effectiveness] || 0,
    fullMark: 4,
    level: r.effectiveness,
    riId: r.id,
  }));

  const chartConfig = {
    value: { label: t(lang, 'ri.effLevel'), color: '#0ea5e9' },
  };

  const total = 11;
  const levels: EffectivenessLevel[] = ['Élevé', 'Significatif', 'Modéré', 'Faible', 'Non évalué'];
  const distribution = levels.map((level) => ({
    name: level,
    count: data.immediateResults.filter((r) => r.effectiveness === level).length,
    fill: effColor[level],
    fillLight: effColorLight[level],
    fillDark: effColorDark[level],
  })).filter(d => d.count > 0);

  const filteredRIs = selectedLevel
    ? data.immediateResults.filter((r) => r.effectiveness === selectedLevel)
    : [];

  const radarTickLabels = [
    '',
    t(lang, 'level.Faible'),
    t(lang, 'level.Modéré'),
    t(lang, 'level.Significatif'),
    t(lang, 'level.Élevé'),
  ];

  function getEffBadgeVariant(level: string): 'default' | 'secondary' | 'destructive' | 'outline' {
    switch (level) {
      case 'Élevé': case 'Significatif': return 'default';
      case 'Modéré': return 'secondary';
      case 'Faible': return 'destructive';
      default: return 'outline';
    }
  }

  return (
    <section className="space-y-6">
      {/* Aesthetic Dice Overview — clickable */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {distribution.map((d) => (
          <EffectivenessDice
            key={d.name}
            name={d.name}
            count={d.count}
            color={d.fill}
            colorLight={d.fillLight}
            colorDark={d.fillDark}
            total={total}
            onClick={() => setSelectedLevel(d.name)}
          />
        ))}
      </div>

      {/* Statistics Dialog */}
      <Dialog open={!!selectedLevel} onOpenChange={(open) => { if (!open) setSelectedLevel(null); }}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <span
                className="w-3 h-3 rounded-full inline-block"
                style={{ backgroundColor: effColor[selectedLevel || ''] || '#9ca3af' }}
              />
              {t(lang, 'ri.listOf').replace('{0}', selectedLevel || '')} — {filteredRIs.length} {filteredRIs.length > 1 ? t(lang, 'ri.resultats') : t(lang, 'ri.resultat')} {filteredRIs.length > 1 ? t(lang, 'ri.immediats') : t(lang, 'ri.immediat')}
            </DialogTitle>
            <DialogDescription>
              {t(lang, 'ri.listOf').replace('{0}', selectedLevel || '')} — <span className="text-sky-600">{t(lang, 'ri.clickToSee')}</span>
            </DialogDescription>
          </DialogHeader>

          <div className="overflow-y-auto -mx-1 px-1">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-gray-200">
                  <th className="text-left py-2 pr-3 font-semibold text-muted-foreground w-20">{t(lang, 'overview.no')}</th>
                  <th className="text-left py-2 pr-3 font-semibold text-muted-foreground">{t(lang, 'ri.riImmediate')}</th>
                  <th className="text-center py-2 pr-3 font-semibold text-muted-foreground w-20">{t(lang, 'ri.type')}</th>
                  <th className="text-right py-2 font-semibold text-muted-foreground w-28">{t(lang, 'rec.level')}</th>
                </tr>
              </thead>
              <tbody>
                {filteredRIs.map((ri) => (
                  <tr
                    key={ri.id}
                    className="border-b border-gray-100 hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => { setDialogSelectedRI(ri.id); setSelectedLevel(null); }}
                  >
                    <td className="py-2.5 pr-3">
                      <span className="font-bold text-sky-700">RI.{ri.id}</span>
                    </td>
                    <td className="py-2.5 pr-3">
                      <span className="text-foreground">{ri.title}</span>
                    </td>
                    <td className="py-2.5 pr-3 text-center">
                      {ri.fundamental && (
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0">{t(lang, 'ri.fundamental')}</Badge>
                      )}
                    </td>
                    <td className="py-2.5 text-right">
                      <span className="text-xs font-medium" style={{ color: effColor[ri.effectiveness] || '#9ca3af' }}>{EFFECTIVENESS_CODE_MAP[ri.effectivenessCode] || ri.effectivenessCode}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Summary footer */}
          <div
            className="mt-auto pt-3 border-t flex items-center justify-between text-xs text-muted-foreground rounded-b-lg px-1"
          >
            <span>{t(lang, 'ri.total').replace('{0}', String(filteredRIs.length))}</span>
            <span>{t(lang, 'ri.percentTotal').replace('{0}', String(Math.round((filteredRIs.length / 11) * 100)))}</span>
          </div>
        </DialogContent>
      </Dialog>

      {/* Interactive Radar Chart */}
      <ZoomableSection title={t(lang, 'ri.radarTitle')}>
      <Card className="overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-sky-50 via-white to-indigo-50">
          <CardTitle className="text-lg">{lang === 'fr' ? t(lang, 'ri.radarTitle').replace(/'/g, '&apos;') : t(lang, 'ri.radarTitle')}</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <ChartContainer config={chartConfig} className="h-[500px] w-full">
            <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="70%">
              <PolarGrid
                stroke="#cbd5e1"
                strokeDasharray="4 4"
                gridType="polygon"
              />
              <PolarAngleAxis
                dataKey="name"
                tick={<RadarAngleTick />}
              />
              <PolarRadiusAxis
                angle={90}
                domain={[0, 4]}
                ticks={[1, 2, 3, 4]}
                tickFormatter={(v) => radarTickLabels[v] || ''}
                tick={{ fontSize: 9, fill: '#94a3b8' }}
                axisLine={false}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0].payload;
                  const level = d?.level || 'N/A';
                  const color = effColor[level] || '#9ca3af';
                  return (
                    <div className="rounded-lg border bg-white px-3 py-2.5 shadow-lg">
                      <p className="text-xs font-bold text-sky-700">{d?.name}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: color }} />
                        <span className="text-sm font-semibold" style={{ color }}>{level}</span>
                      </div>
                    </div>
                  );
                }}
              />
              <Radar
                name={t(lang, 'ri.efficacy')}
                dataKey="value"
                stroke="#0ea5e9"
                fill="url(#radarGradient)"
                fillOpacity={0.85}
                strokeWidth={2.5}
                dot={(props: any) => {
                  const { cx, cy, index, payload } = props;
                  const level = payload?.level || '';
                  const color = effColor[level] || '#9ca3af';
                  return (
                    <circle
                      key={index}
                      cx={cx}
                      cy={cy}
                      r={7}
                      fill={color}
                      stroke="white"
                      strokeWidth={2.5}
                      className="cursor-pointer"
                      style={{ filter: 'drop-shadow(0 1px 3px rgba(0,0,0,0.25))' }}
                    />
                  );
                }}
                activeDot={{
                  r: 10,
                  fill: '#0ea5e9',
                  stroke: 'white',
                  strokeWidth: 3,
                  style: { filter: 'drop-shadow(0 2px 6px rgba(14,165,233,0.5))' },
                }}
                animationBegin={200}
                animationDuration={1200}
                animationEasing="ease-out"
              />
              <defs>
                <radialGradient id="radarGradient" cx="50%" cy="50%" r="50%">
                  <stop offset="0%" stopColor="#0ea5e9" stopOpacity={0.35} />
                  <stop offset="70%" stopColor="#0ea5e9" stopOpacity={0.18} />
                  <stop offset="100%" stopColor="#6366f1" stopOpacity={0.08} />
                </radialGradient>
              </defs>
            </RadarChart>
          </ChartContainer>
        </CardContent>
      </Card>
      </ZoomableSection>

      {/* Detailed results — clickable to show RI details */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg">{t(lang, 'ri.detailTitle')}</CardTitle>
            <span className="text-xs text-muted-foreground">{t(lang, 'ri.clickDetail')}</span>
          </div>
        </CardHeader>
        <CardContent>
          <div className="max-h-[500px] overflow-y-auto pr-2 space-y-2">
            {data.immediateResults.map((result) => (
              <RIDetailSheet
                key={result.id}
                riId={result.id}
                riData={riDetails[result.id] || null}
                onOpenRec={onOpenRec}
              >
                <div
                  className="flex items-start gap-3 p-3 rounded-lg border hover:bg-sky-50/50 hover:border-sky-200 transition-colors cursor-pointer"
                >
                  <div
                    className="w-1 self-stretch rounded-full flex-shrink-0 mt-0.5"
                    style={{ backgroundColor: effColor[result.effectiveness] || '#9ca3af' }}
                  />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="text-sm font-semibold text-foreground">RI.{result.id}</span>
                      <span className="text-sm text-foreground">{result.title}</span>
                      {result.fundamental && (
                        <Badge variant="outline" className="text-[10px] px-1.5 py-0">{t(lang, 'ri.fundamental')}</Badge>
                      )}
                      <Badge
                        className="ml-auto text-xs text-white border-0"
                        style={{ backgroundColor: effColor[result.effectiveness] || '#9ca3af' }}
                      >
                        {result.effectiveness}
                      </Badge>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">{result.description}</p>
                  </div>
                </div>
              </RIDetailSheet>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* RI Detail Sheet opened from Dialog table click */}
      {dialogSelectedRI !== null && (
        <RIDetailSheet
          key={`dialog-ri-${dialogSelectedRI}`}
          riId={dialogSelectedRI}
          riData={riDetails[dialogSelectedRI] || null}
          onOpenRec={onOpenRec}
          initialOpen={true}
        >
          <div />
        </RIDetailSheet>
      )}
    </section>
  );
}