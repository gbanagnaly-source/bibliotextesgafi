'use client';

import { useState, useRef, useEffect, useCallback } from 'react';
import { X, BookOpen, BarChart3, ChevronRight, ExternalLink } from 'lucide-react';
import { RECOMMANDATIONS, RESULTATS_IMMÉDIATS } from '@/data/gafi-knowledge';
import { t, type LangCode } from '@/components/dashboard/settings-panel';

// Modal component for displaying detailed info
export function InfoModal({ open, onClose, content, initialId, lang = 'fr' }: {
  open: boolean;
  onClose: () => void;
  content: 'rec' | 'ri';
  initialId?: number;
  lang?: LangCode;
}) {
  const [activeId, setActiveId] = useState<number>(initialId || 1);
  const listRef = useRef<HTMLDivElement>(null);

  const items = content === 'rec' ? RECOMMANDATIONS : RESULTATS_IMMÉDIATS;

  // Sync activeId when initialId or content changes (single effect avoids race condition)
  useEffect(() => {
    if (initialId) {
      setActiveId(initialId);
    } else {
      setActiveId(1);
    }
  }, [initialId, content]);

  const activeItem = items.find(i => i.id === activeId);

  useEffect(() => {
    if (open) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
    }
    return () => { document.body.style.overflow = ''; };
  }, [open]);

  // Scroll active item into view
  useEffect(() => {
    const el = listRef.current?.querySelector(`[data-id="${activeId}"]`);
    if (el) el.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }, [activeId]);

  const handleKey = useCallback((e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
    if (e.key === 'ArrowDown' || e.key === 'ArrowRight') {
      e.preventDefault();
      setActiveId(prev => Math.min(prev + 1, items.length));
    }
    if (e.key === 'ArrowUp' || e.key === 'ArrowLeft') {
      e.preventDefault();
      setActiveId(prev => Math.max(prev - 1, 1));
    }
  }, [onClose, items.length]);

  useEffect(() => {
    if (open) window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [open, handleKey]);

  if (!open || !activeItem) return null;

  const ratingInfo = content === 'rec'
    ? null
    : (activeItem as any).effectiveness
      ? null
      : null;

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
        onClick={onClose}
      />

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-5xl max-h-[90vh] flex flex-col overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b bg-gradient-to-r from-slate-800 to-slate-900 text-white rounded-t-2xl">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-white/15">
              {content === 'rec' ? (
                <BookOpen className="w-5 h-5" />
              ) : (
                <BarChart3 className="w-5 h-5" />
              )}
            </div>
            <div>
              <h2 className="text-lg font-bold">
                {content === 'rec' ? t(lang, 'km.rec40') : t(lang, 'km.ri11')}
              </h2>
              <p className="text-xs text-blue-200">
                {content === 'rec'
                  ? t(lang, 'km.recSubtitle')
                  : t(lang, 'km.riSubtitle')}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="https://www.fatf-gafi.org/fr/publications/Evaluationsmutuelles/Fatf-methodology.html"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-white/10 hover:bg-white/20 rounded-lg transition-colors"
            >
              {t(lang, 'rec.sourceGafi')} <ExternalLink className="w-3 h-3" />
            </a>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex flex-1 overflow-hidden">
          {/* Sidebar list */}
          <div
            ref={listRef}
            className="w-72 border-r bg-gray-50 overflow-y-auto flex-shrink-0"
          >
            <div className="p-2">
              {items.map(item => (
                <button
                  key={item.id}
                  data-id={item.id}
                  onClick={() => setActiveId(item.id)}
                  className={`w-full flex items-center gap-2 px-3 py-2.5 rounded-lg text-left text-sm transition-colors group ${
                    item.id === activeId
                      ? 'bg-sky-100 text-sky-800 font-semibold'
                      : 'text-gray-700 hover:bg-gray-100'
                  }`}
                >
                  <span className={`flex items-center justify-center w-8 h-8 rounded-md text-xs font-bold flex-shrink-0 ${
                    item.id === activeId
                      ? 'bg-sky-500 text-white'
                      : 'bg-gray-200 text-gray-600 group-hover:bg-gray-300'
                  }`}>
                    {content === 'rec' ? `R${item.id}` : `RI${item.id}`}
                  </span>
                  <span className="flex-1 truncate text-[13px]">
                    {content === 'rec'
                      ? (item as any).title
                      : (item as any).shortTitle}
                  </span>
                  <ChevronRight className={`w-3.5 h-3.5 flex-shrink-0 ${
                    item.id === activeId ? 'text-sky-500' : 'text-gray-300'
                  }`} />
                </button>
              ))}
            </div>
          </div>

          {/* Detail panel */}
          <div className="flex-1 overflow-y-auto p-6">
            <div className="max-w-2xl">
              {/* Title */}
              <div className="flex items-start gap-3 mb-4">
                <span className="flex items-center justify-center w-12 h-12 rounded-xl bg-sky-100 text-sky-700 font-bold text-lg flex-shrink-0">
                  {content === 'rec' ? `R${activeItem.id}` : `RI${activeItem.id}`}
                </span>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">
                    {content === 'rec'
                      ? (activeItem as any).fullTitle
                      : (activeItem as any).title}
                  </h3>
                  {content === 'ri' && (
                    <span className={`inline-block mt-1 px-2 py-0.5 rounded text-[11px] font-semibold ${
                      (activeItem as any).fundamental
                        ? 'bg-amber-100 text-amber-700'
                        : 'bg-gray-100 text-gray-600'
                    }`}>
                      {(activeItem as any).fundamental ? t(lang, 'km.fundamental') : t(lang, 'km.complementary')}
                    </span>
                  )}
                </div>
              </div>

              {/* Description */}
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">Description</h4>
                <p className="text-sm text-gray-700 leading-relaxed">
                  {(activeItem as any).description}
                </p>
              </div>

              {/* Key Criteria / Key Questions */}
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2">
                  {content === 'rec' ? t(lang, 'km.keyCriteria') : t(lang, 'km.keyQuestions')}
                </h4>
                <ul className="space-y-2">
                  {(content === 'rec'
                    ? (activeItem as any).keyCriteria
                    : (activeItem as any).keyQuestions
                  ).map((item: string, i: number) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-gray-700">
                      <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-sky-400 flex-shrink-0" />
                      {item}
                    </li>
                  ))}
                </ul>
              </div>

              {/* Statistics Indicators */}
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" />
                  {t(lang, 'km.statIndicators')}
                </h4>
                <div className="bg-gray-50 rounded-xl p-4 space-y-2">
                  {(activeItem as any).statisticsIndicators.map((indicator: string, i: number) => (
                    <div key={i} className="flex items-start gap-2 text-sm">
                      <span className="mt-0.5 text-emerald-500 flex-shrink-0">●</span>
                      <span className="text-gray-600">{indicator}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Navigation */}
              <div className="flex items-center justify-between pt-4 border-t">
                <button
                  onClick={() => setActiveId(prev => Math.max(prev - 1, 1))}
                  disabled={activeId === 1}
                  className="px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                >
                  {t(lang, 'km.previous')}
                </button>
                <span className="text-xs text-gray-400">
                  {activeItem.id} / {items.length}
                </span>
                <button
                  onClick={() => setActiveId(prev => Math.min(prev + 1, items.length))}
                  disabled={activeItem === items.length}
                  className="px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
                >
                  {t(lang, 'km.next')}
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Wrapper that makes a card clickable
interface KnowledgeCardWrapperProps {
  children: React.ReactNode;
  type: 'rec' | 'ri';
  onOpen: (type: 'rec' | 'ri') => void;
}

export function KnowledgeCardWrapper({ children, type, onOpen }: KnowledgeCardWrapperProps) {
  return (
    <button
      type="button"
      onClick={() => onOpen(type)}
      className="flex-1 p-4 flex items-center gap-3 rounded-xl transition-all duration-200 hover:scale-[1.02] hover:shadow-lg cursor-pointer text-left group"
      style={{
        background: 'rgba(255,255,255,0.07)',
        backdropFilter: 'blur(10px)',
        border: '1px solid rgba(255,255,255,0.1)',
      }}
    >
      {children}
      <div className="ml-auto flex-shrink-0 w-8 h-8 rounded-full bg-white/10 flex items-center justify-center group-hover:bg-white/20 transition-colors">
        <svg className="w-4 h-4 text-white/70 group-hover:text-white transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
        </svg>
      </div>
    </button>
  );
}

export function useGafiKnowledge() {
  const [modalOpen, setModalOpen] = useState(false);
  const [contentType, setContentType] = useState<'rec' | 'ri'>('rec');
  const [initialId, setInitialId] = useState<number | undefined>(undefined);

  const handleOpen = useCallback((type: 'rec' | 'ri', id?: number) => {
    setContentType(type);
    setInitialId(id);
    setModalOpen(true);
  }, []);

  const handleClose = useCallback(() => {
    setModalOpen(false);
    setInitialId(undefined);
  }, []);

  return { modalOpen, contentType, initialId, handleOpen, handleClose };
}