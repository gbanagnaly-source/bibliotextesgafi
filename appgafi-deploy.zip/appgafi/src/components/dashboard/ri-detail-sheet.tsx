'use client';

import { useState } from 'react';
import {
  Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger,
} from '@/components/ui/sheet';
import {
  Accordion, AccordionContent, AccordionItem, AccordionTrigger,
} from '@/components/ui/accordion';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { ScrollText, AlertCircle, BarChart3, Link2, Info, FileQuestion, ClipboardCheck, ExternalLink } from 'lucide-react';
import { RECOMMANDATIONS } from '@/data/gafi-knowledge';
import { t, type LangCode } from '@/components/dashboard/settings-panel';

interface RIDetail {
  id: number;
  shortTitle: string;
  title: string;
  description: string;
  characteristics: string;
  essentialQuestions: string[];
  supportingInfo: string[];
  specificFactors: string[];
  statisticalData: string[];
  mainRecommendations: number[];
  partialRecommendations: { rec: number; elements: string }[];
}

const numberColorMap: Record<string, { numBg: string; numText: string }> = {
  sky: { numBg: 'bg-sky-100', numText: 'text-sky-700' },
  emerald: { numBg: 'bg-emerald-100', numText: 'text-emerald-700' },
  amber: { numBg: 'bg-amber-100', numText: 'text-amber-700' },
  indigo: { numBg: 'bg-indigo-100', numText: 'text-indigo-700' },
  orange: { numBg: 'bg-orange-100', numText: 'text-orange-700' },
  teal: { numBg: 'bg-teal-100', numText: 'text-teal-700' },
};

/* ── Recommendation badge with tooltip + click ── */
function RecBadge({ recId, lang = 'fr', onOpenRec }: { recId: number; lang?: LangCode; onOpenRec?: (id: number) => void }) {
  const rec = RECOMMANDATIONS.find(r => r.id === recId);
  const label = `R.${recId}`;
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <button
          type="button"
          onClick={(e) => { e.stopPropagation(); onOpenRec?.(recId); }}
          className="inline-flex items-center gap-1 bg-purple-600 hover:bg-purple-700 text-[11px] px-3 py-1 shadow-sm font-medium rounded-md transition-colors cursor-pointer"
        >
          {label}
          <ExternalLink className="w-2.5 h-2.5 opacity-60" />
        </button>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="max-w-xs">
        <p className="font-semibold text-purple-900">{label} — {rec?.title || ''}</p>
        <p className="text-[11px] text-gray-500 mt-0.5">{t(lang, 'riDesc.clickToOpen')}</p>
      </TooltipContent>
    </Tooltip>
  );
}

function PartialRecBadge({ recId, elements, lang = 'fr', onOpenRec }: { recId: number; elements: string; lang?: LangCode; onOpenRec?: (id: number) => void }) {
  const rec = RECOMMANDATIONS.find(r => r.id === recId);
  const label = `R.${recId}`;
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <div
          role="button"
          tabIndex={0}
          onClick={(e) => { e.stopPropagation(); onOpenRec?.(recId); }}
          onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); onOpenRec?.(recId); } }}
          className="flex items-start gap-2.5 p-3 rounded-xl bg-purple-50/50 border border-purple-100/80 cursor-pointer hover:bg-purple-100/60 transition-colors"
        >
          <Badge variant="outline" className="text-[11px] border-purple-300 text-purple-700 bg-white flex-shrink-0 mt-0.5 font-medium">
            {label}
            <ExternalLink className="w-2.5 h-2.5 ml-1 opacity-50" />
          </Badge>
          <span className="text-[12px] text-gray-600 leading-relaxed mt-0.5">{elements}</span>
        </div>
      </TooltipTrigger>
      <TooltipContent side="bottom" className="max-w-xs">
        <p className="font-semibold text-purple-900">{label} — {rec?.title || ''}</p>
        <p className="text-[11px] text-gray-500 mt-0.5">{t(lang, 'riDesc.clickToOpen')}</p>
      </TooltipContent>
    </Tooltip>
  );
}

export default function RIDetailSheet({ riId, children, riData, onOpenRec, initialOpen = false, lang = 'fr' }: {
  riId: number;
  children: React.ReactNode;
  riData: RIDetail | null;
  onOpenRec?: (recId: number) => void;
  initialOpen?: boolean;
  lang?: LangCode;
}) {
  const [open, setOpen] = useState(initialOpen);

  /* ── Section config (inside component to access lang) ── */
  const sections = [
    { key: 'description', label: t(lang, 'riDesc.description'), Icon: Info, color: 'sky', bg: 'bg-sky-50', iconBg: 'bg-sky-100', iconColor: 'text-sky-600', bulletColor: 'text-sky-400', borderHover: 'hover:border-sky-200' },
    { key: 'characteristics', label: t(lang, 'riDesc.characteristics'), Icon: ClipboardCheck, color: 'emerald', bg: 'bg-emerald-50', iconBg: 'bg-emerald-100', iconColor: 'text-emerald-600', bulletColor: 'text-emerald-400', borderHover: 'hover:border-emerald-200' },
    { key: 'questions', label: t(lang, 'riDesc.questions'), Icon: FileQuestion, color: 'amber', bg: 'bg-amber-50', iconBg: 'bg-amber-100', iconColor: 'text-amber-600', bulletColor: 'text-amber-400', borderHover: 'hover:border-amber-200', isNumbered: true },
    { key: 'supporting-info', label: t(lang, 'riDesc.supportingInfo'), Icon: ScrollText, color: 'indigo', bg: 'bg-indigo-50', iconBg: 'bg-indigo-100', iconColor: 'text-indigo-600', bulletColor: 'text-indigo-400', borderHover: 'hover:border-indigo-200' },
    { key: 'specific-factors', label: t(lang, 'riDesc.specificFactors'), Icon: AlertCircle, color: 'orange', bg: 'bg-orange-50', iconBg: 'bg-orange-100', iconColor: 'text-orange-600', bulletColor: 'text-orange-400', borderHover: 'hover:border-orange-200' },
    { key: 'statistical-data', label: t(lang, 'riDesc.statisticalData'), Icon: BarChart3, color: 'teal', bg: 'bg-teal-50', iconBg: 'bg-teal-100', iconColor: 'text-teal-600', bulletColor: 'text-teal-400', borderHover: 'hover:border-teal-200' },
  ] as const;

  if (!riData) return <>{children}</>;

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <div className="cursor-pointer">{children}</div>
      </SheetTrigger>
      <SheetContent side="right" className="w-full sm:max-w-2xl overflow-y-auto p-0">
        {/* ── Header with gradient ── */}
        <SheetHeader className="p-5 pb-4 sticky top-0 bg-gradient-to-r from-sky-50 via-white to-white z-10 border-b border-sky-100/60">
          <SheetTitle className="flex items-center gap-3 text-base">
            <span className="inline-flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-sky-400 to-sky-600 text-white text-sm font-bold flex-shrink-0 shadow-sm">
              {riId}
            </span>
            <div className="min-w-0">
              <span className="leading-tight block text-[15px] font-semibold text-gray-900">{riData.shortTitle}</span>
              <span className="text-[11px] text-gray-500 leading-snug block mt-0.5 line-clamp-2">{riData.title}</span>
            </div>
          </SheetTitle>
        </SheetHeader>

        <TooltipProvider delayDuration={300}>
        <div className="px-5 pb-8 pt-4">
          <Accordion type="multiple" defaultValue={['description', 'characteristics']} className="w-full space-y-1">
            {/* ── Auto-generated sections ── */}
            {sections.map((sec, secIdx) => {
              const items: string[] = (riData as any)[
                sec.key === 'description' ? 'description'
                : sec.key === 'characteristics' ? 'characteristics'
                : sec.key === 'questions' ? 'essentialQuestions'
                : sec.key === 'supporting-info' ? 'supportingInfo'
                : sec.key === 'specific-factors' ? 'specificFactors'
                : 'statisticalData'
              ];

              // Description & Characteristics are single text
              const isTextField = secIdx < 2;

              return (
                <AccordionItem key={sec.key} value={sec.key} className={`border rounded-xl ${sec.borderHover} transition-colors`}>
                  <AccordionTrigger className="gap-3 hover:no-underline px-4 py-3.5">
                    <div className="flex items-center gap-3">
                      <div className={`w-8 h-8 rounded-lg ${sec.iconBg} flex items-center justify-center flex-shrink-0`}>
                        <sec.Icon className={`w-4 h-4 ${sec.iconColor}`} />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-[10px] font-bold text-gray-400">{secIdx + 1}.</span>
                        <span className="text-[13px] font-semibold text-gray-800">{sec.label}</span>
                      </div>
                    </div>
                  </AccordionTrigger>
                  <AccordionContent className="pb-4">
                    <div className="px-4">
                      {isTextField ? (
                        <p className="text-[13px] text-gray-700 leading-[1.75]">{secIdx === 0 ? riData.description : riData.characteristics}</p>
                      ) : (
                        <ul className="space-y-3">
                          {items.map((item: string, i: number) => (
                            <li key={i} className="flex gap-3 text-[13px] text-gray-700 leading-[1.75]">
                              <span className={`inline-flex items-center justify-center w-5 h-5 rounded-md ${numberColorMap[sec.color].numBg} ${numberColorMap[sec.color].numText} text-[10px] font-bold flex-shrink-0 mt-0.5`}>
                                {i + 1}
                              </span>
                              <span className="whitespace-pre-line">{item}</span>
                            </li>
                          ))}
                        </ul>
                      )}
                    </div>
                  </AccordionContent>
                </AccordionItem>
              );
            })}

            {/* ── 7. Liens avec les Recommandations ── */}
            <AccordionItem value="recommendations" className="border rounded-xl hover:border-purple-200 transition-colors">
              <AccordionTrigger className="gap-3 hover:no-underline px-4 py-3.5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-purple-100 flex items-center justify-center flex-shrink-0">
                    <Link2 className="w-4 h-4 text-purple-600" />
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] font-bold text-gray-400">7.</span>
                    <span className="text-[13px] font-semibold text-gray-800">{t(lang, 'riDesc.recommendationLinks')}</span>
                  </div>
                </div>
              </AccordionTrigger>
              <AccordionContent className="pb-4">
                <div className="px-4 space-y-6">
                  {/* Main recommendations */}
                  {riData.mainRecommendations.length > 0 && (
                    <div>
                      <div className="flex items-center gap-2.5 mb-3">
                        <div className="h-px flex-1 bg-purple-200/80" />
                        <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-purple-600 whitespace-nowrap">
                          {t(lang, 'riDesc.mainRecs')}
                        </p>
                        <div className="h-px flex-1 bg-purple-200/80" />
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {riData.mainRecommendations.map(rec => (
                          <RecBadge key={rec} recId={rec} lang={lang} onOpenRec={onOpenRec} />
                        ))}
                      </div>
                    </div>
                  )}
                  {/* Partial recommendations */}
                  {riData.partialRecommendations.length > 0 && (
                    <div>
                      <div className="flex items-center gap-2.5 mb-3">
                        <div className="h-px flex-1 bg-purple-200/80" />
                        <p className="text-[10px] font-bold uppercase tracking-[0.1em] text-purple-500 whitespace-nowrap">
                          {t(lang, 'riDesc.partialRecs')}
                        </p>
                        <div className="h-px flex-1 bg-purple-200/80" />
                      </div>
                      <div className="space-y-2">
                        {riData.partialRecommendations.map((pr, i) => (
                          <PartialRecBadge key={i} recId={pr.rec} elements={pr.elements} lang={lang} onOpenRec={onOpenRec} />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>
        </div>
        </TooltipProvider>
      </SheetContent>
    </Sheet>
  );
}