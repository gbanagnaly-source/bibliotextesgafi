'use client';

import { useState, useMemo, useCallback } from 'react';
import { CountryListItem, CountryData } from './types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, ChevronDown, ArrowRightLeft } from 'lucide-react';
import {
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  Radar, Legend, ResponsiveContainer, Tooltip,
} from 'recharts';
import { ChartContainer, ChartLegendContent } from '@/components/ui/chart';
import ZoomableSection from './zoomable-section';
import { t, LangCode } from '@/components/dashboard/settings-panel';

/* ── Custom angle axis tick with RI number above label ── */
function RadarAngleTick(props: any) {
  try {
    const { x, y, payload, index } = props || {};
    if (!payload || !payload.value) return null;
    const ioId = (index ?? 0) + 1;
    const cx = typeof x === 'number' ? x : 0;
    const cy = typeof y === 'number' ? y : 0;
    return (
      <g>
        <text
          x={cx}
          y={cy - 12}
          textAnchor="middle"
          fill="#0284c7"
          fontSize={10}
          fontWeight={700}
        >
          {`RI.${ioId}`}
        </text>
        <text
          x={cx}
          y={cy + 4}
          textAnchor="middle"
          fill="#475569"
          fontSize={10.5}
          fontWeight={500}
        >
          {payload.value}
        </text>
      </g>
    );
  } catch {
    return null;
  }
}

// IO short labels for radar chart axes
const IO_LABELS: Record<number, string> = {
  1: 'Risques',
  2: 'Coop. intl.',
  3: 'Supervision',
  4: 'Prév. fin.',
  5: 'Prév. non fin.',
  6: 'Déclarations',
  7: 'Enquêtes BL',
  8: 'Enquêtes FT',
  9: 'Gel/Confisc.',
  10: 'Prolifération',
  11: 'Transp. PM',
};

const IO_LABELS_L10N: Record<LangCode, Record<number, string>> = {
  fr: { 1: 'Risques', 2: 'Coop. intl.', 3: 'Supervision', 4: 'Prév. fin.', 5: 'Prév. non fin.', 6: 'Déclarations', 7: 'Enquêtes BL', 8: 'Enquêtes FT', 9: 'Gel/Confisc.', 10: 'Prolifération', 11: 'Transp. PM' },
  en: { 1: 'Risks', 2: 'Intl. coop.', 3: 'Supervision', 4: 'Fin. prev.', 5: 'Non-fin. prev.', 6: 'Reports', 7: 'ML Invest.', 8: 'TF Invest.', 9: 'Freeze/Confisc.', 10: 'Proliferation', 11: 'Transp. LP' },
};

const EFFECTIVENESS_SCORE: Record<string, number> = {
  'Élevé': 100, 'Significatif': 75, 'Modéré': 50, 'Faible': 25,
};

const EFFECTIVENESS_LABEL: Record<string, string> = {
  'Élevé': 'Élevé', 'Significatif': 'Significatif', 'Modéré': 'Modéré', 'Faible': 'Faible',
};

const EFFECTIVENESS_COLOR: Record<string, string> = {
  'Élevé': '#22c55e', 'Significatif': '#84cc16', 'Modéré': '#f97316', 'Faible': '#ef4444',
};

interface ComparisonSectionProps {
  countries: CountryListItem[];
  selectedCountry: string;
  countryData: CountryData | null;
  lang?: LangCode;
}

function MiniFlag({ code, size = 18 }: { code?: string; size?: number }) {
  if (!code) return null;
  return (
    <img
      src={`https://flagcdn.com/w40/${code}.png`}
      alt=""
      width={size}
      height={Math.round(size * 0.67)}
      className="rounded-sm object-cover flex-shrink-0"
      loading="lazy"
    />
  );
}

function CountryPicker({
  countries,
  selected,
  onSelect,
  label,
  disabled = false,
  lang,
}: {
  countries: CountryListItem[];
  selected: string;
  onSelect: (name: string) => void;
  label: string;
  disabled?: boolean;
  lang: LangCode;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');

  const selectedData = countries.find(c => c.countryName === selected);

  const filtered = useMemo(() => {
    if (!search.trim()) return countries;
    const q = search.toLowerCase();
    return countries.filter(c => c.countryName.toLowerCase().includes(q));
  }, [countries, search]);

  return (
    <div className="relative">
      <label className="block text-xs font-medium text-gray-500 mb-1">{label}</label>
      <button
        type="button"
        onClick={() => { if (disabled) return; setOpen(!open); setSearch(''); }}
        className={`flex items-center gap-2 px-3 py-2.5 border rounded-lg bg-white transition-colors text-sm w-full ${
          disabled ? 'opacity-70 cursor-default border-gray-200' : 'hover:bg-gray-50 cursor-pointer'
        }`}
      >
        {selectedData && <MiniFlag code={selectedData.countryCode} size={18} />}
        <span className="flex-1 text-left truncate font-medium">
          {selectedData ? selectedData.countryName : t(lang, 'comp.selectCountry')}
        </span>
        {!disabled && <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform flex-shrink-0 ${open ? 'rotate-180' : ''}`} />}
      </button>

      {open && (
        <div className="absolute top-full left-0 mt-1 w-full bg-white border rounded-xl shadow-xl z-[100] max-h-[50vh] flex flex-col">
          <div className="p-2 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t(lang, 'comp.searchPlaceholder')}
                className="w-full pl-9 pr-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/30 focus:border-sky-500"
                autoFocus
              />
            </div>
          </div>
          <div className="overflow-y-auto flex-1">
            {filtered.map((c) => (
              <button
                key={c.countryName}
                onClick={() => { onSelect(c.countryName); setOpen(false); setSearch(''); }}
                className={`w-full flex items-center gap-2.5 px-3 py-2 text-sm hover:bg-sky-50 transition-colors text-left ${
                  c.countryName === selected ? 'bg-sky-50 text-sky-700 font-semibold' : 'text-gray-700'
                }`}
              >
                <MiniFlag code={c.countryCode} size={18} />
                <span className="flex-1 truncate">{c.countryName}</span>
                <span className="text-[10px] text-gray-400">{c.latestEvaluation.overallEffectiveness}%</span>
              </button>
            ))}
            {filtered.length === 0 && (
              <p className="px-3 py-4 text-sm text-gray-400 text-center">{t(lang, 'comp.noResult')}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export default function ComparisonSection({ countries, selectedCountry, countryData, lang = 'fr' }: ComparisonSectionProps) {
  const [compareCountry, setCompareCountry] = useState<string>('');
  const [compareData, setCompareData] = useState<CountryData | null>(null);
  const [loading, setLoading] = useState(false);

  const handleCompareSelect = useCallback(async (name: string) => {
    setCompareCountry(name);
    setLoading(true);
    try {
      const res = await fetch(`/api/evaluations?country=${encodeURIComponent(name)}`);
      const data = await res.json();
      setCompareData(data);
    } catch {
      setCompareData(null);
    }
    setLoading(false);
  }, []);

  const primaryLabel = countryData?.countryName || t(lang, 'comp.country1');
  const secondaryLabel = compareData?.countryName || '';

  // Build radar data from IOs
  const radarData = useMemo(() => {
    const axes = Array.from({ length: 11 }, (_, i) => i + 1);
    return axes.map(ioId => {
      const item: Record<string, any> = { io: IO_LABELS_L10N[lang][ioId] || IO_LABELS[ioId], ioId };

      if (countryData) {
        const io = countryData.immediateResults.find(r => r.id === ioId);
        item[primaryLabel] = io ? EFFECTIVENESS_SCORE[io.effectivenessCode] || 0 : 0;
        item[`${primaryLabel}_level`] = io ? EFFECTIVENESS_LABEL[io.effectivenessCode] || '' : '';
      }

      if (compareData) {
        const io = compareData.immediateResults.find(r => r.id === ioId);
        item[secondaryLabel] = io ? EFFECTIVENESS_SCORE[io.effectivenessCode] || 0 : 0;
        item[`${secondaryLabel}_level`] = io ? EFFECTIVENESS_LABEL[io.effectivenessCode] || '' : '';
      }

      return item;
    });
  }, [countryData, compareData, primaryLabel, secondaryLabel, lang]);

  // Also build compliance comparison summary
  const summaryStats = useMemo(() => {
    const primary = countryData;
    const secondary = compareData;
    return [
      {
        label: t(lang, 'comp.technicalCompliance'),
        primary: primary?.latestEvaluation.overallCompliance || 0,
        secondary: secondary?.latestEvaluation.overallCompliance || 0,
      },
      {
        label: t(lang, 'comp.systemEffectiveness'),
        primary: primary?.latestEvaluation.overallEffectiveness || 0,
        secondary: secondary?.latestEvaluation.overallEffectiveness || 0,
      },
    ];
  }, [countryData, compareData, lang]);

  const hasCompare = !!compareData && !loading;

  const chartConfig: Record<string, { label: string; color: string }> = {
    [primaryLabel]: { label: primaryLabel, color: '#0ea5e9' },
    ...(secondaryLabel ? { [secondaryLabel]: { label: secondaryLabel, color: '#f97316' } } : {}),
  };

  return (
    <div className="space-y-6">
      {/* Country Pickers */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5" />
            {t(lang, 'comp.radarTitle')}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <CountryPicker
                countries={countries}
                selected={selectedCountry}
                onSelect={() => {}}
                label={countryData?.countryName || t(lang, 'comp.selectedCountry')}
                disabled
                lang={lang}
              />
              {countryData && (
                <div className="mt-2 flex gap-3 text-xs text-gray-500">
                  <span>{t(lang, 'compliance')} : <b className="text-gray-800">{countryData.latestEvaluation.overallCompliance}%</b></span>
                  <span>{t(lang, 'effectiveness')} : <b className="text-gray-800">{countryData.latestEvaluation.overallEffectiveness}%</b></span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    countryData.latestEvaluation.globalRating === 'Satisfaisant' ? 'bg-emerald-100 text-emerald-700' :
                    countryData.latestEvaluation.globalRating === 'Suffisant' ? 'bg-amber-100 text-amber-700' :
                    countryData.latestEvaluation.globalRating === 'Non Satisfaisant' ? 'bg-orange-100 text-orange-700' :
                    'bg-red-100 text-red-700'
                  }`}>{t(lang, `rating.${countryData.latestEvaluation.globalRating}`)}</span>
                </div>
              )}
            </div>
            <div>
              <CountryPicker
                countries={countries.filter(c => c.countryName !== selectedCountry)}
                selected={compareCountry}
                onSelect={handleCompareSelect}
                label={compareData?.countryName || t(lang, 'comp.countryToCompare')}
                lang={lang}
              />
              {loading && <p className="mt-2 text-xs text-gray-400 animate-pulse">{t(lang, 'comp.loading')}</p>}
              {compareData && !loading && (
                <div className="mt-2 flex gap-3 text-xs text-gray-500">
                  <span>{t(lang, 'compliance')} : <b className="text-gray-800">{compareData.latestEvaluation.overallCompliance}%</b></span>
                  <span>{t(lang, 'effectiveness')} : <b className="text-gray-800">{compareData.latestEvaluation.overallEffectiveness}%</b></span>
                  <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                    compareData.latestEvaluation.globalRating === 'Satisfaisant' ? 'bg-emerald-100 text-emerald-700' :
                    compareData.latestEvaluation.globalRating === 'Suffisant' ? 'bg-amber-100 text-amber-700' :
                    compareData.latestEvaluation.globalRating === 'Non Satisfaisant' ? 'bg-orange-100 text-orange-700' :
                    'bg-red-100 text-red-700'
                  }`}>{t(lang, `rating.${compareData.latestEvaluation.globalRating}`)}</span>
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Radar Chart */}
      <ZoomableSection title={t(lang, 'comp.radarZoom')}>
      <Card>
        <CardHeader>
          <CardTitle className="text-base">
            {hasCompare
              ? `${t(lang, 'effectiveness')} : ${countryData?.countryName} vs ${compareData?.countryName}`
              : `${t(lang, 'effectiveness')} : ${countryData?.countryName} (${t(lang, 'comp.selectHint')})`}
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ChartContainer config={chartConfig} className="h-[500px] w-full">
            <RadarChart data={radarData} cx="50%" cy="50%" outerRadius="72%">
              <PolarGrid
                stroke="#e2e8f0"
                strokeDasharray="4 4"
                gridType="polygon"
              />
              <PolarAngleAxis
                dataKey="io"
                tick={<RadarAngleTick />}
              />
              <PolarRadiusAxis
                domain={[0, 100]}
                tick={{ fontSize: 9, fill: '#94a3b8' }}
                tickCount={5}
                axisLine={false}
                tickFormatter={(value: number) => {
                  if (value === 25) return t(lang, 'level.Faible');
                  if (value === 50) return t(lang, 'level.Modéré');
                  if (value === 75) return t(lang, 'level.Significatif');
                  if (value === 100) return t(lang, 'level.Élevé');
                  return String(value);
                }}
              />
              <Tooltip
                content={({ active, payload }) => {
                  if (!active || !payload?.length) return null;
                  const d = payload[0]?.payload;
                  if (!d) return null;
                  const ioId = d.ioId;
                  const ioLabel = d.io;
                  return (
                    <div className="rounded-lg border bg-white px-3 py-2.5 shadow-lg min-w-[180px]">
                      <p className="text-[10px] font-bold text-sky-700">RI.{ioId} — {ioLabel}</p>
                      <div className="mt-1.5 space-y-1">
                        {payload.map((entry: any, i: number) => {
                          const name = entry.name;
                          const levelKey = `${name}_level`;
                          const level = d[levelKey] || 'N/A';
                          const color = entry.color || (i === 0 ? '#0ea5e9' : '#f97316');
                          const lvlColor = EFFECTIVENESS_COLOR[level] || '#9ca3af';
                          const displayLevel = level !== 'N/A' ? t(lang, `level.${level}`) : level;
                          return (
                            <div key={name} className="flex items-center gap-2">
                              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: color }} />
                              <span className="text-xs text-gray-600 flex-1 truncate">{name}</span>
                              <span className="text-xs font-bold" style={{ color: lvlColor }}>{displayLevel}</span>
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  );
                }}
              />
              <Radar
                name={primaryLabel}
                dataKey={primaryLabel}
                stroke="#0ea5e9"
                fill="#0ea5e9"
                fillOpacity={0.18}
                strokeWidth={2.5}
                dot={{ r: 4, fill: '#0ea5e9', strokeWidth: 2, stroke: '#fff' }}
                activeDot={{ r: 6, fill: '#0ea5e9', strokeWidth: 2, stroke: '#fff' }}
              />
              {hasCompare && (
                <Radar
                  name={secondaryLabel}
                  dataKey={secondaryLabel}
                  stroke="#f97316"
                  fill="#f97316"
                  fillOpacity={0.12}
                  strokeWidth={2.5}
                  dot={{ r: 4, fill: '#f97316', strokeWidth: 2, stroke: '#fff' }}
                  activeDot={{ r: 6, fill: '#f97316', strokeWidth: 2, stroke: '#fff' }}
                />
              )}
              <Legend
                verticalAlign="bottom"
                iconType="circle"
                iconSize={10}
                wrapperStyle={{ paddingTop: 16, fontSize: 13 }}
              />
            </RadarChart>
          </ChartContainer>

          {/* Summary bar comparison */}
          <div className="mt-6 grid grid-cols-1 sm:grid-cols-2 gap-4">
            {summaryStats.map(stat => (
              <div key={stat.label} className="border rounded-lg p-4">
                <p className="text-sm font-medium text-gray-600 mb-3">{stat.label}</p>
                <div className="space-y-2">
                  <div>
                    <div className="flex justify-between text-xs mb-1">
                      <span className="text-sky-700 font-medium">{countryData?.countryName}</span>
                      <span className="font-bold">{stat.primary}%</span>
                    </div>
                    <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-sky-500 rounded-full transition-all duration-500"
                        style={{ width: `${stat.primary}%` }}
                      />
                    </div>
                  </div>
                  {hasCompare && (
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-orange-700 font-medium">{compareData?.countryName}</span>
                        <span className="font-bold">{stat.secondary}%</span>
                      </div>
                      <div className="h-2.5 bg-gray-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-orange-500 rounded-full transition-all duration-500"
                          style={{ width: `${stat.secondary}%` }}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* IO Detail Table */}
          {hasCompare && (
            <div className="mt-6 overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-2 px-2 text-xs text-gray-500 font-medium">{t(lang, 'ri.riImmediate')}</th>
                    <th className="text-center py-2 px-2 text-xs text-sky-600 font-medium">{countryData?.countryName}</th>
                    <th className="text-center py-2 px-2 text-xs text-orange-600 font-medium">{compareData?.countryName}</th>
                  </tr>
                </thead>
                <tbody>
                  {countryData?.immediateResults.map((io) => {
                    const cmpIo = compareData?.immediateResults.find(r => r.id === io.id);
                    return (
                      <tr key={io.id} className="border-b border-gray-50">
                        <td className="py-2 px-2 text-gray-700">
                          <span className="font-medium">RI.{io.id}</span> {io.shortTitle}
                        </td>
                        <td className="py-2 px-2 text-center">
                          <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${
                            io.effectiveness === 'Élevé' ? 'bg-emerald-100 text-emerald-700' :
                            io.effectiveness === 'Significatif' ? 'bg-sky-100 text-sky-700' :
                            io.effectiveness === 'Modéré' ? 'bg-amber-100 text-amber-700' :
                            'bg-red-100 text-red-700'
                          }`}>{t(lang, `level.${io.effectiveness}`)}</span>
                        </td>
                        <td className="py-2 px-2 text-center">
                          {cmpIo && (
                            <span className={`inline-block px-2 py-0.5 rounded text-xs font-medium ${
                              cmpIo.effectiveness === 'Élevé' ? 'bg-emerald-100 text-emerald-700' :
                              cmpIo.effectiveness === 'Significatif' ? 'bg-sky-100 text-sky-700' :
                              cmpIo.effectiveness === 'Modéré' ? 'bg-amber-100 text-amber-700' :
                              'bg-red-100 text-red-700'
                            }`}>{t(lang, `level.${cmpIo.effectiveness}`)}</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </CardContent>
      </Card>
      </ZoomableSection>
    </div>
  );
}