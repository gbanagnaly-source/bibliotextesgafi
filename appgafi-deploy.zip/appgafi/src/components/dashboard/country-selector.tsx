'use client';

import { useState, useRef, useEffect, useMemo } from 'react';
import { CountryListItem } from './types';
import { Search, ChevronDown } from 'lucide-react';
import { t } from './settings-panel';

interface CountrySelectorProps {
  countries: CountryListItem[];
  selectedCountry: string;
  onCountryChange: (name: string) => void;
  lang?: 'fr' | 'en';
}

function CountryFlag({ code, size = 20 }: { code?: string; size?: number }) {
  if (!code) return null;
  return (
    <img
      src={`https://flagcdn.com/w40/${code}.png`}
      alt=""
      width={size}
      height={Math.round(size * 0.67)}
      className="rounded-sm object-cover flex-shrink-0"
      loading="lazy"
    />
  );
}

export default function CountrySelector({ countries, selectedCountry, onCountryChange, lang = 'fr' }: CountrySelectorProps) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState('');
  const containerRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const selected = countries.find(c => c.countryName === selectedCountry);

  const filtered = useMemo(() => {
    if (!search.trim()) return countries;
    const q = search.toLowerCase();
    return countries.filter(c =>
      c.countryName.toLowerCase().includes(q) ||
      c.region.toLowerCase().includes(q)
    );
  }, [countries, search]);

  // Group by region
  const grouped = useMemo(() => {
    const groups: Record<string, CountryListItem[]> = {};
    for (const c of filtered) {
      const r = c.region;
      if (!groups[r]) groups[r] = [];
      groups[r].push(c);
    }
    return Object.entries(groups).sort(([a], [b]) => a.localeCompare(b));
  }, [filtered]);

  useEffect(() => {
    if (open && inputRef.current) {
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [open]);

  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <div ref={containerRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="flex items-center gap-2 px-3 py-2 border rounded-lg bg-white hover:bg-gray-50 transition-colors text-sm w-[280px] sm:w-[320px]"
      >
        {selected && <CountryFlag code={selected.countryCode} size={18} />}
        <span className="flex-1 text-left truncate font-medium">
          {selected ? selected.countryName : t(lang, 'cs.selectCountry')}
        </span>
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>

      {open && (
        <div className="absolute top-full left-0 mt-1 w-[320px] sm:w-[400px] bg-white border rounded-xl shadow-xl z-[100] max-h-[70vh] flex flex-col">
          {/* Search input */}
          <div className="p-3 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input
                ref={inputRef}
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder={t(lang, 'cs.searchPlaceholder')}
                className="w-full pl-9 pr-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-sky-500/30 focus:border-sky-500"
              />
            </div>
            <p className="text-xs text-gray-400 mt-1.5">
              {filtered.length} {t(lang, 'cs.countriesShown')}
            </p>
          </div>

          {/* Country list */}
          <div className="overflow-y-auto flex-1">
            {grouped.map(([region, items]) => (
              <div key={region}>
                <div className="sticky top-0 bg-gray-100 px-3 py-1.5 text-[11px] font-semibold text-gray-500 uppercase tracking-wider">
                  {region} ({items.length})
                </div>
                {items.map((c) => (
                  <button
                    key={c.countryName}
                    onClick={() => {
                      onCountryChange(c.countryName);
                      setOpen(false);
                      setSearch('');
                    }}
                    className={`w-full flex items-center gap-2.5 px-3 py-2 text-sm hover:bg-sky-50 transition-colors text-left ${
                      c.countryName === selectedCountry ? 'bg-sky-50 text-sky-700 font-semibold' : 'text-gray-700'
                    }`}
                  >
                    <CountryFlag code={c.countryCode} size={18} />
                    <span className="flex-1 truncate">{c.countryName}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                      c.latestEvaluation.globalRating === 'Satisfaisant' ? 'bg-emerald-100 text-emerald-700' :
                      c.latestEvaluation.globalRating === 'Suffisant' ? 'bg-amber-100 text-amber-700' :
                      c.latestEvaluation.globalRating === 'Non Satisfaisant' ? 'bg-orange-100 text-orange-700' :
                      'bg-red-100 text-red-700 blink-insuffisant'
                    }`}>
                      {c.latestEvaluation.overallCompliance}%
                    </span>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}