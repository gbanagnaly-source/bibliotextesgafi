'use client';

import { useState } from 'react';
import { CountryData, ComplianceLevel } from './types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ExternalLink } from 'lucide-react';
import ZoomableSection from './zoomable-section';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { t, LangCode } from '@/components/dashboard/settings-panel';

interface ComplianceSectionProps {
  data: CountryData;
  onOpenRec?: (recId: number) => void;
  lang?: LangCode;
}

const COMPLIANCE_CODE_MAP: Record<string, string> = {
  'C': 'Conforme',
  'LC': 'Largement Conforme',
  'PC': 'Partiellement Conforme',
  'NC': 'Non Conforme',
  'N/A': 'Non évalué',
};

const complianceColor: Record<string, string> = {
  'Conforme': '#16a34a',
  'Largement Conforme': '#3b82f6',
  'Partiellement Conforme': '#f59e0b',
  'Non Conforme': '#f97316',
  'Non évalué': '#9ca3af',
};

const complianceColorLight: Record<string, string> = {
  'Conforme': '#dcfce7',
  'Largement Conforme': '#dbeafe',
  'Partiellement Conforme': '#fef3c7',
  'Non Conforme': '#ffedd5',
  'Non évalué': '#f3f4f6',
};

const complianceColorDark: Record<string, string> = {
  'Conforme': '#15803d',
  'Largement Conforme': '#1d4ed8',
  'Partiellement Conforme': '#d97706',
  'Non Conforme': '#ea580c',
  'Non évalué': '#6b7280',
};

const complianceOrder: ComplianceLevel[] = ['Conforme', 'Largement Conforme', 'Partiellement Conforme', 'Non Conforme', 'Non évalué'];

function getLevelBadgeVariant(level: string): 'default' | 'secondary' | 'destructive' | 'outline' {
  switch (level) {
    case 'Conforme': case 'Largement Conforme': return 'default';
    case 'Partiellement Conforme': return 'secondary';
    case 'Non Conforme': return 'destructive';
    default: return 'outline';
  }
}

function ComplianceDice({ name, count, color, colorLight, colorDark, onClick }: {
  name: string;
  count: number;
  color: string;
  colorLight: string;
  colorDark: string;
  onClick: () => void;
}) {
  const total = 40;
  const pct = Math.round((count / total) * 100);

  return (
    <div className="relative group" onClick={onClick}>
      {/* 3D die body */}
      <div
        className="relative rounded-2xl p-5 transition-all duration-300 group-hover:scale-[1.04] group-hover:shadow-xl cursor-pointer"
        style={{
          background: `linear-gradient(145deg, ${colorLight} 0%, white 60%, ${colorLight} 100%)`,
          border: `1.5px solid ${color}30`,
          boxShadow: `
            0 4px 6px -1px rgba(0,0,0,0.08),
            0 2px 4px -2px rgba(0,0,0,0.06),
            inset 0 1px 0 rgba(255,255,255,0.9),
            inset 0 -2px 4px rgba(0,0,0,0.04)
          `,
        }}
      >
        {/* Label */}
        <p
          className="text-[10px] sm:text-[11px] font-bold uppercase tracking-widest mt-1 mb-3"
          style={{ color: colorDark }}
        >
          {name}
        </p>

        {/* Big number */}
        <div className="flex items-end gap-1.5">
          <span
            className="text-4xl sm:text-5xl font-extrabold leading-none"
            style={{
              color: colorDark,
              textShadow: `0 1px 2px ${colorLight}`,
            }}
          >
            {count}
          </span>
          <span className="text-xs font-medium mb-1" style={{ color: color }}>
            / {total}
          </span>
        </div>

        {/* Progress bar */}
        <div
          className="mt-3 h-1.5 rounded-full overflow-hidden"
          style={{ backgroundColor: `${color}20` }}
        >
          <div
            className="h-full rounded-full transition-all duration-700 ease-out"
            style={{
              width: `${pct}%`,
              background: `linear-gradient(90deg, ${color}, ${colorDark})`,
            }}
          />
        </div>

        {/* Percentage */}
        <p className="text-[10px] font-semibold mt-1.5 text-right" style={{ color: color }}>
          {pct}%
        </p>

        {/* Decorative corner dots */}
        <div
          className="absolute bottom-3 left-4 w-2 h-2 rounded-full opacity-20"
          style={{ backgroundColor: color }}
        />
        <div
          className="absolute bottom-3 left-4 w-2 h-2 rounded-full opacity-20"
          style={{ backgroundColor: color, marginLeft: '10px' }}
        />
        <div
          className="absolute bottom-3 left-4 w-2 h-2 rounded-full opacity-20"
          style={{ backgroundColor: color, marginLeft: '20px' }}
        />
      </div>
    </div>
  );
}

export default function ComplianceSection({ data, onOpenRec, lang = 'fr' }: ComplianceSectionProps) {
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

  const distribution = complianceOrder.map((level) => ({
    name: level,
    count: data.recommendations.filter((r) => r.compliance === level).length,
    fill: complianceColor[level],
    fillLight: complianceColorLight[level],
    fillDark: complianceColorDark[level],
  })).filter(d => d.count > 0);

  const filteredRecs = selectedLevel
    ? data.recommendations.filter((r) => r.compliance === selectedLevel)
    : [];

  return (
    <section className="space-y-6">
      {/* Aesthetic Dice Overview — clickable */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {distribution.map((d) => (
          <ComplianceDice
            key={d.name}
            name={d.name}
            count={d.count}
            color={d.fill}
            colorLight={d.fillLight}
            colorDark={d.fillDark}
            onClick={() => setSelectedLevel(d.name)}
          />
        ))}
      </div>

      {/* Statistics Dialog */}
      <Dialog open={!!selectedLevel} onOpenChange={(open) => { if (!open) setSelectedLevel(null); }}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <span
                className="w-3 h-3 rounded-full inline-block"
                style={{ backgroundColor: complianceColor[selectedLevel || ''] || '#9ca3af' }}
              />
              {t(lang, 'rec.listOf').replace('{0}', selectedLevel || '')} — {filteredRecs.length} {filteredRecs.length > 1 ? t(lang, 'rec.recommendations_word') : t(lang, 'rec.recommendation_word')}
            </DialogTitle>
            <DialogDescription>
              {t(lang, 'rec.listOf').replace('{0}', selectedLevel || '')} — <span className="text-sky-600">{t(lang, 'rec.clickToSee')}</span>
            </DialogDescription>
          </DialogHeader>

          <div className="overflow-y-auto -mx-1 px-1">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b-2 border-gray-200">
                  <th className="text-left py-2 pr-3 font-semibold text-muted-foreground w-16">{t(lang, 'overview.no')}</th>
                  <th className="text-left py-2 pr-3 font-semibold text-muted-foreground">{t(lang, 'rec.recommendation')}</th>
                  <th className="text-right py-2 font-semibold text-muted-foreground w-28">{t(lang, 'rec.level')}</th>
                </tr>
              </thead>
              <tbody>
                {filteredRecs.map((rec, idx) => (
                  <tr
                    key={rec.id}
                    className={`border-b border-gray-100 hover:bg-muted/50 transition-colors ${onOpenRec ? 'cursor-pointer' : ''}`}
                    onClick={() => onOpenRec?.(rec.id)}
                  >
                    <td className="py-2.5 pr-3">
                      <span className="font-bold text-foreground">R.{rec.id}</span>
                    </td>
                    <td className="py-2.5 pr-3">
                      <span className="text-foreground">{rec.title}</span>
                    </td>
                    <td className="py-2.5 text-right">
                      <span className="text-xs font-medium" style={{ color: complianceColor[rec.compliance] || '#9ca3af' }}>{COMPLIANCE_CODE_MAP[rec.ratingCode] || rec.ratingCode}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Summary footer */}
          <div
            className="mt-auto pt-3 border-t flex items-center justify-between text-xs text-muted-foreground rounded-b-lg px-1"
          >
            <span>{t(lang, 'rec.total').replace('{0}', String(filteredRecs.length))}</span>
            <span>{t(lang, 'rec.percentTotal').replace('{0}', String(Math.round((filteredRecs.length / 40) * 100)))}</span>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detailed recommendations */}
      <ZoomableSection title={t(lang, 'rec.40detail')}>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="min-w-0">
            <CardTitle className="text-lg">{t(lang, 'rec.40detail')}</CardTitle>
            {onOpenRec && <p className="text-xs text-sky-600 mt-0.5">{t(lang, 'rec.clickDetail')}</p>}
          </div>
          <a
            href="https://www.fatf-gafi.org/fr/publications/Evaluationsmutuelles/Fatf-methodology.html"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs bg-sky-50 hover:bg-sky-100 text-sky-700 rounded-lg transition-colors border border-sky-200"
          >
            {t(lang, 'rec.sourceGafi')} <ExternalLink className="w-3 h-3" />
          </a>
        </CardHeader>
        <CardContent>
          <div className="max-h-[500px] overflow-y-auto pr-2 space-y-2">
            {data.recommendations.map((rec) => (
              <div
                key={rec.id}
                className={`flex items-start gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors ${onOpenRec ? 'cursor-pointer' : ''}`}
                onClick={() => onOpenRec?.(rec.id)}
              >
                <div
                  className="w-1 self-stretch rounded-full flex-shrink-0 mt-0.5"
                  style={{ backgroundColor: complianceColor[rec.compliance] || '#9ca3af' }}
                />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-semibold text-foreground">R.{rec.id}</span>
                    <span className="text-sm text-foreground">{rec.title}</span>
                    <Badge variant={getLevelBadgeVariant(rec.compliance)} className="ml-auto text-xs">
                      {rec.compliance}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground mt-1">{rec.description}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
      </ZoomableSection>
    </section>
  );
}