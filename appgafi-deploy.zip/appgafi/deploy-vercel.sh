#!/bin/bash
# === Script de déploiement AppGAFI via Vercel CLI ===
echo "============================================"
echo "  Déploiement AppGAFI sur Vercel"
echo "============================================"
echo ""

# Check if vercel CLI is installed
if ! command -v vercel &> /dev/null; then
    echo "Installation de Vercel CLI..."
    npm i -g vercel
fi

# Login if needed
echo ""
echo "Si vous n'êtes pas connecté, exécutez: vercel login"
echo ""

# Install dependencies
echo "[1/3] Installation des dépendances..."
npm install

# Build
echo "[2/3] Construction de l'application..."
npm run build

# Deploy
echo "[3/3] Déploiement sur Vercel..."
vercel --prod --yes

echo ""
echo "============================================"
echo "  Déploiement terminé avec succès !"
echo "============================================"
