# AppGAFI - Guide de Déploiement

## Méthode 1 : Déploiement automatique via Vercel (recommandé)

```bash
# 1. Extraire le zip
unzip appgafi-deploy.zip

# 2. Entrer dans le dossier
cd appgafi

# 3. Lancer le script de déploiement
bash deploy-vercel.sh
```

## Méthode 2 : Déploiement manuel via Vercel CLI

```bash
cd appgafi
npm install
npm run build
vercel --prod --yes
```

## Méthode 3 : Serveur dédié (Node.js / Bun)

```bash
cd appgafi
npm install
npm run build
# Démarrer le serveur
node .next/standalone/server.js
# ou avec bun:
bun .next/standalone/server.js
```

Le serveur démarre par défaut sur le port 3000.

## Notes
- Le fichier `.env` est inclus dans le zip.
- Les données GAFI sont dans `public/data/gafi-data.json` et `src/data/`.
- Le favicon et les icônes sont déjà configurés.
