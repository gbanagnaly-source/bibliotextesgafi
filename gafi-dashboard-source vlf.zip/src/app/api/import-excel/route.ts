import { NextRequest, NextResponse } from 'next/server';
import * as XLSX from 'xlsx';
import fs from 'fs';
import path from 'path';

const EXPECTED_PASSWORD = 'Cleobule1980@';

// Mapping of compliance codes
function parseCompliance(value: string): { compliance: string; ratingCode: string } {
  const v = (value || '').toString().trim().toLowerCase();
  const map: Record<string, { compliance: string; ratingCode: string }> = {
    'c': { compliance: 'Conforme', ratingCode: 'C' },
    'conforme': { compliance: 'Conforme', ratingCode: 'C' },
    'lc': { compliance: 'Largement Conforme', ratingCode: 'LC' },
    'largement conforme': { compliance: 'Largement Conforme', ratingCode: 'LC' },
    'pc': { compliance: 'Partiellement Conforme', ratingCode: 'PC' },
    'partiellement conforme': { compliance: 'Partiellement Conforme', ratingCode: 'PC' },
    'nc': { compliance: 'Non Conforme', ratingCode: 'NC' },
    'non conforme': { compliance: 'Non Conforme', ratingCode: 'NC' },
    'n/a': { compliance: 'Non évalué', ratingCode: 'N/A' },
    'na': { compliance: 'Non évalué', ratingCode: 'N/A' },
    'non évalué': { compliance: 'Non évalué', ratingCode: 'N/A' },
  };
  return map[v] || { compliance: 'Non évalué', ratingCode: 'N/A' };
}

// Mapping of effectiveness codes
function parseEffectiveness(value: string): { effectiveness: string; effectivenessCode: string } {
  const v = (value || '').toString().trim().toLowerCase();
  const map: Record<string, { effectiveness: string; effectivenessCode: string }> = {
    'élevé': { effectiveness: 'Élevé', effectivenessCode: 'Élevé' },
    'eleve': { effectiveness: 'Élevé', effectivenessCode: 'Élevé' },
    'he': { effectiveness: 'Élevé', effectivenessCode: 'Élevé' },
    'high': { effectiveness: 'Élevé', effectivenessCode: 'Élevé' },
    'significatif': { effectiveness: 'Significatif', effectivenessCode: 'Significatif' },
    'se': { effectiveness: 'Significatif', effectivenessCode: 'Significatif' },
    'significant': { effectiveness: 'Significatif', effectivenessCode: 'Significatif' },
    'modéré': { effectiveness: 'Modéré', effectivenessCode: 'Modéré' },
    'modere': { effectiveness: 'Modéré', effectivenessCode: 'Modéré' },
    'me': { effectiveness: 'Modéré', effectivenessCode: 'Modéré' },
    'moderate': { effectiveness: 'Modéré', effectivenessCode: 'Modéré' },
    'faible': { effectiveness: 'Faible', effectivenessCode: 'Faible' },
    'le': { effectiveness: 'Faible', effectivenessCode: 'Faible' },
    'low': { effectiveness: 'Faible', effectivenessCode: 'Faible' },
  };
  return map[v] || { effectiveness: 'Non évalué', effectivenessCode: 'Non évalué' };
}

// Official recommendation titles (R.1-R.40) — GAFI 2023 consolidées
const REC_TITLES: Record<number, string> = {
  1: "Évaluation des risques et application d'une approche fondée sur les risques",
  2: "Coopération et coordination nationales",
  3: "Infraction de blanchiment de capitaux",
  4: "Confiscation et mesures provisoires",
  5: "Infraction de financement du terrorisme",
  6: "Sanctions financières ciblées liées au terrorisme et au financement du terrorisme",
  7: "Sanctions financières ciblées liées à la prolifération",
  8: "Organismes à but non lucratif",
  9: "Lois sur le secret professionnel des institutions financières",
  10: "Devoir de vigilance relatif à la clientèle",
  11: "Conservation des documents",
  12: "Personnes politiquement exposées",
  13: "Correspondance bancaire",
  14: "Services de transfert de fonds ou de valeurs",
  15: "Nouvelles technologies",
  16: "Virements électroniques",
  17: "Recours à des tiers",
  18: "Contrôles internes et succursales et filiales à l'étranger",
  19: "Pays présentant un risque plus élevé",
  20: "Déclaration des opérations suspectes",
  21: "Divulgation et confidentialité",
  22: "Entreprises et professions non financières désignées – Devoir de vigilance relatif à la clientèle",
  23: "Entreprises et professions non financières désignées – Autres mesures",
  24: "Transparence et bénéficiaires effectifs des personnes morales",
  25: "Transparence et bénéficiaires effectifs des constructions juridiques",
  26: "Réglementation et contrôle des institutions financières",
  27: "Pouvoirs des autorités de contrôle",
  28: "Réglementation et contrôle des entreprises et professions non financières désignées",
  29: "Cellules de renseignements financiers",
  30: "Responsabilités des autorités de poursuite pénale et des autorités chargées des enquêtes",
  31: "Pouvoirs des autorités de poursuite pénale et des autorités chargées des enquêtes",
  32: "Passeurs de fonds",
  33: "Statistiques",
  34: "Lignes directrices et retour d'informations",
  35: "Sanctions",
  36: "Instruments internationaux",
  37: "Entraide judiciaire",
  38: "Entraide judiciaire : gel et confiscation",
  39: "Extradition",
  40: "Autres formes de coopération",
};

// Official RI titles
const RI_TITLES: Record<number, { title: string; shortTitle: string }> = {
  1: { title: "Compréhension des risques de BC/FT/FP et application d'une AFR", shortTitle: "Risques, politique et coordination" },
  2: { title: "Coopération internationale", shortTitle: "Coopération internationale" },
  3: { title: "Supervision et surveillance", shortTitle: "Supervision" },
  4: { title: "Prévention du BC/FT par les institutions financières", shortTitle: "Mesures préventives" },
  5: { title: "Prévention du BC/FT par les professions non financières", shortTitle: "Transparence PM" },
  6: { title: "Déclarations d'opérations suspectes utilisées efficacement", shortTitle: "Transparence CJ" },
  7: { title: "Enquêtes et poursuites en matière de BC", shortTitle: "Blanchiment de capitaux" },
  8: { title: "Enquêtes et poursuites en matière de FT", shortTitle: "Confiscation" },
  9: { title: "Mesures de gel et de confiscation", shortTitle: "FT et prolifération" },
  10: { title: "Sanctions financières ciblées en matière de prolifération", shortTitle: "Entraide judiciaire" },
  11: { title: "Entraide administrative", shortTitle: "Entraide administrative" },
};

export async function POST(request: NextRequest) {
  try {
    const formData = await request.formData();
    const password = formData.get('password') as string;
    const file = formData.get('file') as File;

    if (password !== EXPECTED_PASSWORD) {
      return NextResponse.json({ error: 'Mot de passe incorrect.' }, { status: 403 });
    }

    if (!file) {
      return NextResponse.json({ error: 'Aucun fichier fourni.' }, { status: 400 });
    }

    // Read and parse Excel
    const buffer = Buffer.from(await file.arrayBuffer());
    const workbook = XLSX.read(buffer, { type: 'buffer' });

    // Expected sheet name: "Données" or first sheet
    const sheetName = workbook.SheetNames.includes('Données')
      ? 'Données'
      : workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: '' });

    if (rows.length === 0) {
      return NextResponse.json({ error: 'Le fichier Excel est vide.' }, { status: 400 });
    }

    // Load existing data
    const dataPath = path.join(process.cwd(), 'src', 'data', 'gafi-data.json');
    const existingData = JSON.parse(fs.readFileSync(dataPath, 'utf-8'));
    const countriesMap = new Map(existingData.countries.map((c: any) => [c.countryName, c]));

    let updatedCount = 0;

    for (const row of rows) {
      const countryName = String(row['Pays'] || row['pays'] || row['Country'] || '').trim();
      if (!countryName) continue;

      const existing = countriesMap.get(countryName);
      if (!existing) continue;

      // Update recommendations (columns R.1 to R.40)
      for (let i = 1; i <= 40; i++) {
        const colKey = `R.${i}`;
        const cellValue = String(row[colKey] || '');
        if (cellValue) {
          const parsed = parseCompliance(cellValue);
          const recIndex = existing.recommendations.findIndex((r: any) => r.id === i);
          if (recIndex >= 0) {
            existing.recommendations[recIndex].compliance = parsed.compliance;
            existing.recommendations[recIndex].ratingCode = parsed.ratingCode;
          }
        }
      }

      // Update immediate results (columns RI.1 to RI.11)
      for (let i = 1; i <= 11; i++) {
        const colKey = `RI.${i}`;
        const cellValue = String(row[colKey] || '');
        if (cellValue) {
          const parsed = parseEffectiveness(cellValue);
          const riIndex = existing.immediateResults.findIndex((r: any) => r.id === i);
          if (riIndex >= 0) {
            existing.immediateResults[riIndex].effectiveness = parsed.effectiveness;
            existing.immediateResults[riIndex].effectivenessCode = parsed.effectivenessCode;
          }
        }
      }

      // Recalculate compliance score
      const COMPLIANCE_SCORE: Record<string, number> = { 'C': 100, 'LC': 75, 'PC': 50, 'NC': 0, 'N/A': 0 };
      const totalCompliance = existing.recommendations.reduce((sum: number, r: any) => {
        return sum + (COMPLIANCE_SCORE[r.ratingCode] || 0);
      }, 0);
      const overallCompliance = Math.round(totalCompliance / 40);

      // Recalculate effectiveness score
      const EFF_SCORE: Record<string, number> = { 'Élevé': 4, 'Significatif': 3, 'Modéré': 2, 'Faible': 1, 'Non évalué': 0 };
      const totalEff = existing.immediateResults.reduce((sum: number, r: any) => {
        return sum + (EFF_SCORE[r.effectivenessCode] || 0);
      }, 0);
      const effectivenessPct = Math.round((totalEff / 44) * 100); // 11 RIs * max 4

      existing.latestEvaluation.overallCompliance = overallCompliance;
      existing.latestEvaluation.overallEffectiveness = effectivenessPct;
      existing.overallCompliance = overallCompliance;

      // Update global rating
      let globalRating = 'Insuffisant';
      if (overallCompliance >= 70) globalRating = 'Satisfaisant';
      else if (overallCompliance >= 50) globalRating = 'Suffisant';
      else if (overallCompliance >= 35) globalRating = 'Non Satisfaisant';
      existing.latestEvaluation.globalRating = globalRating;

      // Update summary
      if (existing.summary) {
        existing.summary.technicalComplianceScore = overallCompliance;
      }

      updatedCount++;
    }

    // Save updated data
    existingData.countries = existingData.countries.map((c: any) => countriesMap.get(c.countryName) || c);
    fs.writeFileSync(dataPath, JSON.stringify(existingData, null, 2), 'utf-8');

    // Also copy to public/data
    const publicPath = path.join(process.cwd(), 'public', 'data', 'gafi-data.json');
    if (fs.existsSync(path.dirname(publicPath))) {
      fs.writeFileSync(publicPath, JSON.stringify(existingData, null, 2), 'utf-8');
    }

    return NextResponse.json({
      success: true,
      updatedCountries: updatedCount,
      totalRows: rows.length,
    });
  } catch (error) {
    console.error('Excel import error:', error);
    return NextResponse.json(
      { error: 'Erreur lors du traitement du fichier Excel.' },
      { status: 500 }
    );
  }
}