import { NextRequest, NextResponse } from 'next/server';
import { readFile } from 'fs/promises';
import { join } from 'path';

const PUBLIC_DIR = '/home/z/my-project/public';

const ALLOWED = [
  'gafi-part-aa', 'gafi-part-ab', 'gafi-part-ac',
  'gafi-part-ad', 'gafi-part-ae', 'gafi-part-af',
  'gafi-dashboard-code-source.txt',
];

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const file = searchParams.get('file');

  if (!file || !ALLOWED.includes(file)) {
    return NextResponse.json({ error: 'Fichier non trouvé' }, { status: 404 });
  }

  try {
    const data = await readFile(join(PUBLIC_DIR, file));
    return new NextResponse(data, {
      headers: {
        'Content-Type': 'application/octet-stream',
        'Content-Disposition': `attachment; filename="${file}"`,
        'Content-Length': String(data.length),
        'Cache-Control': 'public, max-age=3600',
      },
    });
  } catch {
    return NextResponse.json({ error: 'Fichier non trouvé' }, { status: 404 });
  }
}