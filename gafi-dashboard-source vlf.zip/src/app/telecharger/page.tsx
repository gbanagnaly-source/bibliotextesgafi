'use client';

import { useState } from 'react';
import { Download, Loader2, CheckCircle, AlertCircle } from 'lucide-react';

const PARTS = ['gafi-part-aa', 'gafi-part-ab', 'gafi-part-ac', 'gafi-part-ad', 'gafi-part-ae', 'gafi-part-af'];

export default function TelechargerPage() {
  const [status, setStatus] = useState<'idle' | 'loading' | 'done' | 'error'>('idle');
  const [progress, setProgress] = useState(0);

  async function handleDownload() {
    setStatus('loading');
    setProgress(0);

    try {
      const blobs: Blob[] = [];

      for (let i = 0; i < PARTS.length; i++) {
        const res = await fetch(`/api/download?file=${PARTS[i]}`);
        if (!res.ok) throw new Error(`Erreur partie ${i + 1}`);
        const blob = await res.blob();
        blobs.push(blob);
        setProgress(Math.round(((i + 1) / PARTS.length) * 100));
      }

      const finalBlob = new Blob(blobs, { type: 'application/zip' });
      const url = URL.createObjectURL(finalBlob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'gafi-dashboard-source.zip';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);

      setStatus('done');
    } catch {
      setStatus('error');
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-lg max-w-md w-full p-8 text-center">
        <div className="mb-6">
          <div className="w-16 h-16 bg-sky-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Download className="w-8 h-8 text-sky-600" />
          </div>
          <h1 className="text-xl font-bold text-gray-900">GAFI Dashboard</h1>
          <p className="text-sm text-gray-500 mt-1">Code source complet + données</p>
          <p className="text-xs text-gray-400 mt-0.5">2.2 Mo — 6 parties</p>
        </div>

        {status === 'loading' && (
          <div className="mb-6">
            <div className="w-full bg-gray-200 rounded-full h-2.5">
              <div
                className="bg-sky-500 h-2.5 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
            <p className="text-xs text-gray-500 mt-2">{progress}% — Assemblage en cours...</p>
          </div>
        )}

        {status === 'done' && (
          <div className="mb-6 flex items-center justify-center gap-2 text-emerald-600">
            <CheckCircle className="w-5 h-5" />
            <span className="text-sm font-medium">Téléchargement terminé !</span>
          </div>
        )}

        {status === 'error' && (
          <div className="mb-6 flex items-center justify-center gap-2 text-red-600">
            <AlertCircle className="w-5 h-5" />
            <span className="text-sm font-medium">Erreur. Réessayez.</span>
          </div>
        )}

        <button
          onClick={handleDownload}
          disabled={status === 'loading'}
          className="w-full py-3 px-4 bg-sky-600 hover:bg-sky-700 disabled:bg-gray-300 text-white font-medium rounded-xl transition-colors flex items-center justify-center gap-2"
        >
          {status === 'loading' ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Téléchargement...
            </>
          ) : status === 'done' ? (
            <>
              <CheckCircle className="w-5 h-5" />
              Télécharger à nouveau
            </>
          ) : (
            <>
              <Download className="w-5 h-5" />
              Télécharger le ZIP
            </>
          )}
        </button>

        <div className="mt-6 text-left bg-gray-50 rounded-xl p-4">
          <p className="text-xs font-semibold text-gray-700 mb-2">Pour déployer :</p>
          <code className="text-[11px] text-gray-600 leading-relaxed block whitespace-pre-wrap">
unzip gafi-dashboard-source.zip
npm install
npm run build
node .next/standalone/server.js
          </code>
        </div>
      </div>
    </div>
  );
}