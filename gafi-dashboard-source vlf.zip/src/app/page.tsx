'use client';

import { useState, useEffect, useMemo, useCallback } from 'react';
import HeroHeader from '@/components/dashboard/hero-header';
import CountrySelector from '@/components/dashboard/country-selector';
import ComplianceSection from '@/components/dashboard/compliance-section';
import EffectivenessSection from '@/components/dashboard/effectiveness-section';
import SummarySection from '@/components/dashboard/summary-section';
import ComparisonSection from '@/components/dashboard/comparison-section';
import RISummarySheet from '@/components/dashboard/ri-summary-sheet';
import { CountryData, CountryListItem } from '@/components/dashboard/types';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Shield, BookOpen, BarChart3, FileText, Globe2, Search, ArrowUpDown, Phone } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';
import SettingsPanel, { t as tFn, getCurrentLang, setCurrentLang } from '@/components/dashboard/settings-panel';
import { InfoModal, useGafiKnowledge } from '@/components/dashboard/gafi-knowledge-modal';
import AnimatedLogo from '@/components/dashboard/animated-logo';
import ZoomableSection from '@/components/dashboard/zoomable-section';

type LangCode = 'fr' | 'en';

const RATING_MAP: Record<string, string> = {
  'Satisfaisant': 'rating.Satisfaisant',
  'Suffisant': 'rating.Suffisant',
  'Non Satisfaisant': 'rating.Non Satisfaisant',
  'Insuffisant': 'rating.Insuffisant',
};

function getRatingColor(rating: string): string {
  switch (rating) {
    case 'Satisfaisant': return 'bg-emerald-500 text-white';
    case 'Suffisant': return 'bg-amber-500 text-white';
    case 'Non Satisfaisant': return 'bg-orange-500 text-white';
    case 'Insuffisant': return 'bg-red-600 text-white';
    default: return 'bg-gray-400 text-white';
  }
}

type SortKey = 'countryName' | 'overallCompliance' | 'overallEffectiveness' | 'date';
type SortDir = 'asc' | 'desc';

function CountryOverviewTable({ countries, lang }: { countries: CountryListItem[]; lang: LangCode }) {
  const [search, setSearch] = useState('');
  const [sortKey, setSortKey] = useState<SortKey>('countryName');
  const [sortDir, setSortDir] = useState<SortDir>('asc');
  const [regionFilter, setRegionFilter] = useState('all');

  const regions = useMemo(() => {
    const r = new Set(countries.map(c => c.region));
    return Array.from(r).sort();
  }, [countries]);

  const filtered = useMemo(() => {
    let result = countries;
    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(c => c.countryName.toLowerCase().includes(q));
    }
    if (regionFilter !== 'all') {
      result = result.filter(c => c.region === regionFilter);
    }
    result = [...result].sort((a, b) => {
      let cmp = 0;
      switch (sortKey) {
        case 'countryName': cmp = a.countryName.localeCompare(b.countryName); break;
        case 'overallCompliance': cmp = a.latestEvaluation.overallCompliance - b.latestEvaluation.overallCompliance; break;
        case 'overallEffectiveness': cmp = a.latestEvaluation.overallEffectiveness - b.latestEvaluation.overallEffectiveness; break;
        case 'date': cmp = (b.latestEvaluation.date || '').localeCompare(a.latestEvaluation.date || ''); break;
      }
      return sortDir === 'asc' ? cmp : -cmp;
    });
    return result;
  }, [countries, search, regionFilter, sortKey, sortDir]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  return (
    <ZoomableSection title={tFn(lang, 'overview.title')} className="contents">
    <Card>
      <CardHeader>
        <CardTitle className="text-lg flex items-center gap-2">
          <Globe2 className="w-5 h-5" />
          {tFn(lang, 'overview.title').replace(' — ', ' — ')} {filtered.length} {tFn(lang, 'countries')}
        </CardTitle>
      </CardHeader>
      <CardContent>
        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-3 mb-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder={tFn(lang, 'search.placeholder')}
              className="pl-9"
            />
          </div>
          <div className="flex gap-2 flex-wrap">
            <button
              onClick={() => setRegionFilter('all')}
              className={`px-3 py-1.5 text-xs rounded-lg border font-medium transition-colors ${regionFilter === 'all' ? 'bg-sky-100 border-sky-300 text-sky-700' : 'bg-white hover:bg-gray-50'}`}
            >
              {tFn(lang, 'all')} ({countries.length})
            </button>
            {regions.slice(0, 6).map(r => (
              <button
                key={r}
                onClick={() => setRegionFilter(r)}
                className={`px-3 py-1.5 text-xs rounded-lg border font-medium transition-colors ${regionFilter === r ? 'bg-sky-100 border-sky-300 text-sky-700' : 'bg-white hover:bg-gray-50'}`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        <div className="overflow-x-auto max-h-[600px] overflow-y-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[200px] cursor-pointer" onClick={() => toggleSort('countryName')}>
                  <span className="flex items-center gap-1">{tFn(lang, 'country')} <ArrowUpDown className="w-3 h-3" /></span>
                </TableHead>
                <TableHead className="hidden md:table-cell">{tFn(lang, 'region')}</TableHead>
                <TableHead className="text-center cursor-pointer" onClick={() => toggleSort('date')}>
                  <span className="flex items-center justify-center gap-1">{tFn(lang, 'date')} <ArrowUpDown className="w-3 h-3" /></span>
                </TableHead>
                <TableHead className="text-center">{tFn(lang, 'rating')}</TableHead>
                <TableHead className="text-center cursor-pointer" onClick={() => toggleSort('overallCompliance')}>
                  <span className="flex items-center justify-center gap-1">{tFn(lang, 'compliance')} <ArrowUpDown className="w-3 h-3" /></span>
                </TableHead>
                <TableHead className="text-center cursor-pointer" onClick={() => toggleSort('overallEffectiveness')}>
                  <span className="flex items-center justify-center gap-1">{tFn(lang, 'effectiveness')} <ArrowUpDown className="w-3 h-3" /></span>
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.map((c) => {
                return (
                  <TableRow key={c.countryName}>
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        {c.countryCode && (
                          <img src={`https://flagcdn.com/w20/${c.countryCode}.png`} alt="" width={20} height={14} className="rounded-sm flex-shrink-0" loading="lazy" />
                        )}
                        <span className="truncate">{c.countryName}</span>
                      </div>
                    </TableCell>
                    <TableCell className="hidden md:table-cell text-xs text-muted-foreground">{c.region}</TableCell>
                    <TableCell className="text-center text-sm">{c.latestEvaluation.date}</TableCell>
                    <TableCell className="text-center">
                      <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${getRatingColor(c.latestEvaluation.globalRating)} ${c.latestEvaluation.globalRating === 'Insuffisant' ? 'blink-insuffisant' : ''}`}>
                        {tFn(lang, RATING_MAP[c.latestEvaluation.globalRating] || '')}
                      </span>
                    </TableCell>
                    <TableCell className="text-center font-semibold text-sm">{c.latestEvaluation.overallCompliance}%</TableCell>
                    <TableCell className="text-center font-semibold text-sm">{c.latestEvaluation.overallEffectiveness}%</TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
    </ZoomableSection>
  );
}

export default function Home() {
  const [countryList, setCountryList] = useState<CountryListItem[]>([]);
  const [selectedCountry, setSelectedCountry] = useState("Côte d'Ivoire");
  const [countryData, setCountryData] = useState<CountryData | null>(null);
  const [loading, setLoading] = useState(true);
  const [detailLoading, setDetailLoading] = useState(false);
  const { modalOpen, contentType, initialId, handleOpen, handleClose } = useGafiKnowledge();
  const [heroRiSheetOpen, setHeroRiSheetOpen] = useState(false);
  const [lang, setLang] = useState<LangCode>(() => getCurrentLang());

  const handleLanguageChange = useCallback((newLang: LangCode) => {
    setLang(newLang);
    setCurrentLang(newLang);
  }, []);

  const reloadData = useCallback(() => {
    fetch(`/api/evaluations?country=${encodeURIComponent(selectedCountry)}`)
      .then(res => { if (!res.ok) return null; return res.json(); })
      .then((data: CountryData | null) => { if (data) setCountryData(data); })
      .catch(() => {});
  }, [selectedCountry]);

  // Load country list on mount
  useEffect(() => {
    fetch('/api/evaluations')
      .then(res => res.json())
      .then((data: CountryListItem[]) => {
        setCountryList(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  // Load detailed data when country changes
  const handleCountryChange = useCallback((name: string) => {
    setSelectedCountry(name);
    setDetailLoading(true);
    fetch(`/api/evaluations?country=${encodeURIComponent(name)}`)
      .then(res => {
        if (!res.ok) { setCountryData(null); setDetailLoading(false); return null; }
        return res.json();
      })
      .then((data: CountryData | null) => {
        if (data) setCountryData(data);
        setDetailLoading(false);
      })
      .catch(() => setDetailLoading(false));
  }, []);

  // Load initial country detail
  const initialCountry = "Côte d'Ivoire";
  useEffect(() => {
    fetch(`/api/evaluations?country=${encodeURIComponent(initialCountry)}`)
      .then(res => {
        if (!res.ok) { setCountryData(null); setDetailLoading(false); return null; }
        return res.json();
      })
      .then((data: CountryData | null) => {
        if (data) setCountryData(data);
        setDetailLoading(false);
      })
      .catch(() => setDetailLoading(false));
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50">
      {/* Top Navigation Bar */}
      <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <AnimatedLogo size={42} showLabel />
              <div>
                <h1 className="text-base font-bold text-gray-900 leading-tight">{tFn(lang, 'nav.title')}</h1>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!loading && countryList.length > 0 && (
                <div className="hidden sm:block">
                  <CountrySelector countries={countryList} selectedCountry={selectedCountry} onCountryChange={handleCountryChange} lang={lang} />
                </div>
              )}
              <SettingsPanel currentLang={lang} onLanguageChange={handleLanguageChange} onDataUpdate={reloadData} />
            </div>
          </div>
          {/* Mobile selector */}
          {!loading && countryList.length > 0 && (
            <div className="sm:hidden pb-3">
              <CountrySelector countries={countryList} selectedCountry={selectedCountry} onCountryChange={handleCountryChange} lang={lang} />
            </div>
          )}
        </div>
      </nav>

      <main className="flex-1">
        {loading ? (
          <div className="max-w-7xl mx-auto px-4 py-8 space-y-6">
            <Skeleton className="h-[300px] w-full rounded-xl" />
            <div className="grid grid-cols-2 gap-4">
              <Skeleton className="h-[200px] rounded-xl" />
              <Skeleton className="h-[200px] rounded-xl" />
            </div>
            <Skeleton className="h-[400px] rounded-xl" />
          </div>
        ) : (
          <>
            {/* Hero Header */}
            <HeroHeader data={countryData} loading={detailLoading || !countryData} onOpenKnowledge={handleOpen} onOpenRISheet={() => setHeroRiSheetOpen(true)} lang={lang} />

            {/* Content */}
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
              <Tabs defaultValue="summary" className="w-full">
                <TabsList className="grid w-full grid-cols-2 sm:grid-cols-5 mb-6">
                  <TabsTrigger value="summary" className="text-xs sm:text-sm gap-1.5">
                    <FileText className="w-4 h-4 hidden sm:inline" />{tFn(lang, 'tab.synthese')}
                  </TabsTrigger>
                  <TabsTrigger value="compliance" className="text-xs sm:text-sm gap-1.5">
                    <BookOpen className="w-4 h-4 hidden sm:inline" />{tFn(lang, 'tab.conformite')}
                  </TabsTrigger>
                  <TabsTrigger value="effectiveness" className="text-xs sm:text-sm gap-1.5">
                    <BarChart3 className="w-4 h-4 hidden sm:inline" />{tFn(lang, 'tab.efficacite')}
                  </TabsTrigger>
                  <TabsTrigger value="comparison" className="text-xs sm:text-sm gap-1.5 hidden sm:flex">
                    <BarChart3 className="w-4 h-4" />{tFn(lang, 'tab.comparaison')}
                  </TabsTrigger>
                  <TabsTrigger value="overview" className="text-xs sm:text-sm gap-1.5">
                    <Globe2 className="w-4 h-4 hidden sm:inline" />{tFn(lang, 'tab.allCountries')}
                  </TabsTrigger>
                </TabsList>

                <TabsContent value="summary">
                  {detailLoading || !countryData ? <Skeleton className="h-[300px] rounded-xl" /> : <SummarySection data={countryData} onOpenRec={(id) => handleOpen('rec', id)} lang={lang} />}
                </TabsContent>
                <TabsContent value="compliance">
                  {detailLoading || !countryData ? <Skeleton className="h-[500px] rounded-xl" /> : <ComplianceSection data={countryData} onOpenRec={(id) => handleOpen('rec', id)} lang={lang} />}
                </TabsContent>
                <TabsContent value="effectiveness">
                  {detailLoading || !countryData ? <Skeleton className="h-[500px] rounded-xl" /> : <EffectivenessSection data={countryData} onOpenRec={(id) => handleOpen('rec', id)} lang={lang} />}
                </TabsContent>
                <TabsContent value="comparison">
                  {detailLoading || !countryData ? <Skeleton className="h-[300px] rounded-xl" /> : <ComparisonSection countries={countryList} selectedCountry={selectedCountry} countryData={countryData} lang={lang} />}
                </TabsContent>
                <TabsContent value="overview">
                  <CountryOverviewTable countries={countryList} lang={lang} />
                </TabsContent>
              </Tabs>
            </div>
          </>
        )}
      </main>

      {/* Knowledge Modal */}
      <InfoModal open={modalOpen} onClose={handleClose} content={contentType} initialId={initialId} lang={lang} />

      {/* RI Summary Sheet from hero EXPLORER button */}
      {countryData && (
        <RISummarySheet
          open={heroRiSheetOpen}
          onOpenChange={setHeroRiSheetOpen}
          immediateResults={countryData.immediateResults}
          onOpenRec={(id) => handleOpen('rec', id)}
          lang={lang}
        />
      )}

      <footer className="bg-white border-t border-gray-200 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex flex-col items-start">
              <div className="flex items-center gap-2 text-sm text-gray-500">
                <AnimatedLogo size={28} />
                <span>{tFn(lang, 'footer.library')}</span>
              </div>
              <div className="flex items-center gap-2 mt-1.5 ml-7 text-xs text-gray-400">
                <Phone size={12} className="shrink-0 text-gray-400" />
                <span>{tFn(lang, 'footer.contact')}</span>
              </div>
              <div className="flex items-center gap-2 mt-0.5 ml-7 text-xs text-gray-400">
                <Globe2 size={12} className="shrink-0 text-gray-400" />
                <a href="https://www.cclbcft.ci" target="_blank" rel="noopener noreferrer" className="hover:text-blue-500 hover:underline transition-colors">
                  www.cclbcft.ci
                </a>
              </div>
              <p className="text-xs text-gray-400 mt-1 ml-7">{tFn(lang, 'footer.service')}</p>
            </div>
            <div className="text-xs text-gray-400 text-center sm:text-right">
              <p>{tFn(lang, 'footer.source')}</p>
              <p className="mt-1">{tFn(lang, 'footer.disclaimer')}</p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}