'use client';

import { useState } from 'react';
import { CountryData } from './types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { TrendingUp, TrendingDown, CheckCircle2, AlertTriangle, ShieldAlert } from 'lucide-react';
import RISummarySheet from './ri-summary-sheet';
import { t, LangCode } from '@/components/dashboard/settings-panel';

interface SummarySectionProps {
  data: CountryData;
  onOpenRec?: (recId: number) => void;
  lang?: LangCode;
}

/* ── Code → French label mappings ── */
const COMPLIANCE_CODE_MAP: Record<string, string> = {
  'C': 'Conforme',
  'LC': 'Largement Conforme',
  'PC': 'Partiellement Conforme',
  'NC': 'Non Conforme',
  'N/A': 'Non évalué',
};

const EFFECTIVENESS_CODE_MAP: Record<string, string> = {
  'Élevé': 'Élevé',
  'Significatif': 'Significatif',
  'Modéré': 'Modéré',
  'Faible': 'Faible',
  'N/A': 'Non évalué',
};

const COMPLIANCE_LEVELS = [
  { key: 'Conforme', color: '#2ECC71', bg: '#f0fdf4', dark: '#27AE60', icon: 'check' },
  { key: 'Largement Conforme', color: '#7ED321', bg: '#f7fef9', dark: '#65a30d', icon: 'minus' },
  { key: 'Partiellement Conforme', color: '#F5A623', bg: '#fffbeb', dark: '#D4911E', icon: 'warning' },
  { key: 'Non Conforme', color: '#D0021B', bg: '#fef2f2', dark: '#B91C1C', icon: 'x' },
] as const;

function StatusIcon({ type }: { type: string }) {
  const cls = "w-5 h-5";
  switch (type) {
    case 'check':
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><polyline points="20 6 9 17 4 12" /></svg>;
    case 'minus':
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={3} strokeLinecap="round"><line x1="6" y1="12" x2="18" y2="12" /></svg>;
    case 'warning':
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" /><line x1="12" y1="9" x2="12" y2="13" /><line x1="12" y1="17" x2="12.01" y2="17" /></svg>;
    case 'x':
      return <svg className={cls} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" /></svg>;
    default: return null;
  }
}

/** SVG circular progress ring */
function ProgressRing({ score, size = 80, strokeWidth = 7, color }: {
  score: number; size?: number; strokeWidth?: number; color: string;
}) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;

  return (
    <div className="relative flex-shrink-0" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#E5E7EB" strokeWidth={strokeWidth} />
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={offset} className="transition-all duration-1000 ease-out" />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">
        <span className="text-xl sm:text-2xl font-bold" style={{ color }}>{score}%</span>
      </div>
    </div>
  );
}

/** Vertical indicator card — now clickable */
function VerticalStatCard({ label, count, color, dark, icon, total = 40, onClick, lang }: {
  label: string; count: number; color: string; dark: string; icon: string; total?: number; onClick: () => void; lang: LangCode;
}) {
  return (
    <div
      onClick={onClick}
      className="flex flex-col items-center justify-center p-2 sm:p-2.5 rounded-md transition-all duration-300 hover:scale-[1.06] hover:shadow-md cursor-pointer"
      style={{ background: '#FFFFFF', border: '1px solid #E0E0E0' }}
    >
      <div className="w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center mb-1.5" style={{ backgroundColor: color }}>
        <StatusIcon type={icon} />
      </div>
      <div className="flex items-baseline gap-0.5 mb-0.5">
        <span className="text-lg sm:text-xl font-bold leading-none" style={{ color: dark }}>{count}</span>
        <span className="text-[9px] sm:text-[10px]" style={{ color: '#666' }}>/ {total}</span>
      </div>
      <p className="text-[8px] sm:text-[10px] font-medium leading-tight text-center" style={{ color: '#666' }}>{t(lang, `level.${label}`)}</p>
    </div>
  );
}

/** Gradient segmented progress bar */
function GradientBar({ distribution, total }: {
  distribution: { key: string; color: string; count: number }[];
  total: number;
}) {
  return (
    <div className="flex h-2 rounded-full overflow-hidden">
      {distribution.map((seg, i) => {
        const pct = Math.round((seg.count / total) * 100);
        return (
          <div key={seg.key} className="h-full transition-all duration-700 ease-out first:rounded-l-full last:rounded-r-full" style={{ width: `${pct}%`, backgroundColor: seg.color, borderRight: i < distribution.length - 1 ? '1.5px solid white' : 'none' }} />
        );
      })}
    </div>
  );
}

function OverviewCard({ title, score, delta, hasPrev, rating, distribution, total, headerIcon, onStatClick, lang }: {
  title: string;
  score: number;
  delta: number;
  hasPrev: boolean;
  rating: string;
  distribution: { key: string; color: string; bg: string; dark: string; icon: string; count: number }[];
  total: number;
  headerIcon: React.ReactNode;
  onStatClick: (level: string) => void;
  lang: LangCode;
}) {
  const ringColor = score >= 70 ? '#4A90E2' : score >= 50 ? '#F5A623' : '#D0021B';
  const ratingColor = score >= 70 ? '#27AE60' : score >= 50 ? '#F5A623' : '#D0021B';

  return (
    <div className="rounded-xl p-4 sm:p-5 transition-all duration-300 hover:shadow-lg cursor-default" style={{ background: '#F0F9F0', border: '1px solid #E0E0E0' }}>
      <div className="flex items-center gap-3 mb-2">
        <ProgressRing score={score} color={ringColor} size={64} strokeWidth={5} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <div className="flex-shrink-0" style={{ color: '#27AE60' }}>{headerIcon}</div>
            <h3 className="text-xs sm:text-sm font-bold uppercase tracking-wider" style={{ color: '#333' }}>{title}</h3>
          </div>
          <div className="flex items-center justify-between gap-2">
            {hasPrev && <span className="text-xs" style={{ color: '#666' }}>{t(lang, 'summary.prev')} {score - delta}</span>}
            <span className="inline-block px-3 py-1 rounded text-xs font-bold text-white flex-shrink-0" style={{ backgroundColor: ratingColor }}>{t(lang, `rating.${rating}`)}</span>
          </div>
        </div>
      </div>

      {hasPrev && (
        <div className="flex justify-center mb-3">
          <div className={`flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-semibold ${delta >= 0 ? 'text-emerald-600' : 'text-red-600'}`}>
            {delta >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
            {delta >= 0 ? '+' : ''}{delta} {t(lang, 'summary.pts')}
          </div>
        </div>
      )}

      {/* 4 vertical indicator cards — clickable */}
      <div className="grid grid-cols-4 gap-1.5 mb-3">
        {distribution.map(lvl => (
          <VerticalStatCard
            key={lvl.key}
            label={lvl.key}
            count={lvl.count}
            color={lvl.color}
            dark={lvl.dark}
            icon={lvl.icon}
            total={total}
            onClick={() => onStatClick(lvl.key)}
            lang={lang}
          />
        ))}
      </div>

      <GradientBar distribution={distribution} total={total} />
    </div>
  );
}

export default function SummarySection({ data, onOpenRec, lang = 'fr' }: SummarySectionProps) {
  const [riSheetOpen, setRiSheetOpen] = useState(false);
  const [dialogType, setDialogType] = useState<'compliance' | 'effectiveness' | null>(null);
  const [selectedLevel, setSelectedLevel] = useState<string | null>(null);

  const prev = data.previousEvaluation;
  const hasPrev = prev.date && prev.date !== 'N/A';
  const compScore = data.latestEvaluation.overallCompliance;
  const effScore = data.latestEvaluation.overallEffectiveness;
  const compDelta = hasPrev ? compScore - prev.overallCompliance : 0;
  const effDelta = hasPrev ? effScore - prev.overallEffectiveness : 0;

  const getRating = (s: number) => s >= 70 ? 'Satisfaisant' : s >= 50 ? 'Suffisant' : s >= 35 ? 'Non Satisfaisant' : 'Insuffisant';

  const complianceDist = COMPLIANCE_LEVELS.map(lvl => ({
    ...lvl,
    count: data.recommendations.filter(r => r.compliance === lvl.key).length,
  }));

  const effectivenessLevels = [
    { key: 'Élevé', color: '#2ECC71', bg: '#f0fdf4', dark: '#27AE60', icon: 'check' },
    { key: 'Significatif', color: '#7ED321', bg: '#f7fef9', dark: '#65a30d', icon: 'minus' },
    { key: 'Modéré', color: '#F5A623', bg: '#fffbeb', dark: '#D4911E', icon: 'warning' },
    { key: 'Faible', color: '#D0021B', bg: '#fef2f2', dark: '#B91C1C', icon: 'x' },
  ] as const;

  const effectDist = effectivenessLevels.map(lvl => ({
    ...lvl,
    count: data.immediateResults.filter(r => r.effectiveness === lvl.key).length,
  }));

  function handleStatClick(type: 'compliance' | 'effectiveness', level: string) {
    setDialogType(type);
    setSelectedLevel(level);
  }

  const filteredRecs = dialogType === 'compliance' && selectedLevel
    ? data.recommendations.filter(r => r.compliance === selectedLevel)
    : [];

  const filteredRIs = dialogType === 'effectiveness' && selectedLevel
    ? data.immediateResults.filter(r => r.effectiveness === selectedLevel)
    : [];

  const dialogOpen = dialogType !== null && selectedLevel !== null;

  const COMPLIANCE_COLOR: Record<string, string> = {
    'Conforme': '#2ECC71',
    'Largement Conforme': '#7ED321',
    'Partiellement Conforme': '#F5A623',
    'Non Conforme': '#D0021B',
  };

  const EFFECTIVENESS_COLOR: Record<string, string> = {
    'Élevé': '#22c55e',
    'Significatif': '#84cc16',
    'Modéré': '#f97316',
    'Faible': '#ef4444',
  };

  // Translated selected level for display
  const selectedLevelDisplay = selectedLevel ? t(lang, `level.${selectedLevel}`) : '';

  // Dialog title count text
  const dialogCountText = dialogType === 'compliance'
    ? `${filteredRecs.length} ${filteredRecs.length > 1 ? t(lang, 'rec.recommendations_word') : t(lang, 'rec.recommendation_word')}`
    : `${filteredRIs.length} ${t(lang, filteredRIs.length > 1 ? 'ri.immediateOutcomes' : 'ri.riImmediate').toLowerCase()}`;

  return (
    <section className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <OverviewCard
          title={t(lang, 'summary.technicalCompliance')}
          score={compScore}
          delta={compDelta}
          hasPrev={hasPrev}
          rating={getRating(compScore)}
          distribution={complianceDist}
          total={40}
          headerIcon={
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          }
          onStatClick={(level) => handleStatClick('compliance', level)}
          lang={lang}
        />
        <OverviewCard
          title={t(lang, 'summary.systemEffectiveness')}
          score={effScore}
          delta={effDelta}
          hasPrev={hasPrev}
          rating={getRating(effScore)}
          distribution={effectDist}
          total={11}
          headerIcon={
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
            </svg>
          }
          onStatClick={(level) => handleStatClick('effectiveness', level)}
          lang={lang}
        />
        <RISummarySheet open={riSheetOpen} onOpenChange={setRiSheetOpen} immediateResults={data.immediateResults} onOpenRec={onOpenRec} />
      </div>

      {/* Unified Statistics Dialog for Summary dice */}
      <Dialog open={dialogOpen} onOpenChange={(open) => { if (!open) { setDialogType(null); setSelectedLevel(null); } }}>
        <DialogContent className="sm:max-w-2xl max-h-[80vh] flex flex-col">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              <span
                className="w-3 h-3 rounded-full inline-block"
                style={{ backgroundColor: dialogType === 'compliance'
                  ? (COMPLIANCE_COLOR[selectedLevel || ''] || '#9ca3af')
                  : (EFFECTIVENESS_COLOR[selectedLevel || ''] || '#9ca3af') }}
              />
              {selectedLevelDisplay} — {dialogCountText}
            </DialogTitle>
            <DialogDescription>
              {dialogType === 'compliance'
                ? t(lang, 'rec.listOf').replace('{0}', selectedLevelDisplay)
                : t(lang, 'ri.listOf').replace('{0}', selectedLevelDisplay)}
            </DialogDescription>
          </DialogHeader>

          {dialogType === 'compliance' && (
            <div className="overflow-y-auto -mx-1 px-1">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="text-left py-2 pr-3 font-semibold text-muted-foreground w-16">{t(lang, 'overview.no')}</th>
                    <th className="text-left py-2 pr-3 font-semibold text-muted-foreground">{t(lang, 'rec.recommendation')}</th>
                    <th className="text-right py-2 font-semibold text-muted-foreground w-28">{t(lang, 'rec.level')}</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredRecs.map((rec) => (
                    <tr key={rec.id} className="border-b border-gray-100 hover:bg-muted/50 transition-colors">
                      <td className="py-2.5 pr-3"><span className="font-bold text-foreground">R.{rec.id}</span></td>
                      <td className="py-2.5 pr-3"><span className="text-foreground">{rec.title}</span></td>
                      <td className="py-2.5 text-right">
                        <span className="text-xs font-medium" style={{ color: COMPLIANCE_COLOR[rec.compliance] || '#9ca3af' }}>
                          {COMPLIANCE_CODE_MAP[rec.ratingCode] || rec.ratingCode}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {dialogType === 'effectiveness' && (
            <div className="overflow-y-auto -mx-1 px-1">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-gray-200">
                    <th className="text-left py-2 pr-3 font-semibold text-muted-foreground w-20">{t(lang, 'overview.no')}</th>
                    <th className="text-left py-2 pr-3 font-semibold text-muted-foreground">{t(lang, 'ri.riImmediate')}</th>
                    <th className="text-center py-2 pr-3 font-semibold text-muted-foreground w-20">{t(lang, 'ri.type')}</th>
                    <th className="text-right py-2 font-semibold text-muted-foreground w-28">{t(lang, 'rec.level')}</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredRIs.map((ri) => (
                    <tr key={ri.id} className="border-b border-gray-100 hover:bg-muted/50 transition-colors">
                      <td className="py-2.5 pr-3"><span className="font-bold text-sky-700">RI.{ri.id}</span></td>
                      <td className="py-2.5 pr-3"><span className="text-foreground">{ri.title}</span></td>
                      <td className="py-2.5 pr-3 text-center">
                        {ri.fundamental && <span className="text-[10px] px-1.5 py-0 rounded border text-amber-700 border-amber-300 bg-amber-50">{t(lang, 'ri.fundamental')}</span>}
                      </td>
                      <td className="py-2.5 text-right">
                        <span className="text-xs font-medium" style={{ color: EFFECTIVENESS_COLOR[ri.effectiveness] || '#9ca3af' }}>
                          {EFFECTIVENESS_CODE_MAP[ri.effectivenessCode] || ri.effectivenessCode}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          <div className="mt-auto pt-3 border-t flex items-center justify-between text-xs text-muted-foreground rounded-b-lg px-1">
            <span>{dialogType === 'compliance'
              ? t(lang, 'rec.total').replace('{0}', String(filteredRecs.length))
              : t(lang, 'ri.total').replace('{0}', String(filteredRIs.length))}</span>
            <span>{t(lang, dialogType === 'compliance' ? 'rec.percentTotal' : 'ri.percentTotal').replace('{0}', String(Math.round(((dialogType === 'compliance' ? filteredRecs.length : filteredRIs.length) / (dialogType === 'compliance' ? 40 : 11)) * 100)))}</span>
          </div>
        </DialogContent>
      </Dialog>

      {/* Tabs */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{t(lang, 'summary.title')}</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="strengths">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="strengths" className="text-xs sm:text-sm">
                <CheckCircle2 className="w-4 h-4 mr-1.5 hidden sm:inline" />{t(lang, 'summary.strengths')}
              </TabsTrigger>
              <TabsTrigger value="improvements" className="text-xs sm:text-sm">
                <AlertTriangle className="w-4 h-4 mr-1.5 hidden sm:inline" />{t(lang, 'summary.improvements')}
              </TabsTrigger>
              <TabsTrigger value="risks" className="text-xs sm:text-sm">
                <ShieldAlert className="w-4 h-4 mr-1.5 hidden sm:inline" />{t(lang, 'summary.riskAreas')}
              </TabsTrigger>
            </TabsList>
            <TabsContent value="strengths" className="mt-4">
              <ul className="space-y-3">
                {data.summary.strengths.map((s, i) => (
                  <li key={i} className="flex items-start gap-3 p-3 rounded-lg bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{s}</span>
                  </li>
                ))}
              </ul>
            </TabsContent>
            <TabsContent value="improvements" className="mt-4">
              <ul className="space-y-3">
                {data.summary.areasForImprovement.map((s, i) => (
                  <li key={i} className="flex items-start gap-3 p-3 rounded-lg bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800">
                    <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{s}</span>
                  </li>
                ))}
              </ul>
            </TabsContent>
            <TabsContent value="risks" className="mt-4">
              <ul className="space-y-3">
                {data.summary.highRiskAreas.map((s, i) => (
                  <li key={i} className="flex items-start gap-3 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800">
                    <ShieldAlert className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm">{s}</span>
                  </li>
                ))}
              </ul>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </section>
  );
}