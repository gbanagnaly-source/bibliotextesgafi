// Types
export type Notation = "C" | "LC" | "PC" | "NC";

export interface Critere {
  id: string;
  text: string;
  fondamental: boolean;
}

export interface NoteEvaluateur {
  id: string;
  text: string;
}

export interface Recommandation {
  id: string;
  numero: number;
  titre: string;
  texte: string;
  criteres: Critere[];
  notesEvaluateurs: NoteEvaluateur[];
  notation?: Notation;
}

export interface QuestionEssentielle {
  id: string;
  text: string;
}

export interface ResultatImmédiat {
  id: string;
  numero: number;
  titre: string;
  resume: string;
  caracteristiques: string[];
  recommandationsPrincipales: string[];
  recommandationsCertainsElements: string[];
  questionsEssentielles: QuestionEssentielle[];
  exemplesInformations: string[];
  exemplesFacteursSpecifiques: string[];
  /** All linked recommendations (union of principales + certainsElements) — derived at data level */
  recommandationsLiees: string[];
}

// Notation labels and colors
export const notationInfo: Record<Notation, { label: string; description: string; color: string; bgClass: string; textClass: string }> = {
  C: { label: "Conforme", description: "Le pays est conforme à la Recommandation", color: "#16a34a", bgClass: "bg-green-100 dark:bg-green-900/30", textClass: "text-green-700 dark:text-green-400" },
  LC: { label: "Largement Conforme", description: "Le pays est largement conforme à la Recommandation", color: "#65a30d", bgClass: "bg-lime-100 dark:bg-lime-900/30", textClass: "text-lime-700 dark:text-lime-400" },
  PC: { label: "Partiellement Conforme", description: "Le pays est partiellement conforme à la Recommandation", color: "#ea580c", bgClass: "bg-orange-100 dark:bg-orange-900/30", textClass: "text-orange-700 dark:text-orange-400" },
  NC: { label: "Non Conforme", description: "Le pays n'est pas conforme à la Recommandation", color: "#dc2626", bgClass: "bg-red-100 dark:bg-red-900/30", textClass: "text-red-700 dark:text-red-400" },
};

// All 40 FATF Recommendations
export const recommandations: Recommandation[] = [
  {
    id: "R1", numero: 1, titre: "Évaluation des risques et application d'une approche fondée sur les risques (ABR)",
    texte: "Les pays devraient identifier, évaluer et comprendre les risques de blanchiment de capitaux (BC) et de financement du terrorisme (FT) auxquels ils sont exposés, et prendre des mesures correspondant à leur niveau de risque, y compris en désignant une autorité ou des autorités compétentes chargées de cette évaluation. Les pays devraient s'appuyer sur les informations disponibles pour appliquer une approche fondée sur les risques (ABR). Les risques peuvent varier selon le secteur, l'activité ou le type de client. Les pays devraient déterminer les secteurs, les activités et les types de clients présentant un risque plus élevé, et s'assurer que leurs mesures de lutte contre le BC/FT sont adaptées à ces risques.",
    criteres: [
      { id: "1.1", text: "Il existe une évaluation des risques (ER) ou une mise à jour de l'ER qui est récente (c'est-à-dire achevée au cours des trois dernières années) et qui a été approuvée ou est en cours d'approbation par les autorités nationales compétentes.", fondamental: true },
      { id: "1.2", text: "L'ER identifie, évalue et documente les risques de BC/FT auxquels le pays est exposé, y compris les risques inhérents et les vulnérabilités.", fondamental: true },
      { id: "1.3", text: "L'ER tient compte de toutes les informations pertinentes disponibles au niveau national et, le cas échéant, au niveau international. Les sources d'information comprennent au moins les rapports d'évaluation, les rapports d'activités, les statistiques et les autres informations des autorités de lutte contre le BC/FT et des cellules de renseignement financier (CRF), ainsi que des autres autorités compétentes.", fondamental: true },
      { id: "1.4", text: "L'ER a une portée et une couverture suffisantes, y compris en ce qui concerne les types de criminalité sous-jacente, les secteurs et professions, les produits, services, transactions et canaux de prestation de services.", fondamental: true },
      { id: "1.5", text: "L'ER est diffusée de manière appropriée aux autorités compétentes, aux entités soumises aux obligations de LBC/FT, et aux autres parties prenantes pertinentes, afin de leur permettre de gérer et d'atténuer efficacement les risques identifiés dans l'ER.", fondamental: true },
      { id: "1.6", text: "L'ER est révisée et mise à jour régulièrement pour tenir compte des risques nouveaux ou émergents. En cas de changements importants des risques ou des circonstances, des mises à jour extraordinaires sont effectuées en temps opportun.", fondamental: false },
    ],
    notesEvaluateurs: [
      { id: "NE1.1", text: "L'évaluation devrait déterminer si le processus d'ER est global, s'il couvre tous les risques pertinents et s'il est régulièrement mis à jour. Les évaluateurs devraient vérifier si l'ER est documentée de manière adéquate et si elle a été diffusée aux parties prenantes concernées." },
      { id: "NE1.2", text: "Les évaluateurs devraient tenir compte de la qualité de l'ER, notamment de la mesure dans laquelle elle est fondée sur des données empiriques, si elle identifie correctement les risques principaux et les secteurs à risque plus élevé, et si elle aboutit à des mesures d'atténuation appropriées." },
    ],
    notation: "C",
  },
  {
    id: "R2", numero: 2, titre: "Coopération internationale",
    texte: "Les pays devraient coopérer au niveau international dans le cadre d'enquêtes, de poursuites et de procédures judiciaires parallèles portant sur le blanchiment de capitaux et les infractions sous-jacentes, le financement du terrorisme et le financement de la prolifération. Les pays devraient utiliser le réseau du GAFI et de ses organismes régionaux analogues (ORG) comme principal canal de coopération internationale, et devraient mettre en place des mécanismes de coopération efficaces avec d'autres pays.",
    criteres: [
      { id: "2.1", text: "Le pays dispose d'un cadre juridique adéquat pour la coopération internationale en matière de BC/FT/FP, y compris l'entraide judiciaire, l'extradition et la coopération entre autorités de contrôle.", fondamental: true },
      { id: "2.2", text: "Le pays a désigné une autorité centrale compétente pour recevoir et traiter les demandes de coopération internationale.", fondamental: true },
      { id: "2.3", text: "Les demandes de coopération internationale sont traitées de manière rapide, efficace et constructive.", fondamental: true },
      { id: "2.4", text: "Le pays ne refuse pas la coopération internationale pour des raisons de secret bancaire ou de fiscalité.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE2.1", text: "Les évaluateurs devraient vérifier si le pays a conclu les traités et accords nécessaires pour la coopération internationale." },
    ],
    notation: "LC",
  },
  {
    id: "R3", numero: 3, titre: "Infraction de blanchiment de capitaux",
    texte: "Les pays devraient désigner le blanchiment de capitaux comme infraction pénale conformément à la Convention de Vienne de 1988, la Convention de Palerme de 2000 et la Convention des Nations Unies contre la corruption. Les pays devraient appliquer l'infraction de blanchiment de capitaux à tous les crimes graves, dans le but d'inclure la plus large gamme d'infractions sous-jacentes.",
    criteres: [
      { id: "3.1", text: "Le blanchiment de capitaux est incriminé conformément aux normes internationales, y compris toutes les formes de blanchiment (conversion, dissimulation, participation, tentative et complicité).", fondamental: true },
      { id: "3.2", text: "L'infraction de blanchiment de capitaux s'applique à tous les crimes graves avec un champ d'application large des infractions sous-jacentes.", fondamental: true },
      { id: "3.3", text: "La responsabilité des personnes morales est établie en matière de blanchiment de capitaux.", fondamental: false },
      { id: "3.4", text: "Les sanctions applicables au blanchiment de capitaux sont proportionnées, dissuasives et effectives, y compris des peines d'emprisonnement.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE3.1", text: "Les évaluateurs devraient vérifier la portée de l'incrimination, y compris la liste des infractions sous-jacentes et les sanctions prévues." },
    ],
    notation: "LC",
  },
  {
    id: "R4", numero: 4, titre: "Confiscation et mesures instrumentaires",
    texte: "Les pays devraient adopter des mesures analogues à celles énoncées dans la Convention de Vienne de 1988, la Convention de Palerme de 2000 et la Convention contre la corruption, notamment en ce qui concerne la confiscation et les mesures instrumentaires relatives aux produits du crime, aux biens, aux instruments ou à tout autre objet lié à ces infractions.",
    criteres: [
      { id: "4.1", text: "Des mesures de confiscation sont en place, y compris la confiscation de produits, d'instruments et de biens d'une valeur correspondante.", fondamental: true },
      { id: "4.2", text: "La confiscation peut être prononcée sur la base d'une condamnation pénale ou par d'autres procédures, y compris la confiscation sans condamnation (confiscation en valeur).", fondamental: true },
      { id: "4.3", text: "Des mesures provisoires (gel, saisie) sont disponibles pour empêcher le transfert, la dissipation ou la destruction des biens.", fondamental: true },
      { id: "4.4", text: "Le pays dispose de mécanismes efficaces pour la gestion et la disposition des biens confisqués.", fondamental: false },
    ],
    notesEvaluateurs: [
      { id: "NE4.1", text: "Les évaluateurs devraient examiner le cadre juridique et les pratiques de confiscation, y compris les statistiques sur les biens confisqués." },
    ],
    notation: "PC",
  },
  {
    id: "R5", numero: 5, titre: "Infraction de financement du terrorisme",
    texte: "Les pays devraient désigner le financement du terrorisme comme infraction pénale, conformément à la Convention des Nations Unies pour la répression du financement du terrorisme de 1999, et devraient incriminer non seulement le financement d'actes terroristes, mais aussi le financement d'organisations terroristes et de terroristes individuels.",
    criteres: [
      { id: "5.1", text: "Le financement du terrorisme est incriminé conformément aux normes internationales, y compris la collecte et la fourniture de fonds en vue de commettre des actes terroristes.", fondamental: true },
      { id: "5.2", text: "L'infraction couvre le financement d'organisations terroristes et de terroristes individuels, même en l'absence de lien avec un acte terroriste spécifique.", fondamental: true },
      { id: "5.3", text: "Les tentatives, la complicité et la participation au financement du terrorisme sont également incriminées.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE5.1", text: "Les évaluateurs doivent vérifier la conformité avec la Convention de 1999 et les résolutions pertinentes du Conseil de sécurité des Nations Unies." },
    ],
    notation: "C",
  },
  {
    id: "R6", numero: 6, titre: "Infraction de financement de la prolifération",
    texte: "Les pays devraient désigner le financement de la prolifération d'armes de destruction massive comme infraction pénale. Ils devraient le faire en se conformant aux instruments juridiques internationaux pertinents auxquels le pays est partie, et en intégrant les résolutions du Conseil de sécurité des Nations Unies dans leur droit interne.",
    criteres: [
      { id: "6.1", text: "Le financement de la prolifération d'armes de destruction massive est incriminé en droit interne.", fondamental: true },
      { id: "6.2", text: "Les résolutions pertinentes du Conseil de sécurité de l'ONU sont intégrées dans le droit interne et effectivement appliquées.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE6.1", text: "Les évaluateurs devraient vérifier la mise en œuvre des résolutions du Conseil de sécurité et les mécanismes de gel des avoirs." },
    ],
    notation: "PC",
  },
  {
    id: "R7", numero: 7, titre: "Mesures ciblées liées au financement de la prolifération",
    texte: "Les pays devraient mettre en œuvre des mesures financières ciblées conformément aux résolutions pertinentes du Conseil de sécurité des Nations Unies, afin de prévenir le financement de la prolifération d'armes de destruction massive et de leurs systèmes de lancement et de transport. Ces mesures devraient inclure le gel des avoirs des personnes et entités désignées.",
    criteres: [
      { id: "7.1", text: "Des mécanismes juridiques et opérationnels sont en place pour mettre en œuvre les résolutions du Conseil de sécurité de l'ONU relatives au gel des avoirs.", fondamental: true },
      { id: "7.2", text: "Les listes de personnes et entités désignées sont régulièrement mises à jour et diffusées aux institutions financières et autres entités concernées.", fondamental: true },
      { id: "7.3", text: "Les institutions financières et autres entités concernées respectent les obligations de gel des avoirs de manière effective.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE7.1", text: "Les évaluateurs doivent vérifier la rapidité et l'efficacité de la mise en œuvre des mesures de gel." },
    ],
    notation: "PC",
  },
  {
    id: "R8", numero: 8, titre: "Régimes de sanctions applicables aux personnes morales",
    texte: "Les pays devraient veiller à ce que des sanctions efficaces, proportionnées et dissuasives, qu'elles soient pénales, civiles ou administratives, soient applicables aux personnes morales jugées responsables d'infractions de blanchiment de capitaux, de financement du terrorisme ou de financement de la prolifération.",
    criteres: [
      { id: "8.1", text: "La responsabilité des personnes morales est établie pour les infractions de BC/FT/FP.", fondamental: true },
      { id: "8.2", text: "Des sanctions efficaces, proportionnées et dissuasives sont applicables aux personnes morales, y compris des sanctions pénales, civiles ou administratives.", fondamental: true },
      { id: "8.3", text: "Les autorités compétentes disposent des pouvoirs nécessaires pour enquêter sur les personnes morales et leur imposer des sanctions.", fondamental: false },
    ],
    notesEvaluateurs: [
      { id: "NE8.1", text: "Les évaluateurs devraient vérifier si les sanctions sont effectivement appliquées en pratique et si elles sont dissuasives." },
    ],
    notation: "LC",
  },
  {
    id: "R9", numero: 9, titre: "Secret bancaire",
    texte: "Les pays devraient veiller à ce que les lois et réglementations relatives au secret bancaire ou à la confidentialité des informations ne fassent pas obstacle à la mise en œuvre des recommandations du GAFI, et puissent être levées pour les autorités compétentes chargées de la lutte contre le blanchiment de capitaux et le financement du terrorisme.",
    criteres: [
      { id: "9.1", text: "Les dispositions relatives au secret bancaire ne font pas obstacle à la mise en œuvre des recommandations du GAFI.", fondamental: true },
      { id: "9.2", text: "Les autorités compétentes (services de renseignement financier, autorités de poursuite, autorités de contrôle) ont accès aux informations bancaires et financières dans le cadre de leurs fonctions LBC/FT.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE9.1", text: "Les évaluateurs doivent vérifier les mécanismes légaux permettant de lever le secret bancaire pour les autorités compétentes." },
    ],
    notation: "C",
  },
  {
    id: "R10", numero: 10, titre: "Obligations de diligence raisonnable de la clientèle (DR)",
    texte: "Les institutions financières devraient être soumises à des obligations de diligence raisonnable à l'égard de la clientèle (DR) lorsqu'elles établissent des relations d'affaires, effectuent des transactions occasionnelles dépassant le seuil applicable, soupçonnent l'existence d'un blanchiment de capitaux ou d'un financement du terrorisme, ou doutent de l'exactitude des données d'identification précédemment obtenues. Les mesures de DR comprennent l'identification et la vérification de l'identité du client et du bénéficiaire effectif, l'identification du bénéficiaire d'une transaction, la compréhension de l'objet et de la nature de la relation d'affaires, et la surveillance continue de la relation d'affaires.",
    criteres: [
      { id: "10.1", text: "Les obligations de DR sont prescrites par la loi ou des réglementations contraignantes pour toutes les institutions financières.", fondamental: true },
      { id: "10.2", text: "La DR inclut l'identification et la vérification de l'identité du client et la détermination du bénéficiaire effectif.", fondamental: true },
      { id: "10.3", text: "La DR inclut la compréhension de l'objet et de la nature de la relation d'affaires.", fondamental: true },
      { id: "10.4", text: "La DR inclut la surveillance continue de la relation d'affaires et des transactions.", fondamental: true },
      { id: "10.5", text: "Des mesures de DR simplifiées ou renforcées sont appliquées en fonction du niveau de risque du client.", fondamental: true },
      { id: "10.6", text: "Des mesures de DR renforcées sont appliquées pour les personnes politiquement exposées (PPE).", fondamental: true },
      { id: "10.7", text: "Les obligations de DR sont effectivement appliquées et supervisées par les autorités compétentes.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE10.1", text: "Les évaluateurs devraient vérifier la portée et l'efficacité des mesures de DR, y compris la vérification du bénéficiaire effectif et les mesures renforcées pour les PPE." },
      { id: "NE10.2", text: "L'évaluation devrait inclure la vérification de l'application pratique des mesures de DR par les institutions financières." },
    ],
    notation: "LC",
  },
  {
    id: "R11", numero: 11, titre: "Conservation des enregistrements",
    texte: "Les institutions financières devraient conserver, pendant au moins cinq ans, tous les enregistrements nécessaires relatifs aux transactions, nationales et internationales, pour pouvoir les fournir rapidement aux autorités compétentes lorsqu'elles en font la demande. Ces enregistrements doivent être suffisamment complets pour permettre la reconstruction de transactions individuelles.",
    criteres: [
      { id: "11.1", text: "Les obligations de conservation des enregistrements sont prescrites par la loi ou des réglementations contraignantes.", fondamental: true },
      { id: "11.2", text: "Les enregistrements de transactions et les données d'identification de la clientèle sont conservés pendant au moins cinq ans après la fin de la relation d'affaires.", fondamental: true },
      { id: "11.3", text: "Les enregistrements sont suffisamment complets pour permettre la reconstruction des transactions.", fondamental: true },
      { id: "11.4", text: "Les enregistrements sont accessibles aux autorités compétentes dans des délais raisonnables.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE11.1", text: "Les évaluateurs doivent vérifier la conformité des pratiques de conservation avec les exigences réglementaires." },
    ],
    notation: "C",
  },
  {
    id: "R12", numero: 12, titre: "Déclarations de transactions suspectes (DOS)",
    texte: "Les institutions financières, les professions non financières et les autres entités désignées devraient déclarer les transactions suspectes aux autorités compétentes (la cellule de renseignement financier - CRF). Les déclarations devraient être faites promptement, sans en avertir les clients concernés, et devraient être fondées sur des faits concrets ou sur des soupçons raisonnables.",
    criteres: [
      { id: "12.1", text: "L'obligation de déclarer les transactions suspectes est prescrite par la loi ou des réglementations contraignantes pour toutes les entités soumises aux obligations LBC/FT.", fondamental: true },
      { id: "12.2", text: "La déclaration est faite à la CRF (ou autorité équivalente) dans les délais prévus.", fondamental: true },
      { id: "12.3", text: "Les entités soumises aux obligations sont protégées contre toute responsabilité lorsqu'elles font de bonne foi des déclarations de transactions suspectes.", fondamental: true },
      { id: "12.4", text: "Les déclarations sont fondées sur des soupçons raisonnables et le processus de déclaration est effectivement appliqué.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE12.1", text: "Les évaluateurs devraient examiner le volume et la qualité des DOS reçues par la CRF et leur utilisation ultérieure." },
    ],
    notation: "LC",
  },
  {
    id: "R13", numero: 13, titre: "Déclarations de transactions en espèces dépassant un seuil",
    texte: "Les pays devraient exiger des institutions financières qu'elles déclarent les transactions nationales et internationales en espèces dépassant un seuil déterminé, aux autorités compétentes. Le GAFI recommande un seuil de 15 000 USD/EUR pour les transactions nationales et internationales.",
    criteres: [
      { id: "13.1", text: "L'obligation de déclarer les transactions en espèces dépassant un seuil est prescrite par la loi ou des réglementations contraignantes.", fondamental: true },
      { id: "13.2", text: "Le seuil de déclaration est conforme aux normes du GAFI (15 000 USD/EUR) ou est inférieur.", fondamental: true },
      { id: "13.3", text: "Les déclarations sont faites à l'autorité compétente et sont effectivement utilisées.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE13.1", text: "Les évaluateurs devraient vérifier si les déclarations sont compilées et analysées de manière utile." },
    ],
    notation: "C",
  },
  {
    id: "R14", numero: 14, titre: "Déclarations de virements télégraphiques",
    texte: "Les pays devraient exiger des institutions financières qu'elles incluent des informations requises sur l'expéditeur et le bénéficiaire dans les virements télégraphiques, et que ces informations accompagnent le virement tout au long de la chaîne de paiement. Les institutions financières devraient effectuer des contrôles sur ces informations lorsqu'elles reçoivent des virements.",
    criteres: [
      { id: "14.1", text: "Les obligations relatives aux informations sur les virements télégraphiques sont prescrites par la loi ou des réglementations contraignantes.", fondamental: true },
      { id: "14.2", text: "Les informations sur l'expéditeur (nom, numéro de compte, adresse) et le bénéficiaire sont incluses dans les virements télégraphiques.", fondamental: true },
      { id: "14.3", text: "Des contrôles sont effectués sur les informations des virements reçus, et les virements dépourvus d'informations requises sont signalés.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE14.1", text: "Les évaluateurs doivent vérifier la conformité avec les exigences du GAFI relatives aux paiements transfrontaliers." },
    ],
    notation: "LC",
  },
  {
    id: "R15", numero: 15, titre: "Nouvelles technologies",
    texte: "Les pays et les institutions financières devraient identifier et évaluer les risques de BC/FT pouvant résulter du développement de nouveaux produits et de nouvelles pratiques commerciales, de l'utilisation de nouvelles technologies, et de l'utilisation de types de moyens de paiement nouveaux ou en développement. Ils devraient prendre les mesures appropriées pour gérer ces risques avant le lancement de ces produits ou services.",
    criteres: [
      { id: "15.1", text: "Des mesures sont en place pour identifier et évaluer les risques de BC/FT liés aux nouvelles technologies et aux nouveaux produits.", fondamental: true },
      { id: "15.2", text: "Des mesures de gestion des risques sont mises en œuvre avant le lancement de nouveaux produits, pratiques ou technologies.", fondamental: true },
      { id: "15.3", text: "Les autorités de contrôle supervisent la gestion des risques liés aux nouvelles technologies par les entités réglementées.", fondamental: false },
    ],
    notesEvaluateurs: [
      { id: "NE15.1", text: "Les évaluateurs devraient examiner les processus d'évaluation des risques liés aux technologies financières, y compris les crypto-actifs et les monnaies virtuelles." },
    ],
    notation: "PC",
  },
  {
    id: "R16", numero: 16, titre: "Transferts électroniques de fonds (TEF) — Déclaration des virements transfrontaliers",
    texte: "Les pays devraient exiger des institutions financières qu'elles signalent tous les virements électroniques transfrontaliers d'une certaine valeur, conformément aux normes internationales. Ces informations devraient être transmises aux autorités compétentes pour les aider à détecter les transactions suspectes.",
    criteres: [
      { id: "16.1", text: "Les obligations de signalement des virements transfrontaliers sont prescrites par la loi ou des réglementations contraignantes.", fondamental: true },
      { id: "16.2", text: "Les informations requises sont transmises aux autorités compétentes.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE16.1", text: "Les évaluateurs doivent vérifier le respect des normes internationales de signalement des virements transfrontaliers." },
    ],
    notation: "LC",
  },
  {
    id: "R17", numero: 17, titre: "Dépendance à l'égard de tiers",
    texte: "Les institutions financières devraient être autorisées à s'appuyer sur des tiers pour effectuer des éléments des mesures de diligence raisonnable de la clientèle (DR). Cependant, l'institution financière qui s'appuie sur un tiers reste pleinement responsable de ses obligations de DR.",
    criteres: [
      { id: "17.1", text: "Le cadre juridique permet aux institutions financières de s'appuyer sur des tiers pour les mesures de DR.", fondamental: true },
      { id: "17.2", text: "Des exigences appropriées sont imposées aux tiers, y compris la capacité de fournir immédiatement les informations de DR pertinentes.", fondamental: true },
      { id: "17.3", text: "L'institution financière qui s'appuie sur un tiers reste responsable du respect de ses obligations de DR.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE17.1", text: "Les évaluateurs doivent vérifier les mécanismes de supervision de la dépendance à l'égard des tiers." },
    ],
    notation: "C",
  },
  {
    id: "R18", numero: 18, titre: "Contrôles internes et filiales étrangères",
    texte: "Les institutions financières devraient mettre en place des programmes de lutte contre le blanchiment de capitaux et le financement du terrorisme (LBC/FT) qui comprennent des politiques, des procédures et des contrôles internes adéquats, la nomination d'un responsable de la conformité au niveau de la direction, la formation continue du personnel et des procédures de vérification. Ces programmes devraient s'appliquer également aux succursales et filiales étrangères, en tenant compte du cadre réglementaire du pays hôte.",
    criteres: [
      { id: "18.1", text: "Les institutions financières sont tenues par la loi ou des réglementations de mettre en place des programmes LBC/FT internes adéquats.", fondamental: true },
      { id: "18.2", text: "Les programmes comprennent des politiques, des procédures, des contrôles internes, un audit indépendant, la nomination d'un responsable de la conformité et une formation du personnel.", fondamental: true },
      { id: "18.3", text: "Des exigences de contrôle interne et de conformité s'appliquent aux succursales et filiales étrangères, adaptées au risque et au cadre réglementaire du pays hôte.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE18.1", text: "Les évaluateurs doivent vérifier l'efficacité des programmes LBC/FT et leur application effective." },
    ],
    notation: "LC",
  },
  {
    id: "R19", numero: 19, titre: "Pays et juridictions à haut risque",
    texte: "Les pays devraient exiger des institutions financières qu'elles appliquent des mesures de diligence raisonnable renforcées (DRR) aux transactions et aux relations d'affaires impliquant des pays et des juridictions à haut risque identifiés par le GAFI. Ces mesures devraient inclure l'obtention d'informations supplémentaires sur le client, le bénéficiaire effectif et la nature de la transaction.",
    criteres: [
      { id: "19.1", text: "Les institutions financières sont tenues d'appliquer des mesures de DRR aux pays et juridictions identifiés comme présentant des déficiences stratégiques par le GAFI.", fondamental: true },
      { id: "19.2", text: "Les mesures de DRR comprennent l'obtention d'informations supplémentaires et la réalisation de contrôles renforcés.", fondamental: true },
      { id: "19.3", text: "Les autorités de contrôle supervisent la mise en œuvre des mesures de DRR par les institutions financières.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE19.1", text: "Les évaluateurs doivent vérifier la mise en œuvre effective des mesures de DRR et leur conformité avec les listes du GAFI." },
    ],
    notation: "C",
  },
  {
    id: "R20", numero: 20, titre: "Déclaration de transactions suspectes — autres entités désignées",
    texte: "Les professions et entreprises non financières désignées (PNFD) telles que les casinos, les agents immobiliers, les marchands de pierres précieuses, les avocats, les notaires et les comptables, devraient être soumises à des obligations de déclaration de transactions suspectes lorsqu'elles effectuent des transactions au nom de leurs clients.",
    criteres: [
      { id: "20.1", text: "Les PNFD sont soumises à des obligations de déclaration de transactions suspectes par la loi ou des réglementations.", fondamental: true },
      { id: "20.2", text: "Les déclarations sont faites à la CRF et sont effectivement utilisées.", fondamental: true },
      { id: "20.3", text: "Les PNFD sont protégées contre toute responsabilité pour les déclarations de bonne foi.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE20.1", text: "Les évaluateurs devraient vérifier la couverture et l'efficacité des obligations de déclaration pour les PNFD." },
    ],
    notation: "PC",
  },
  {
    id: "R21", numero: 21, titre: "Déclaration de transactions suspectes — casinos",
    texte: "Les casinos devraient être tenus de déclarer les transactions suspectes à la CRF. Ils devraient être soumis à un régime complet de LBC/FT, y compris les obligations de diligence raisonnable de la clientèle, la conservation des enregistrements et les déclarations de transactions en espèces.",
    criteres: [
      { id: "21.1", text: "Les casinos sont soumis à un régime LBC/FT complet, y compris les obligations de DR, de conservation des enregistrements et de déclaration.", fondamental: true },
      { id: "21.2", text: "Les casinos déclarent les transactions suspectes à la CRF.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE21.1", text: "Les évaluateurs doivent vérifier l'efficacité du régime LBC/FT applicable aux casinos." },
    ],
    notation: "LC",
  },
  {
    id: "R22", numero: 22, titre: "Mesures applicables aux clients des DNFBP",
    texte: "Les professions et entreprises non financières désignées (DNFBP) devraient être soumises à des obligations de diligence raisonnable de la clientèle. Cela comprend l'identification du client et du bénéficiaire effectif, la vérification de l'identité, la compréhension de la nature de la relation d'affaires, et la surveillance continue.",
    criteres: [
      { id: "22.1", text: "Les DNFBP sont soumises à des obligations de DR par la loi ou des réglementations.", fondamental: true },
      { id: "22.2", text: "Les obligations de DR incluent l'identification du client, du bénéficiaire effectif, la vérification de l'identité et la surveillance continue.", fondamental: true },
      { id: "22.3", text: "Les mesures de DR simplifiées ou renforcées sont appliquées en fonction du risque.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE22.1", text: "Les évaluateurs doivent vérifier l'application effective des obligations de DR par les DNFBP." },
    ],
    notation: "PC",
  },
  {
    id: "R23", numero: 23, titre: "Mesures applicables aux personnes politiquement exposées (PPE) — DNFBP",
    texte: "Les DNFBP devraient être tenus d'appliquer des mesures de diligence raisonnable renforcées à l'égard des personnes politiquement exposées (PPE), y compris l'obtention de l'approbation de la direction pour l'établissement de la relation d'affaires, la détermination de la source de la fortune et du patrimoine, et la surveillance continue renforcée de la relation d'affaires.",
    criteres: [
      { id: "23.1", text: "Les DNFBP sont tenus d'appliquer des mesures de DRR aux PPE, y compris l'identification et la vérification renforcées.", fondamental: true },
      { id: "23.2", text: "Les mesures de DRR incluent l'obtention de l'approbation de la direction, la détermination de la source de la fortune et la surveillance continue renforcée.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE23.1", text: "Les évaluateurs doivent vérifier l'application effective des mesures de DRR aux PPE par les DNFBP." },
    ],
    notation: "PC",
  },
  {
    id: "R24", numero: 24, titre: "Transparence des personnes morales",
    texte: "Les pays devraient prendre des mesures pour empêcher l'utilisation abusive des personnes morales pour le blanchiment de capitaux. Des informations adéquates, exactes et à jour sur les bénéficiaires effectifs et la structure de propriété des personnes morales devraient être disponibles aux autorités compétentes de manière rapide et fiable.",
    criteres: [
      { id: "24.1", text: "Des informations adéquates, exactes et à jour sur les bénéficiaires effectifs des personnes morales sont disponibles.", fondamental: true },
      { id: "24.2", text: "Les personnes morales sont tenues de conserver des informations sur leurs bénéficiaires effectifs et de les mettre à jour régulièrement.", fondamental: true },
      { id: "24.3", text: "Les autorités compétentes ont accès aux informations sur les bénéficiaires effectifs de manière rapide et fiable.", fondamental: true },
      { id: "24.4", text: "Des sanctions effectives, proportionnées et dissuasives sont prévues en cas de non-respect des obligations de transparence.", fondamental: false },
    ],
    notesEvaluateurs: [
      { id: "NE24.1", text: "Les évaluateurs devraient vérifier l'existence et l'efficacité des registres de bénéficiaires effectifs et leur accessibilité par les autorités compétentes." },
    ],
    notation: "PC",
  },
  {
    id: "R25", numero: 25, titre: "Transparence des constructions juridiques",
    texte: "Les pays devraient prendre des mesures pour empêcher l'utilisation abusive des constructions juridiques (tels que les trusts, les fiducies et autres arrangements similaires) pour le blanchiment de capitaux. Des informations adéquates, exactes et à jour sur les constituateurs, les trustees, les protecteurs, les bénéficiaires et tout autre personne exerçant un contrôle effectif devraient être disponibles aux autorités compétentes.",
    criteres: [
      { id: "25.1", text: "Des informations adéquates, exactes et à jour sur les constructions juridiques (constituateurs, trustees, bénéficiaires) sont disponibles.", fondamental: true },
      { id: "25.2", text: "Les trustees et autres personnes concernées sont tenus de conserver et de mettre à jour les informations sur les bénéficiaires effectifs et la structure du trust.", fondamental: true },
      { id: "25.3", text: "Les autorités compétentes ont accès aux informations sur les constructions juridiques.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE25.1", text: "Les évaluateurs doivent vérifier la disponibilité des informations sur les trusts et les arrangements similaires." },
    ],
    notation: "PC",
  },
  {
    id: "R26", numero: 26, titre: "Réglementation et supervision des institutions financières",
    texte: "Les pays devraient veiller à ce que les institutions financières soient soumises à une réglementation et à une supervision adéquates en matière de lutte contre le blanchiment de capitaux et le financement du terrorisme. Les autorités de supervision ou les autorités de contrôle devraient prendre les mesures nécessaires pour s'assurer que les institutions financières se conforment aux obligations LBC/FT.",
    criteres: [
      { id: "26.1", text: "Toutes les institutions financières sont soumises à une réglementation et à une supervision LBC/FT par des autorités compétentes.", fondamental: true },
      { id: "26.2", text: "Les autorités de supervision ont des pouvoirs adéquats pour surveiller et faire respecter les obligations LBC/FT.", fondamental: true },
      { id: "26.3", text: "Les autorités de supervision mènent des inspections et appliquent des sanctions effectives en cas de non-conformité.", fondamental: true },
      { id: "26.4", text: "Les autorités de supervision disposent de ressources suffisantes pour exercer leurs fonctions.", fondamental: false },
    ],
    notesEvaluateurs: [
      { id: "NE26.1", text: "Les évaluateurs doivent vérifier l'indépendance, les pouvoirs et les ressources des autorités de supervision." },
    ],
    notation: "LC",
  },
  {
    id: "R27", numero: 27, titre: "Pouvoirs des autorités de supervision",
    texte: "Les autorités de supervision ou les autorités de contrôle devraient avoir les pouvoirs nécessaires pour surveiller et s'assurer que les institutions financières se conforment aux obligations LBC/FT. Ces pouvoirs devraient inclure la capacité de procéder à des inspections, de donner des instructions, de suspendre ou de révoquer des licences, et d'imposer des sanctions.",
    criteres: [
      { id: "27.1", text: "Les autorités de supervision ont des pouvoirs légaux pour effectuer des inspections sur place et à distance.", fondamental: true },
      { id: "27.2", text: "Les autorités de supervision peuvent donner des instructions correctives, imposer des restrictions d'activités, et suspendre ou révoquer des licences.", fondamental: true },
      { id: "27.3", text: "Les autorités de supervision peuvent imposer des sanctions administratives, pénales ou civiles effectives et dissuasives.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE27.1", text: "Les évaluateurs doivent vérifier l'utilisation effective de ces pouvoirs en pratique." },
    ],
    notation: "LC",
  },
  {
    id: "R28", numero: 28, titre: "Réglementation et supervision des DNFBP",
    texte: "Les pays devraient veiller à ce que les professions et entreprises non financières désignées (DNFBP) soient soumises à une réglementation et à une supervision adéquates en matière de LBC/FT. La nature de la supervision devrait être adaptée au risque que présente chaque profession.",
    criteres: [
      { id: "28.1", text: "Toutes les DNFBP sont soumises à une réglementation et à une supervision LBC/FT par des autorités compétentes.", fondamental: true },
      { id: "28.2", text: "La supervision est adaptée au risque présenté par chaque type de DNFBP.", fondamental: true },
      { id: "28.3", text: "Les autorités de supervision des DNFBP ont des pouvoirs adéquats pour surveiller et faire respecter les obligations LBC/FT.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE28.1", text: "Les évaluateurs doivent vérifier l'étendue et l'efficacité de la supervision des DNFBP." },
    ],
    notation: "PC",
  },
  {
    id: "R29", numero: 29, titre: "Cellules de renseignement financier (CRF)",
    texte: "Les pays devraient établir une cellule de renseignement financier (CRF) qui fonctionne comme un centre national de réception, d'analyse et de diffusion des déclarations de transactions suspectes (DOS) et d'autres informations pertinentes concernant le blanchiment de capitaux, le financement du terrorisme et les infractions sous-jacentes associées. La CRF devrait avoir accès, directement ou indirectement, aux informations financières, commerciales et administratives dont elle a besoin pour remplir correctement ses fonctions.",
    criteres: [
      { id: "29.1", text: "Le pays dispose d'une CRF opérationnelle qui reçoit, analyse et diffuse les DOS et d'autres informations pertinentes.", fondamental: true },
      { id: "29.2", text: "La CRF a accès, directement ou indirectement, aux informations financières, commerciales et administratives nécessaires à l'exercice de ses fonctions.", fondamental: true },
      { id: "29.3", text: "La CRF est indépendante et protégée contre toute ingérence indue.", fondamental: true },
      { id: "29.4", text: "La CRF dispose de ressources adéquates (humaines, financières, technologiques) pour exercer ses fonctions.", fondamental: true },
      { id: "29.5", text: "La CRF coopère efficacement avec ses homologues étrangers et participe aux réseaux internationaux (Groupe Egmont).", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE29.1", text: "Les évaluateurs doivent évaluer l'efficacité opérationnelle de la CRF, y compris son analyse des DOS et la qualité de ses produits analytiques." },
      { id: "NE29.2", text: "Les évaluateurs devraient vérifier les statistiques sur les DOS reçues, analysées et transmises aux autorités de poursuite." },
    ],
    notation: "C",
  },
  {
    id: "R30", numero: 30, titre: "Responsabilités des autorités de détection et de répression",
    texte: "Les autorités de détection et de répression (services de police, services de douane, parquets) devraient coopérer aux niveaux national et international dans le cadre d'enquêtes et de poursuites portant sur le blanchiment de capitaux et le financement du terrorisme. Elles devraient être en mesure d'effectuer des enquêtes efficaces, de geler et de confisquer les produits du crime, et de poursuivre les auteurs d'infractions de BC/FT.",
    criteres: [
      { id: "30.1", text: "Les autorités de détection et de répression sont compétentes pour enquêter sur les infractions de BC/FT.", fondamental: true },
      { id: "30.2", text: "Les autorités coopèrent efficacement au niveau national et international.", fondamental: true },
      { id: "30.3", text: "Les autorités disposent des pouvoirs d'enquête nécessaires, y compris les perquisitions, les saisies et les interrogatoires.", fondamental: true },
      { id: "30.4", text: "Les poursuites sont effectivement engagées et aboutissent à des condamnations pour des infractions de BC/FT.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE30.1", text: "Les évaluateurs doivent vérifier les statistiques sur les enquêtes, les poursuites et les condamnations pour des infractions de BC/FT." },
    ],
    notation: "LC",
  },
  {
    id: "R31", numero: 31, titre: "Services de police et d'enquête",
    texte: "Les pays devraient veiller à ce que les services de police et d'enquête disposent des pouvoirs, des compétences et des ressources nécessaires pour mener des enquêtes efficaces sur le blanchiment de capitaux et le financement du terrorisme, y compris l'accès aux informations financières, la capacité de mener des perquisitions et des saisies, et la possibilité de travailler en collaboration avec des homologues étrangers.",
    criteres: [
      { id: "31.1", text: "Les services de police ont les compétences et les pouvoirs pour enquêter sur les infractions de BC/FT.", fondamental: true },
      { id: "31.2", text: "Des unités spécialisées dans la lutte contre le BC/FT existent et disposent de ressources adéquates.", fondamental: true },
      { id: "31.3", text: "La coopération internationale en matière d'enquêtes est effective et rapide.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE31.1", text: "Les évaluateurs doivent vérifier les ressources, la formation et les pouvoirs des services de police spécialisés." },
    ],
    notation: "LC",
  },
  {
    id: "R32", numero: 32, titre: "Envois de fonds",
    texte: "Les pays devraient veiller à ce que les services d'envoi de fonds, y compris les opérateurs de transfert d'argent, soient soumis à des obligations de LBC/FT effectives, y compris l'enregistrement ou l'autorisation, les mesures de diligence raisonnable de la clientèle, les déclarations de transactions suspectes et la conservation des enregistrements.",
    criteres: [
      { id: "32.1", text: "Les services d'envoi de fonds sont soumis à un régime d'enregistrement ou d'autorisation.", fondamental: true },
      { id: "32.2", text: "Les services d'envoi de fonds sont soumis à des obligations de DR, de déclaration et de conservation des enregistrements.", fondamental: true },
      { id: "32.3", text: "Les autorités compétentes supervisent et contrôlent effectivement les services d'envoi de fonds.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE32.1", text: "Les évaluateurs doivent vérifier l'efficacité de la supervision des opérateurs de transfert d'argent." },
    ],
    notation: "PC",
  },
  {
    id: "R33", numero: 33, titre: "Statistiques",
    texte: "Les pays devraient maintenir des statistiques complètes sur le nombre et le type de déclarations de transactions suspectes reçues et diffusées, d'enquêtes et de poursuites engagées, de condamnations prononcées, de biens gelés ou confisqués, et de demandes de coopération internationale reçues et traitées.",
    criteres: [
      { id: "33.1", text: "Des statistiques complètes sur les DOS reçues et diffusées sont compilées et publiées.", fondamental: true },
      { id: "33.2", text: "Des statistiques sur les enquêtes, poursuites et condamnations pour des infractions de BC/FT sont compilées et publiées.", fondamental: true },
      { id: "33.3", text: "Des statistiques sur les biens gelés et confisqués sont compilées et publiées.", fondamental: true },
      { id: "33.4", text: "Des statistiques sur la coopération internationale sont compilées et publiées.", fondamental: false },
    ],
    notesEvaluateurs: [
      { id: "NE33.1", text: "Les évaluateurs doivent vérifier la qualité, la fiabilité et la disponibilité des statistiques LBC/FT." },
    ],
    notation: "LC",
  },
  {
    id: "R34", numero: 34, titre: "Guide et retour d'information",
    texte: "Les pays devraient fournir aux institutions financières et aux DNFBP des orientations et des directives sur la mise en œuvre des obligations LBC/FT, et devraient établir des mécanismes de retour d'information avec ces entités pour améliorer la compréhension et l'application des mesures de LBC/FT.",
    criteres: [
      { id: "34.1", text: "Des directives et des orientations sur les obligations LBC/FT sont publiées et régulièrement mises à jour.", fondamental: true },
      { id: "34.2", text: "Des mécanismes de retour d'information sont établis entre les autorités et les entités soumises aux obligations LBC/FT.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE34.1", text: "Les évaluateurs doivent vérifier la pertinence et l'accessibilité des directives publiées." },
    ],
    notation: "C",
  },
  {
    id: "R35", numero: 35, titre: "Sanctions",
    texte: "Les pays devraient veiller à ce que des sanctions effectives, proportionnées et dissuasives soient applicables aux personnes physiques et morales qui ne se conforment pas aux obligations LBC/FT. Ces sanctions devraient être applicables par les autorités de contrôle et les autorités judiciaires.",
    criteres: [
      { id: "35.1", text: "Des sanctions effectives, proportionnées et dissuasives sont prévues par la loi pour le non-respect des obligations LBC/FT.", fondamental: true },
      { id: "35.2", text: "Les autorités de contrôle ont le pouvoir d'imposer des sanctions administratives.", fondamental: true },
      { id: "35.3", text: "Les sanctions sont effectivement appliquées en pratique.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE35.1", text: "Les évaluateurs doivent vérifier le nombre et le type de sanctions effectivement imposées." },
    ],
    notation: "LC",
  },
  {
    id: "R36", numero: 36, titre: "Instruments internationaux",
    texte: "Les pays devraient prendre des mesures pour mettre en œuvre les instruments internationaux pertinents en matière de lutte contre le blanchiment de capitaux, le financement du terrorisme et le financement de la prolifération, y compris les conventions des Nations Unies et les résolutions du Conseil de sécurité.",
    criteres: [
      { id: "36.1", text: "Le pays est partie aux conventions internationales pertinentes (Convention de Vienne, Convention de Palerme, Convention contre la corruption, Convention pour la répression du financement du terrorisme).", fondamental: true },
      { id: "36.2", text: "Les conventions et résolutions internationales sont effectivement intégrées dans le droit interne.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE36.1", text: "Les évaluateurs doivent vérifier le statut de ratification des conventions internationales et leur mise en œuvre." },
    ],
    notation: "C",
  },
  {
    id: "R37", numero: 37, titre: "Assistance juridique mutuelle",
    texte: "Les pays devraient fournir rapidement et de manière constructive le plus large éventail possible d'assistance juridique mutuelle en matière de BC/FT/FP. Les autorités centrales désignées à cet effet devraient avoir les capacités et les ressources nécessaires pour traiter efficacement les demandes d'assistance.",
    criteres: [
      { id: "37.1", text: "Le pays a désigné une autorité centrale pour l'entraide judiciaire en matière de BC/FT/FP.", fondamental: true },
      { id: "37.2", text: "Les demandes d'entraide sont traitées de manière rapide et constructive.", fondamental: true },
      { id: "37.3", text: "Le pays peut fournir un large éventail de mesures d'entraide, y compris la notification de documents, la recherche de preuves, le gel et la confiscation de biens.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE37.1", text: "Les évaluateurs doivent vérifier les délais de traitement et le taux de réponse aux demandes d'entraide." },
    ],
    notation: "LC",
  },
  {
    id: "R38", numero: 38, titre: "Extradition",
    texte: "Les pays devraient reconnaître le blanchiment de capitaux et le financement du terrorisme comme des infractions extradables. Les pays devraient simplifier leurs procédures d'extradition et ne pas imposer de conditions excessives qui pourraient entraver l'efficacité de la coopération internationale.",
    criteres: [
      { id: "38.1", text: "Le BC et le FT sont reconnus comme des infractions extradables.", fondamental: true },
      { id: "38.2", text: "Les procédures d'extradition sont efficaces et ne sont pas soumises à des conditions excessives.", fondamental: true },
      { id: "38.3", text: "Le pays coopère effectivement aux demandes d'extradition pour des infractions de BC/FT.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE38.1", text: "Les évaluateurs doivent vérifier le cadre juridique et les pratiques d'extradition." },
    ],
    notation: "LC",
  },
  {
    id: "R39", numero: 39, titre: "Autres formes de coopération internationale",
    texte: "Les pays devraient coopérer au-delà de l'entraide judiciaire formelle, en utilisant des mécanismes tels que l'échange d'informations entre autorités de contrôle, la coopération entre cellules de renseignement financier, et les enquêtes conjointes avec des pays étrangers.",
    criteres: [
      { id: "39.1", text: "Des mécanismes de coopération informelle et opérationnelle sont en place entre les autorités de contrôle.", fondamental: true },
      { id: "39.2", text: "La CRF coopère efficacement avec ses homologues étrangers.", fondamental: true },
      { id: "39.3", text: "Des enquêtes conjointes avec des pays étrangers sont menées lorsque cela est approprié.", fondamental: false },
    ],
    notesEvaluateurs: [
      { id: "NE39.1", text: "Les évaluateurs doivent vérifier l'étendue et l'efficacité des mécanismes de coopération informelle." },
    ],
    notation: "LC",
  },
  {
    id: "R40", numero: 40, titre: "Autres résultats — Recommandation 40 (Transparence)",
    texte: "Les pays devraient veiller à ce que des informations adéquates, exactes et à jour sur les bénéficiaires effectifs des personnes morales et des constructions juridiques soient accessibles de manière rapide et fiable aux autorités compétentes. Les pays pourraient également rendre ces informations accessibles au public, sous réserve de garanties appropriées.",
    criteres: [
      { id: "40.1", text: "Des registres de bénéficiaires effectifs sont en place pour les personnes morales et les constructions juridiques.", fondamental: true },
      { id: "40.2", text: "Les informations sur les bénéficiaires effectifs sont adéquates, exactes et à jour.", fondamental: true },
      { id: "40.3", text: "Les autorités compétentes ont un accès rapide et fiable aux informations sur les bénéficiaires effectifs.", fondamental: true },
      { id: "40.4", text: "Des sanctions effectives sont prévues en cas de non-conformité aux obligations de transparence.", fondamental: true },
      { id: "40.5", text: "Les informations sur les bénéficiaires effectifs sont vérifiées par des autorités compétentes ou des tiers soumis à des obligations de vérification.", fondamental: true },
    ],
    notesEvaluateurs: [
      { id: "NE40.1", text: "Les évaluateurs doivent vérifier la qualité, l'exhaustivité et l'accessibilité des registres de bénéficiaires effectifs." },
      { id: "NE40.2", text: "L'évaluation devrait inclure la vérification de l'effectivité des sanctions en cas de non-conformité." },
    ],
    notation: "PC",
  },
];

// All 11 Immediate Results (FATF Methodology)
export const resultatsImmédiats: ResultatImmédiat[] = [
  {
    id: "RI1", numero: 1,
    titre: "Risques, politique et coordination",
    resume: "Le pays a-t-il identifié et évalué ses risques de blanchiment de capitaux, de financement du terrorisme et de prolifération, et a-t-il mis en place une politique nationale coordonnée, fondée sur ces risques, avec des orientations et des retours d'information adéquats, tout en tenant compte des défis posés par les nouvelles technologies ?",
    caracteristiques: [
      "Les risques de BC/FT/FP sont correctement identifiés, évalués et documentés, et les autorités compétentes comprennent la nature et le niveau de ces risques. L'évaluation des risques est récente, couvre tous les risques pertinents et est fondée sur des données empiriques et des informations de sources multiples (cellule de renseignement financier, services de répression, autorités de supervision, et autres autorités compétentes).",
      "L'évaluation des risques est régulièrement révisée et mise à jour pour tenir compte des risques nouveaux ou émergents, y compris ceux liés aux nouvelles technologies, aux actifs virtuels et aux évolutions de la criminalité sous-jacente.",
      "Une politique nationale coordonnée de LBC/FT/FP est en place, fondée sur les résultats de l'évaluation des risques. Cette politique définit les priorités, les objectifs et les rôles et responsabilités de chaque autorité compétente, et elle est accompagnée d'un calendrier de mise en oeuvre et de mécanismes de suivi.",
      "Des orientations adéquates sont diffusées aux entités soumises aux obligations de LBC/FT et aux autres parties prenantes, notamment sur les risques identifiés, les typologies de BC/FT et les mesures d'atténuation appropriées. Ces orientations sont régulièrement mises à jour et effectivement communiquées.",
      "Des mécanismes de retour d'information sont en place entre les autorités compétentes, les entités assujetties et les autres parties prenantes. Les autorités recueillent et analysent des données pertinentes, notamment des statistiques sur les déclarations de soupçons, les enquêtes, les poursuites et les condamnations, pour évaluer l'efficacité du dispositif national et orienter les politiques futures.",
    ],
    recommandationsPrincipales: ["R1", "R2", "R33", "R34"],
    recommandationsCertainsElements: ["R15"],
    recommandationsLiees: ["R1", "R2", "R15", "R33", "R34"],
    questionsEssentielles: [
      { id: "QE1.1", text: "Les risques de BC/FT/FP sont-ils correctement identifiés, évalués et documentés ?" },
      { id: "QE1.2", text: "Une politique nationale coordonnée de LBC/FT est-elle en place et fondée sur les risques ?" },
      { id: "QE1.3", text: "Les orientations et les retours d'information sont-ils adéquats et effectivement communiqués ?" },
      { id: "QE1.4", text: "Les statistiques sont-elles compilées et utilisées de manière adéquate ?" },
    ],
    exemplesInformations: [
      "Rapport d'évaluation des risques nationaux",
      "Politique nationale de LBC/FT",
      "Statistiques LBC/FT du pays",
      "Rapports d'orientation et de retour d'information",
      "Cadre réglementaire relatif aux nouvelles technologies",
    ],
    exemplesFacteursSpecifiques: [
      "La fréquence et la qualité des mises à jour de l'évaluation des risques",
      "La mesure dans laquelle les résultats de l'ER sont communiqués aux parties prenantes",
      "L'utilisation effective des statistiques pour orienter les politiques",
      "La prise en compte des nouvelles technologies dans l'évaluation des risques",
    ],
  },
  {
    id: "RI2", numero: 2,
    titre: "Coopération internationale",
    resume: "Le pays fournit-il une entraide judiciaire, une extradition et une coopération internationale efficaces et rapides, et échange-t-il des informations avec ses homologues étrangers, y compris sur les bénéficiaires effectifs, le secret professionnel et les nouvelles technologies, afin de lutter contre les menaces transfrontalières ?",
    caracteristiques: [
      "Le pays fournit une entraide judiciaire mutuelle en matière de BC/FT/FP de manière rapide, constructive et effective. Les demandes sont traitées dans des délais raisonnables, et le pays ne refuse pas la coopération pour des motifs de secret bancaire ou fiscal. Les autorités compétentes disposent des pouvoirs et des procédures nécessaires pour exécuter les demandes d'entraide.",
      "Le pays coopère effectivement à l'extradition pour les infractions de BC/FT/FP. Les demandes d'extradition sont traitées dans des délais raisonnables, et le pays a un cadre juridique adéquat permettant l'extradition de ses propres ressortissants ou de prévoir des poursuites effectives lorsque l'extradition est refusée.",
      "La cellule de renseignement financier (CRF) échange des informations de manière rapide et effective avec ses homologues étrangers, y compris par la conclusion de mémorandums d'entente et l'utilisation de canaux de communication sécurisés. Les échanges d'informations portent sur les déclarations de soupçons, les analyses financières et les renseignements opérationnels.",
      "Le pays coopère effectivement avec les autorités étrangères pour l'identification, le repérage, le gel et la confiscation des produits du crime, y compris par la mise en oeuvre de mesures de gel sans préavis et la fourniture d'une assistance dans les procédures de confiscation transfrontalière.",
      "Les autorités compétentes coopèrent de manière informelle et directe avec leurs homologues étrangers, en dehors des canaux formels d'entraide judiciaire, pour faciliter les enquêtes en cours et l'échange d'informations opérationnelles en temps opportun.",
    ],
    recommandationsPrincipales: ["R36", "R37", "R38", "R39", "R40"],
    recommandationsCertainsElements: ["R9", "R15", "R24", "R25", "R32"],
    recommandationsLiees: ["R9", "R15", "R24", "R25", "R32", "R36", "R37", "R38", "R39", "R40"],
    questionsEssentielles: [
      { id: "QE2.1", text: "Le pays coopère-t-il rapidement et de manière constructive au niveau international ?" },
      { id: "QE2.2", text: "Les demandes d'entraide judiciaire sont-elles traitées dans des délais raisonnables ?" },
      { id: "QE2.3", text: "L'extradition est-elle effective pour les infractions de BC/FT ?" },
      { id: "QE2.4", text: "Les informations sur les bénéficiaires effectifs sont-elles échangées avec les autorités étrangères ?" },
    ],
    exemplesInformations: [
      "Statistiques sur les demandes d'entraide reçues et traitées",
      "Statistiques sur les demandes d'extradition",
      "Accords de coopération internationale",
      "Rapports d'activités de la CRF sur la coopération internationale",
    ],
    exemplesFacteursSpecifiques: [
      "Le délai moyen de traitement des demandes d'entraide",
      "Le taux de réponse aux demandes d'entraide et d'extradition",
      "La qualité et la pertinence des informations échangées",
      "L'efficacité des mécanismes de gel et de confiscation transfrontaliers",
    ],
  },
  {
    id: "RI3", numero: 3,
    titre: "Supervision des institutions financières et PSAV",
    resume: "Les institutions financières et les prestataires de services sur actifs virtuels (PSAV) sont-ils soumis à une réglementation et à une supervision efficaces, fondées sur les risques, et appliquent-ils correctement les mesures préventives (vigilance clientèle, conservation des documents, déclaration de soupçons, etc.), avec des sanctions dissuasives et une coopération entre les autorités ?",
    caracteristiques: [
      "Les autorités de supervision surveillent et s'assurent de manière effective que les institutions financières et les PSAV se conforment aux obligations de LBC/FT. La supervision est fondée sur les risques, les superviseurs disposent de pouvoirs adéquats, de ressources suffisantes et de compétences techniques appropriées pour évaluer la conformité.",
      "Les superviseurs prennent des mesures correctives appropriées lorsque les obligations ne sont pas respectées, y compris l'imposition de sanctions effectives, proportionnées et dissuasives. Les sanctions sont effectivement appliquées et publiquement communiquées lorsque cela est approprié, afin de renforcer la dissuasion.",
      "Les institutions financières et les PSAV mettent en oeuvre de manière effective les mesures préventives, y compris la diligence raisonnable de la clientèle (normale, renforcée et simplifiée), la conservation des documents, les déclarations de soupçons, les contrôles internes et la formation du personnel. Ces mesures sont adaptées au niveau de risque identifié.",
      "Les superviseurs mènent des inspections sur place et des contrôles hors site de manière régulière et fondée sur les risques. Le programme de supervision couvre l'ensemble des activités et des risques pertinents, et les résultats des inspections sont suivis de manière adéquate.",
      "Les superviseurs échangent des informations de manière effective avec les autres autorités compétentes, notamment la CRF, les services de répression et les autres superviseurs, tant au niveau national qu'international, afin de garantir une approche cohérente de la supervision LBC/FT.",
    ],
    recommandationsPrincipales: ["R9", "R10", "R11", "R12", "R13", "R14", "R15", "R16", "R17", "R18", "R19", "R20", "R21", "R26", "R27", "R34", "R35"],
    recommandationsCertainsElements: ["R1", "R29", "R40"],
    recommandationsLiees: ["R1", "R9", "R10", "R11", "R12", "R13", "R14", "R15", "R16", "R17", "R18", "R19", "R20", "R21", "R26", "R27", "R29", "R34", "R35", "R40"],
    questionsEssentielles: [
      { id: "QE3.1", text: "Les autorités de supervision ont-elles les pouvoirs et les ressources nécessaires ?" },
      { id: "QE3.2", text: "La supervision est-elle fondée sur les risques et couvre-t-elle toutes les entités ?" },
      { id: "QE3.3", text: "Les institutions financières et PSAV appliquent-ils correctement les mesures préventives ?" },
      { id: "QE3.4", text: "Des sanctions dissuasives sont-elles effectivement imposées en cas de non-conformité ?" },
    ],
    exemplesInformations: [
      "Rapports d'inspection et de supervision",
      "Statistiques sur les sanctions imposées",
      "Programmes de supervision fondés sur les risques",
      "Résultats d'inspections de la conformité LBC/FT",
    ],
    exemplesFacteursSpecifiques: [
      "La fréquence et la couverture des inspections",
      "Le nombre de sanctions imposées et leur nature",
      "Les ressources humaines et financières des autorités de supervision",
      "Le taux de conformité aux obligations de diligence raisonnable",
    ],
  },
  {
    id: "RI4", numero: 4,
    titre: "Supervision des EPNFD",
    resume: "Les entreprises et professions non financières désignées (EPNFD) — comme les avocats, notaires, comptables, agents immobiliers et marchands de métaux précieux — sont-elles soumises à une réglementation et une surveillance adéquates, fondées sur les risques, et appliquent-elles les mesures préventives (vigilance clientèle, déclaration de soupçons, etc.) avec des sanctions effectives ?",
    caracteristiques: [
      "Les autorités de supervision surveillent et s'assurent de manière effective que les EPNFD se conforment aux obligations de LBC/FT. Tous les types d'EPNFD (avocats, notaires, comptables, agents immobiliers, marchands de métaux précieux, etc.) sont couverts par un mécanisme de supervision adéquat et effectif.",
      "Les superviseurs prennent des mesures correctives appropriées lorsque les obligations ne sont pas respectées, y compris l'imposition de sanctions effectives, proportionnées et dissuasives. Le régime de sanctions est effectivement appliqué et les sanctions sont publiquement communiquées lorsque cela est approprié.",
      "Les EPNFD mettent en oeuvre de manière effective les mesures préventives, y compris la diligence raisonnable de la clientèle, la conservation des documents, les déclarations de soupçons et les contrôles internes. Les obligations professionnelles existantes sont effectivement utilisées comme base pour les obligations LBC/FT des professions juridiques et comptables.",
      "Les superviseurs mènent des inspections sur place et des contrôles hors site de manière régulière et fondée sur les risques. Le programme de supervision tient compte de la nature spécifique de chaque type d'EPNFD et des risques particuliers qui y sont associés.",
      "Les superviseurs échangent des informations de manière effective avec les autres autorités compétentes, notamment la CRF et les services de répression, afin de garantir une approche cohérente de la supervision LBC/FT des EPNFD et de détecter les cas de non-conformité.",
    ],
    recommandationsPrincipales: ["R22", "R23", "R28", "R34", "R35"],
    recommandationsCertainsElements: ["R1", "R29", "R40"],
    recommandationsLiees: ["R1", "R22", "R23", "R28", "R29", "R34", "R35", "R40"],
    questionsEssentielles: [
      { id: "QE4.1", text: "Les EPNFD sont-elles soumises à une réglementation et une supervision adéquates ?" },
      { id: "QE4.2", text: "Les EPNFD appliquent-elles correctement les mesures de vigilance clientèle ?" },
      { id: "QE4.3", text: "Les déclarations de soupçons des EPNFD sont-elles de bonne qualité ?" },
      { id: "QE4.4", text: "Des sanctions effectives sont-elles imposées aux EPNFD en cas de non-conformité ?" },
    ],
    exemplesInformations: [
      "Rapports d'inspection et de supervision des EPNFD",
      "Statistiques sur les DOS transmises par les EPNFD",
      "Programmes de supervision des EPNFD fondés sur les risques",
    ],
    exemplesFacteursSpecifiques: [
      "La couverture de la supervision des différents types d'EPNFD",
      "Le nombre de sanctions imposées aux EPNFD",
      "La qualité des déclarations de soupçons transmises par les EPNFD",
      "Les ressources allouées à la supervision des EPNFD",
    ],
  },
  {
    id: "RI5", numero: 5,
    titre: "Personnes morales et constructions juridiques",
    resume: "Le pays garantit-il la transparence des personnes morales et des constructions juridiques (trusts, fiducies) en exigeant des informations précises et actualisées sur leurs bénéficiaires effectifs, et ces informations sont-elles facilement accessibles aux autorités compétentes, y compris dans le cadre de l'entraide judiciaire internationale ?",
    caracteristiques: [
      "Des informations adéquates, exactes et à jour sur les bénéficiaires effectifs des personnes morales sont disponibles pour les autorités compétentes de manière rapide et fiable. Les obligations de déclaration des bénéficiaires effectifs sont clairement définies par la loi, et les informations sont conservées dans un registre centralisé ou par les intermédiaires désignés.",
      "Des informations adéquates, exactes et à jour sur les bénéficiaires effectifs des constructions juridiques (trusts et autres fiducies) sont disponibles pour les autorités compétentes. Les fiduciaires et autres personnes exerçant le contrôle de ces constructions sont soumis à des obligations de déclaration et de conservation d'informations.",
      "Les autorités compétentes ont des pouvoirs et des procédures adéquats pour accéder en temps opportun aux informations sur les bénéficiaires effectifs, que ces informations soient détenues par des registres publics, des autorités de supervision, des intermédiaires ou d'autres entités. L'accès comprend les situations de coopération internationale.",
      "Des mesures adéquates sont en place pour s'assurer que les informations sur les bénéficiaires effectifs sont tenues à jour et vérifiées. Cela inclut des obligations de mise à jour périodique, des mécanismes de vérification par des tiers, et des sanctions effectives en cas de non-respect des obligations de transparence.",
    ],
    recommandationsPrincipales: ["R24", "R25"],
    recommandationsCertainsElements: ["R1", "R10", "R22", "R37", "R40"],
    recommandationsLiees: ["R1", "R10", "R22", "R24", "R25", "R37", "R40"],
    questionsEssentielles: [
      { id: "QE5.1", text: "Des informations sur les bénéficiaires effectifs des personnes morales sont-elles disponibles et accessibles ?" },
      { id: "QE5.2", text: "Des informations sur les constructions juridiques sont-elles disponibles aux autorités compétentes ?" },
      { id: "QE5.3", text: "Les informations sur les bénéficiaires effectifs sont-elles vérifiées et tenues à jour ?" },
      { id: "QE5.4", text: "Des sanctions sont-elles imposées en cas de non-respect des obligations de transparence ?" },
    ],
    exemplesInformations: [
      "Cadre juridique relatif aux bénéficiaires effectifs",
      "Statistiques sur les registres de bénéficiaires effectifs",
      "Registres de trusts et constructions juridiques",
      "Exemples de coopération internationale sur les bénéficiaires effectifs",
    ],
    exemplesFacteursSpecifiques: [
      "La couverture et l'exhaustivité des registres de bénéficiaires effectifs",
      "La fiabilité et l'actualisation des informations enregistrées",
      "Les mécanismes de vérification des informations",
      "L'accessibilité des informations pour les autorités étrangères",
    ],
  },
  {
    id: "RI6", numero: 6,
    titre: "Renseignements financiers",
    resume: "La cellule de renseignements financiers (CRF) reçoit-elle, analyse-t-elle et diffuse-t-elle des renseignements financiers de qualité, exploitables par les autorités de poursuite et d'enquête, tout en bénéficiant d'une coopération nationale et internationale et en utilisant les outils technologiques appropriés ?",
    caracteristiques: [
      "La CRF fonctionne de manière efficace et indépendante, avec des ressources adéquates et un personnel qualifié. La CRF est protégée contre toute ingérence indue et dispose de l'autonomie opérationnelle nécessaire pour s'acquitter de ses fonctions de réception, d'analyse et de diffusion des renseignements financiers.",
      "La CRF reçoit, analyse et diffuse les déclarations de soupçons (et autres rapports) de manière efficace et en temps opportun. Les analyses sont fondées sur des informations complètes et pertinentes, et les résultats sont communiqués aux autorités compétentes de manière à faciliter les enquêtes et les poursuites.",
      "La CRF a un accès direct et en temps opportun aux informations financières, administratives et répressives dont elle a besoin pour s'acquitter de ses fonctions, y compris les bases de données des autorités de supervision, les registres publics et les informations provenant d'autres autorités compétentes.",
      "La CRF produit des produits d'analyse financière de haute qualité, exploitables et utiles aux autorités de répression et aux autres autorités compétentes. Les analyses de la CRF conduisent effectivement à l'ouverture d'enquêtes, de poursuites et à des actions de confiscation.",
      "La CRF coopère de manière effective avec les autorités compétentes au niveau national (services de police, parquet, autorités de supervision, autorités fiscales et douanières) et avec les CRF étrangères, par des échanges d'informations réguliers et structurés, des mémorandums d'entente et des canaux de communication sécurisés.",
    ],
    recommandationsPrincipales: ["R29", "R30", "R31", "R32"],
    recommandationsCertainsElements: ["R1", "R2", "R4", "R8", "R9", "R15", "R34", "R40"],
    recommandationsLiees: ["R1", "R2", "R4", "R8", "R9", "R15", "R29", "R30", "R31", "R32", "R34", "R40"],
    questionsEssentielles: [
      { id: "QE6.1", text: "La CRF reçoit-elle et analyse-t-elle les déclarations de soupçons de manière efficace ?" },
      { id: "QE6.2", text: "Les produits analytiques de la CRF sont-ils de bonne qualité et utilisés par les autorités ?" },
      { id: "QE6.3", text: "La CRF coopère-t-elle efficacement avec les autorités nationales et étrangères ?" },
    ],
    exemplesInformations: [
      "Statistiques de la CRF sur les DOS reçues, analysées et diffusées",
      "Rapports d'activités de la CRF",
      "Accords de coopération de la CRF avec ses homologues étrangers",
    ],
    exemplesFacteursSpecifiques: [
      "Le délai moyen d'analyse des DOS",
      "Le taux de transmission des DOS aux autorités de répression",
      "Le nombre d'enquêtes déclenchées suite à des analyses de la CRF",
      "L'utilisation d'outils technologiques par la CRF",
    ],
  },
  {
    id: "RI7", numero: 7,
    titre: "Enquêtes et poursuites BC",
    resume: "Les autorités compétentes mènent-elles des enquêtes et des poursuites efficaces pour l'infraction de blanchiment de capitaux, en disposant des pouvoirs d'investigation nécessaires (perquisitions, écoutes, accès aux documents, etc.), et coopèrent-elles au niveau national et international, y compris en matière d'extradition et d'entraide judiciaire ?",
    caracteristiques: [
      "Les autorités de répression mènent des enquêtes efficaces et proactives sur le blanchiment de capitaux, en se fondant sur les renseignements financiers de la CRF et sur toutes les autres informations disponibles. Les enquêtes sont menées de manière diligente et utilisent les pouvoirs d'investigation spéciaux (perquisitions, écoutes téléphoniques, infiltration, saisie de documents, etc.) de manière appropriée.",
      "Les enquêtes et poursuites pour blanchiment de capitaux aboutissent à des condamnations effectives de personnes physiques et morales, assorties de sanctions effectives, proportionnées et dissuasives. Le nombre de condamnations est suffisant par rapport à la taille du pays et au niveau des risques identifiés, et les peines d'emprisonnement sont effectivement appliquées.",
      "Les enquêtes ciblent les produits du crime ainsi que les acteurs criminels, dans le but de priver les criminels de leurs produits illicites. Les enquêtes portent non seulement sur les opérations de blanchiment, mais aussi sur les infractions sous-jacentes et sur les réseaux criminels impliqués.",
      "Il existe une coordination et une coopération efficaces entre toutes les autorités nationales compétentes (police, parquet, CRF, autorités de supervision, autorités fiscales et douanières) pour les enquêtes et poursuites en matière de BC. Les mécanismes de coopération opérationnelle sont formalisés et effectivement utilisés.",
    ],
    recommandationsPrincipales: ["R3", "R30", "R31"],
    recommandationsCertainsElements: ["R1", "R2", "R15", "R32", "R37", "R39", "R40"],
    recommandationsLiees: ["R1", "R2", "R3", "R15", "R30", "R31", "R32", "R37", "R39", "R40"],
    questionsEssentielles: [
      { id: "QE7.1", text: "Les autorités enquêtent-elles efficacement sur les cas de blanchiment de capitaux ?" },
      { id: "QE7.2", text: "Les poursuites aboutissent-elles à des condamnations effectives ?" },
      { id: "QE7.3", text: "Les enquêtes ciblent-elles les profits criminels et les réseaux criminels ?" },
    ],
    exemplesInformations: [
      "Statistiques sur les enquêtes, poursuites et condamnations pour BC",
      "Montant des biens confisqués",
      "Rapports d'activités des services de police spécialisés",
    ],
    exemplesFacteursSpecifiques: [
      "Le nombre d'enquêtes BC ouvertes et clôturées",
      "Le ratio condamnations/poursuites",
      "Le montant des biens confisqués par rapport aux produits du crime estimés",
      "L'utilisation de techniques d'investigation spécialisées",
    ],
  },
  {
    id: "RI8", numero: 8,
    titre: "Confiscation",
    resume: "Le pays dispose-t-il de mesures efficaces pour identifier, geler, saisir et confisquer les produits du crime et les instruments ayant servi à le commettre, y compris dans le cadre d'une approche fondée sur les risques, et ces mesures sont-elles coordonnées au niveau national et international, en particulier via l'entraide judiciaire ?",
    caracteristiques: [
      "Il existe des mesures et procédures efficaces pour identifier, repérer et geler les biens criminels aux fins de confiscation. Les autorités compétentes disposent de pouvoirs d'investigation adéquats (y compris l'accès aux informations financières, aux registres et aux bases de données) et les mesures de gel sont appliquées sans délai excessif pour empêcher le transfert ou la dissipation des biens.",
      "Le pays dispose d'un cadre juridique efficace pour la confiscation des biens criminels, comprenant la confiscation directe (y compris la confiscation en valeur), la confiscation élargie et la confiscation par équivalent. Les procédures de confiscation sont effectivement utilisées dans la pratique et les biens confisqués sont gérés de manière appropriée.",
      "Les biens criminels sont effectivement identifiés, repérés et confisqués, et les montants confisqués sont significatifs par rapport aux produits du crime estimés. Les autorités accordent une priorité appropriée à la confiscation dans le cadre des enquêtes et poursuites pénales, y compris pour les affaires de criminalité grave et organisée.",
      "Il existe des mécanismes efficaces de coopération internationale en matière de confiscation, y compris l'identification et le gel de biens à la demande de pays étrangers, l'exécution des ordres de confiscation étrangers et le partage des biens confisqués. Le pays participe activement aux réseaux de coopération internationale en matière de confiscation.",
    ],
    recommandationsPrincipales: ["R1", "R4", "R32"],
    recommandationsCertainsElements: ["R15", "R30", "R31", "R37", "R38", "R40"],
    recommandationsLiees: ["R1", "R4", "R15", "R30", "R31", "R32", "R37", "R38", "R40"],
    questionsEssentielles: [
      { id: "QE8.1", text: "Le pays dispose-t-il d'un cadre juridique adéquat pour la confiscation ?" },
      { id: "QE8.2", text: "Les mesures de gel et de saisie sont-elles effectivement appliquées ?" },
      { id: "QE8.3", text: "Les confiscations portent-elles sur des montants significatifs par rapport aux produits du crime ?" },
    ],
    exemplesInformations: [
      "Montant des biens confisqués",
      "Cadre juridique relatif à la confiscation",
      "Statistiques sur les mesures de gel et de saisie",
    ],
    exemplesFacteursSpecifiques: [
      "Le ratio entre les produits du crime estimés et les montants confisqués",
      "L'utilisation de la confiscation élargie et de la confiscation en valeur",
      "L'efficacité de la coopération internationale en matière de confiscation",
    ],
  },
  {
    id: "RI9", numero: 9,
    titre: "Enquêtes et poursuites FT",
    resume: "Les autorités compétentes mènent-elles des enquêtes et des poursuites efficaces pour l'infraction de financement du terrorisme, en perturbant les flux financiers terroristes, en utilisant les pouvoirs d'investigation adéquats et en coopérant au niveau national et international, notamment en matière d'extradition et d'entraide judiciaire ?",
    caracteristiques: [
      "Les autorités de répression mènent des enquêtes efficaces et proactives sur le financement du terrorisme, en se fondant sur les renseignements financiers de la CRF, les informations des services de renseignement et toutes les autres informations disponibles. Les enquêtes sont menées de manière diligente et utilisent les pouvoirs d'investigation spéciaux de manière appropriée.",
      "Les enquêtes et poursuites pour financement du terrorisme aboutissent à des condamnations effectives de personnes physiques et morales, assorties de sanctions effectives, proportionnées et dissuasives. Le nombre de condamnations est suffisant par rapport au niveau de la menace terroriste identifiée.",
      "Les enquêtes ciblent effectivement les réseaux de financement du terrorisme et leurs sources de financement, dans le but de perturber et de démanteler ces réseaux. Les autorités enquêtent non seulement sur les opérations de financement direct, mais aussi sur les mécanismes de collecte de fonds, les transferts transfrontaliers et les liens avec les organisations terroristes.",
      "Il existe une coordination et une coopération efficaces entre toutes les autorités nationales compétentes (services de renseignement, police, parquet, CRF, autorités de supervision) pour les enquêtes et poursuites en matière de FT, y compris pour la mise en oeuvre des résolutions du Conseil de sécurité de l'ONU relatives au gel des avoirs terroristes.",
    ],
    recommandationsPrincipales: ["R5", "R30", "R31", "R39"],
    recommandationsCertainsElements: ["R1", "R2", "R15", "R32", "R37", "R40"],
    recommandationsLiees: ["R1", "R2", "R5", "R15", "R30", "R31", "R32", "R37", "R39", "R40"],
    questionsEssentielles: [
      { id: "QE9.1", text: "Les autorités enquêtent-elles efficacement sur les cas de financement du terrorisme ?" },
      { id: "QE9.2", text: "Les mesures de gel des avoirs terroristes sont-elles effectivement mises en oeuvre ?" },
      { id: "QE9.3", text: "Les poursuites pour FT aboutissent-elles à des condamnations effectives ?" },
    ],
    exemplesInformations: [
      "Statistiques sur les enquêtes et poursuites pour FT",
      "Rapports sur la mise en oeuvre des résolutions du Conseil de sécurité",
      "Listes des personnes et entités dont les avoirs ont été gelés",
    ],
    exemplesFacteursSpecifiques: [
      "Le nombre de condamnations pour FT",
      "Le délai de mise en oeuvre des résolutions du Conseil de sécurité",
      "Le nombre de personnes et entités dont les avoirs ont été gelés",
    ],
  },
  {
    id: "RI10", numero: 10,
    titre: "Mesures préventives et sanctions FT",
    resume: "Le pays applique-t-il des sanctions financières ciblées contre les terroristes et les organisations terroristes (conformément aux résolutions de l'ONU) ainsi que des mesures préventives adaptées (notamment pour les transferts de fonds, les actifs virtuels et les organismes à but non lucratif), avec des pouvoirs d'enquête, de gel, de confiscation et une coopération internationale efficaces ?",
    caracteristiques: [
      "Le pays a désigné un éventail adéquat de personnes et entités pour le financement du terrorisme, conformément aux listes du Conseil de sécurité de l'ONU (résolutions 1267 et 1988) et aux désignations nationales fondées sur des critères clairs et objectifs. Les procédures de désignation permettent un ajout rapide aux listes lorsque de nouvelles informations sont disponibles.",
      "Les avoirs des personnes et entités désignées pour le financement du terrorisme sont effectivement et promptement gelés, sans préavis. Les mécanismes de gel couvrent tous les types d'avoirs (fonds, autres actifs financiers et ressources économiques) et les autorités compétentes disposent des pouvoirs nécessaires pour détecter, prévenir et interrompre les transactions impliquant des avoirs gelés.",
      "Le pays met en oeuvre de manière effective les sanctions financières ciblées liées au terrorisme et au financement du terrorisme, conformément aux résolutions pertinentes du Conseil de sécurité de l'ONU. Les obligations de gel et d'interdiction de mise à disposition s'appliquent à toutes les personnes physiques et morales sur le territoire du pays.",
      "Il existe une supervision et un monitoring adéquats des organismes à but non lucratif (OBNL) pour prévenir leur détournement à des fins de financement du terrorisme. Les autorités compétentes ont identifié les types d'OBNL les plus exposés au risque de FT et ont mis en place des mesures proportionnées au risque identifié.",
      "Les mesures préventives en matière de FT sont effectivement appliquées par les entités soumises aux obligations, notamment pour les transferts de fonds (y compris les transferts électroniques et les actifs virtuels), les relations de correspondance bancaire et les opérations impliquant des pays à risque élevé.",
    ],
    recommandationsPrincipales: ["R1", "R4", "R6", "R8"],
    recommandationsCertainsElements: ["R14", "R15", "R16", "R26", "R30", "R31", "R32", "R35", "R37", "R38", "R40"],
    recommandationsLiees: ["R1", "R4", "R6", "R8", "R14", "R15", "R16", "R26", "R30", "R31", "R32", "R35", "R37", "R38", "R40"],
    questionsEssentielles: [
      { id: "QE10.1", text: "Les sanctions financières ciblées sont-elles effectivement mises en oeuvre ?" },
      { id: "QE10.2", text: "Les mesures préventives FT sont-elles appliquées par les entités soumises aux obligations ?" },
      { id: "QE10.3", text: "Les OBNL sont-ils supervisés de manière adéquate pour prévenir le FT ?" },
    ],
    exemplesInformations: [
      "Statistiques sur les sanctions FT imposées",
      "Rapports sur la mise en oeuvre des résolutions de l'ONU",
      "Résultats d'inspections sur la conformité FT des entités",
    ],
    exemplesFacteursSpecifiques: [
      "Le délai de gel des avoirs après inscription sur les listes de l'ONU",
      "Le nombre d'OBNL supervisés et les résultats des inspections",
      "L'efficacité des mesures préventives FT dans les transferts de fonds",
    ],
  },
  {
    id: "RI11", numero: 11,
    titre: "Sanctions financières liées à la prolifération",
    resume: "Le pays met-il en oeuvre efficacement les sanctions financières ciblées liées à la prolifération des armes de destruction massive (conformément aux résolutions du Conseil de sécurité de l'ONU), en identifiant les entités désignées, en gelant leurs avoirs, et en appliquant une approche fondée sur les risques avec une coordination nationale et des outils technologiques appropriés ?",
    caracteristiques: [
      "Le pays a désigné des personnes et entités pour la prolifération d'armes de destruction massive conformément aux listes du Conseil de sécurité de l'ONU (résolutions 1718, 1737, 1929 et 2231), et les procédures de désignation permettent une mise à jour rapide et efficace des listes nationales pour refléter les nouvelles désignations internationales.",
      "Les avoirs des personnes et entités désignées pour la prolifération sont effectivement et promptement gelés, sans préavis. Les mécanismes de gel couvrent tous les types d'avoirs et les autorités compétentes disposent des pouvoirs nécessaires pour détecter, prévenir et interrompre les transactions impliquant des avoirs gelés, y compris les transactions impliquant des intermédiaires ou des structures juridiques complexes.",
      "Le pays met en oeuvre de manière effective les sanctions financières ciblées liées à la prolifération, conformément aux résolutions pertinentes du Conseil de sécurité de l'ONU. Les obligations de gel, d'interdiction de mise à disposition et d'interdiction des voyages s'appliquent à toutes les personnes physiques et morales sur le territoire du pays, et des procédures sont en place pour le traitement des demandes de dérogation.",
    ],
    recommandationsPrincipales: ["R7"],
    recommandationsCertainsElements: ["R1", "R2", "R15"],
    recommandationsLiees: ["R1", "R2", "R7", "R15"],
    questionsEssentielles: [
      { id: "QE11.1", text: "Les sanctions liées à la prolifération sont-elles effectivement mises en oeuvre ?" },
      { id: "QE11.2", text: "Les avoirs des entités désignées sont-ils rapidement gelés ?" },
      { id: "QE11.3", text: "Une approche fondée sur les risques est-elle appliquée aux risques de prolifération ?" },
    ],
    exemplesInformations: [
      "Rapports sur la mise en oeuvre des résolutions de prolifération de l'ONU",
      "Listes des personnes et entités désignées pour prolifération",
      "Statistiques sur les avoirs gelés liés à la prolifération",
    ],
    exemplesFacteursSpecifiques: [
      "Le délai de gel des avoirs après désignation",
      "La couverture des entités soumises aux obligations de prolifération",
      "L'utilisation d'outils technologiques pour détecter les transactions de prolifération",
    ],
  },
];

// Helper functions
export function getRecommandationById(id: string): Recommandation | undefined {
  return recommandations.find((r) => r.id === id);
}

export function getResultatImmédiatById(id: string): ResultatImmédiat | undefined {
  return resultatsImmédiats.find((r) => r.id === id);
}

export function getRecommandationsByResultat(riId: string): Recommandation[] {
  const ri = getResultatImmédiatById(riId);
  if (!ri) return [];
  return ri.recommandationsLiees
    .map((id) => getRecommandationById(id))
    .filter((r): r is Recommandation => r !== undefined);
}

export function getRecommandationsPrincipalesByResultat(riId: string): Recommandation[] {
  const ri = getResultatImmédiatById(riId);
  if (!ri) return [];
  return ri.recommandationsPrincipales
    .map((id) => getRecommandationById(id))
    .filter((r): r is Recommandation => r !== undefined);
}

export function getRecommandationsCertainsElementsByResultat(riId: string): Recommandation[] {
  const ri = getResultatImmédiatById(riId);
  if (!ri) return [];
  return ri.recommandationsCertainsElements
    .map((id) => getRecommandationById(id))
    .filter((r): r is Recommandation => r !== undefined);
}

export function getResultatsByRecommandation(recId: string): ResultatImmédiat[] {
  return resultatsImmédiats.filter((ri) => ri.recommandationsLiees.includes(recId));
}

// Notation distribution (for demonstration)
export const notationDistribution = {
  C: recommandations.filter((r) => r.notation === "C").length,
  LC: recommandations.filter((r) => r.notation === "LC").length,
  PC: recommandations.filter((r) => r.notation === "PC").length,
  NC: recommandations.filter((r) => r.notation === "NC").length,
};