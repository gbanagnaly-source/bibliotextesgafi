import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Bibliothèque Interactive GAFI — Recommandations & Résultats Immédiats",
  description: "Explorez les 40 Recommandations du GAFI et les 11 Résultats Immédiats du cadre international de lutte contre le blanchiment de capitaux et le financement du terrorisme.",
  keywords: ["GAFI", "FATF", "blanchiment de capitaux", "financement du terrorisme", "recommandations", "résultats immédiats"],
  icons: {
    icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="fr" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
