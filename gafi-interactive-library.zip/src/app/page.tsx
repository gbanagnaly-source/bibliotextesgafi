'use client';

import { useState, useCallback, useMemo, useEffect } from 'react';
import { recommandations, resultatsImmédiats, notationInfo, type Notation, getRecommandationsByResultat, getRecommandationsPrincipalesByResultat, getRecommandationsCertainsElementsByResultat } from '@/lib/gafi-data';
import { paysEvaluations, getNotationDistribution, getEfficaciteDistribution, getClassementMER, getSuiviType, efficaciteInfo, type Efficacite, type PaysEvaluation } from '@/lib/country-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from '@/components/ui/collapsible';
import {
  Select, SelectContent, SelectGroup, SelectItem, SelectLabel, SelectTrigger, SelectValue,
} from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';

import { motion, AnimatePresence } from 'framer-motion';
import {
  BookOpen, ListChecks, Target, ChevronRight, Search, Shield, AlertTriangle,
  CheckCircle2, XCircle, MinusCircle, ArrowRight, FileText, Eye,
  Globe, Scale, Building2, Users, Lock, HelpCircle, MapPin, TrendingUp, TrendingDown, Zap,
  ChevronDown, BarChart3, ChevronLeft, Home as HomeIcon, X, Plus, Check
} from 'lucide-react';
import Image from 'next/image';

// ============ NAVIGATION ============
type View = 'home' | 'reco-list' | 'reco-detail' | 'ri-list' | 'ri-detail' | 'radar';

const NAV_ITEMS: { view: View; label: string; icon: typeof FileText }[] = [
  { view: 'home', label: 'Accueil', icon: HomeIcon },
  { view: 'reco-list', label: 'Recommandations', icon: FileText },
  { view: 'ri-list', label: 'Résultats Immédiats', icon: Target },
  { view: 'radar', label: 'Comparaison', icon: BarChart3 },
];

function NavBar({ currentView, onNavigate, searchQuery, onSearchChange, selectedCountry, onCountryChange }: {
  currentView: View;
  onNavigate: (view: View) => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  selectedCountry: string;
  onCountryChange: (code: string) => void;
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const currentPays = paysEvaluations.find(p => p.code === selectedCountry);

  const handleNav = (v: View) => {
    onNavigate(v);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14 gap-3">
          <div className="flex items-center gap-2.5 shrink-0">
            <Image src="/gafi-logo.png" alt="GAFI" width={32} height={32} className="rounded object-contain" />
            <button onClick={() => handleNav('home')} className="font-bold text-base hover:opacity-80 transition-opacity hidden sm:block">
              GAFI
            </button>
          </div>
          <nav className="hidden lg:flex items-center gap-1">
            {NAV_ITEMS.map((item) => {
              const isActive = item.view === 'reco-list' ? (currentView === 'reco-list' || currentView === 'reco-detail') :
                               item.view === 'ri-list' ? (currentView === 'ri-list' || currentView === 'ri-detail') :
                               currentView === item.view;
              return (
                <Button
                  key={item.view}
                  variant={isActive ? 'secondary' : 'ghost'}
                  size="sm"
                  onClick={() => handleNav(item.view)}
                  className={`text-[14px] font-bold ${isActive ? '' : 'text-foreground hover:text-foreground'}`}
                >
                  <item.icon className="w-4 h-4 mr-1.5" />
                  {item.label}
                </Button>
              );
            })}
          </nav>
          <div className="flex items-center gap-2">
            <div className="relative hidden lg:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-9 w-48 text-[13px]"
              />
            </div>
            <Select value={selectedCountry} onValueChange={onCountryChange}>
              <SelectTrigger className="w-[180px] sm:w-[220px] h-9 text-[13px]">
                <SelectValue placeholder="Choisir un pays" />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                <SelectGroup>
                  <SelectLabel className="text-xs">Pays évalués par le GAFI</SelectLabel>
                  {paysEvaluations.map((p) => (
                    <SelectItem key={p.code} value={p.code} className="text-[13px]">
                      <span className="mr-1.5">{p.drapeau}</span>
                      {p.nom}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
            <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
            </Button>
          </div>
        </div>
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden pb-3 border-t border-border pt-2 space-y-2">
            <div className="flex flex-wrap gap-1.5">
              {NAV_ITEMS.map((item) => {
                const isActive = item.view === 'reco-list' ? (currentView === 'reco-list' || currentView === 'reco-detail') :
                                 item.view === 'ri-list' ? (currentView === 'ri-list' || currentView === 'ri-detail') :
                                 currentView === item.view;
                return (
                  <Button
                    key={item.view}
                    variant={isActive ? 'secondary' : 'outline'}
                    size="sm"
                    className="text-[13px] font-medium flex-1 min-w-0"
                    onClick={() => handleNav(item.view)}
                  >
                    <item.icon className="w-3 h-3 mr-1" />
                    {item.label}
                  </Button>
                );
              })}
            </div>
            <div className="relative">
              <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-muted-foreground" />
              <Input
                placeholder="Rechercher..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="pl-8 h-8 text-xs"
              />
            </div>
          </div>
        )}
      </div>
    </header>
  );
}

// ============ NOTATION BADGE ============
function NotationBadge({ notation }: { notation?: Notation }) {
  if (!notation) return <Badge variant="outline" className="text-xs">N/A</Badge>;
  const info = notationInfo[notation];
  return (
    <Badge className={`${info.bgClass} ${info.textClass} border-0 text-xs font-medium`}>
      {info.label}
    </Badge>
  );
}

function EfficaciteBadge({ efficacite }: { efficacite?: Efficacite }) {
  if (!efficacite) return <Badge variant="outline" className="text-xs">N/A</Badge>;
  const info = efficaciteInfo[efficacite];
  return (
    <Badge className={`${info.bgClass} ${info.textClass} border-0 text-xs font-medium`}>
      {info.label}
    </Badge>
  );
}

// ============ HOME ============
function HomePage({ onNavigate, evaluation }: { onNavigate: (view: View) => void; evaluation: PaysEvaluation }) {
  const total = recommandations.length;
  const dist = getNotationDistribution(evaluation);
  const effDist = getEfficaciteDistribution(evaluation);
  const conformScore = Math.round(((dist.C * 1 + dist.LC * 0.75 + dist.PC * 0.5 + dist.NC * 0) / total) * 100);
  const effScore = Math.round(((effDist['Élevé'] * 1 + effDist['Significatif'] * 0.75 + effDist['Modéré'] * 0.5 + effDist['Faible'] * 0.25) / 11) * 100);
  const classement = getClassementMER(evaluation);
  const suiviType = getSuiviType(conformScore, effScore);

  const notationCards = [
    { label: 'Conforme', count: dist.C, cls: 'bg-green-500', icon: CheckCircle2 },
    { label: 'Larg. Conforme', count: dist.LC, cls: 'bg-lime-500', icon: MinusCircle },
    { label: 'Part. Conforme', count: dist.PC, cls: 'bg-orange-500', icon: AlertTriangle },
    { label: 'Non Conforme', count: dist.NC, cls: 'bg-red-500', icon: XCircle },
  ];

  const effCards = [
    { label: 'Élevé', count: effDist['Élevé'], cls: 'bg-green-500', icon: Zap },
    { label: 'Significatif', count: effDist['Significatif'], cls: 'bg-lime-500', icon: CheckCircle2 },
    { label: 'Modéré', count: effDist['Modéré'], cls: 'bg-orange-500', icon: MinusCircle },
    { label: 'Faible', count: effDist['Faible'], cls: 'bg-red-500', icon: XCircle },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
    >
      {/* Country Header */}
      <section className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-6 sm:p-10 mb-8">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNmZmYiIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djItSDI0di0yaDEyem0wLTMwVjBoLTEydjRoMTJ6TTI0IDI0aDEydi0ySDI0djJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-50" />
        <div className="relative z-10">
          <div className="flex items-center gap-4 mb-3">
            <Image src="/gafi-logo.png" alt="GAFI" width={56} height={56} className="rounded-lg object-contain bg-white/10 p-1" />
            <div>
              <div className="flex items-center gap-2">
                <span className="text-3xl">{evaluation.drapeau}</span>
                <h1 className="text-2xl sm:text-3xl font-bold tracking-tight">{evaluation.nom}</h1>
              </div>
              <div className="flex items-center gap-2 text-sm text-white/60">
                <MapPin className="w-3.5 h-3.5" />
                <span>Évaluation GAFI — {evaluation.dateEvaluation}</span>
              </div>
              <div className="flex flex-wrap items-center gap-3 mt-3">
                <div className="flex items-center gap-2 bg-white/10 rounded-lg px-3 py-1.5 text-sm">
                  <span className="text-white/50 text-xs font-medium">DERNIÈRE REM</span>
                  <span className="text-white font-semibold">{evaluation.dateEvaluation}</span>
                  <span className={
                    classement === 'Largement Satisfaisant' ? 'text-emerald-400' :
                    classement === 'Satisfaisant' ? 'text-lime-400' :
                    classement === 'Partiellement Satisfaisant' ? 'text-orange-400' :
                    'text-red-400'
                  }>
                    {classement}
                  </span>
                  <span className={`text-xs px-1.5 py-0.5 rounded ${suiviType === 'Régulier' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-red-500/20 text-red-300'}`}>
                    Suivi {suiviType}
                  </span>
                </div>
                {evaluation.dateMERPrecedente && (
                  <div className="flex items-center gap-2 bg-white/5 rounded-lg px-3 py-1.5 text-sm border border-white/10">
                    <span className="text-white/40 text-xs font-medium">AVANT-DERNIÈRE REM</span>
                    <span className="text-white/70">{evaluation.dateMERPrecedente}</span>
                    {evaluation.classementMERPrecedente && (
                      <span className={
                        evaluation.classementMERPrecedente === 'Largement Satisfaisant' ? 'text-emerald-400/60' :
                        evaluation.classementMERPrecedente === 'Satisfaisant' ? 'text-lime-400/60' :
                        evaluation.classementMERPrecedente === 'Partiellement Satisfaisant' ? 'text-orange-400/60' :
                        'text-red-400/60'
                      }>
                        {evaluation.classementMERPrecedente}
                      </span>
                    )}
                  </div>
                )}
              </div>
            </div>
          </div>
          <p className="text-white/60 text-sm max-w-2xl mt-3 leading-relaxed">
            Consultez les résultats de l&apos;évaluation mutuelle du {evaluation.nom} par le GAFI, 
            incluant la conformité technique aux 40 Recommandations et l&apos;efficacité du système national de lutte 
            contre le blanchiment de capitaux et le financement du terrorisme.
          </p>
          <div className="flex flex-wrap gap-3 mt-5">
            <Button onClick={() => onNavigate('reco-list')} className="bg-white text-slate-900 hover:bg-white/90 text-sm font-semibold">
              <ListChecks className="w-4 h-4 mr-2" />
              40 Recommandations
            </Button>
            <Button variant="outline" className="border-white/40 text-white bg-white/10 hover:bg-white/20 hover:text-white text-sm font-medium" onClick={() => onNavigate('ri-list')}>
              <Target className="w-4 h-4 mr-2" />
              11 Résultats Immédiats
            </Button>
            <Button variant="outline" className="border-white/40 text-white bg-white/10 hover:bg-white/20 hover:text-white text-sm font-medium" onClick={() => onNavigate('radar')}>
              <BarChart3 className="w-4 h-4 mr-2" />
              Comparaison
            </Button>
          </div>
        </div>
      </section>

      {/* Global Scores */}
      <section className="grid sm:grid-cols-2 gap-4 mb-8">
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="bg-gradient-to-r from-slate-700 to-slate-600 h-1.5" />
            <div className="p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <Shield className="w-4 h-4 text-slate-500" />
                  Conformité Technique
                </h3>
                <span className="text-2xl font-bold">{conformScore}%</span>
              </div>
              <Progress value={conformScore} className="h-2 mb-3" />
              <p className="text-xs text-muted-foreground">
                Score pondéré basé sur les 40 Recommandations. C=100%, LC=75%, PC=50%, NC=0%.
              </p>
            </div>
          </CardContent>
        </Card>
        <Card className="overflow-hidden">
          <CardContent className="p-0">
            <div className="bg-gradient-to-r from-amber-500 to-amber-400 h-1.5" />
            <div className="p-5">
              <div className="flex items-center justify-between mb-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <TrendingUp className="w-4 h-4 text-amber-500" />
                  Efficacité
                </h3>
                <span className="text-2xl font-bold">{effScore}%</span>
              </div>
              <Progress value={effScore} className="h-2 mb-3" />
              <p className="text-xs text-muted-foreground">
                Score pondéré basé sur les 11 Résultats Immédiats. Élevé=100%, Significatif=75%, Modéré=50%, Faible=25%.
              </p>
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Notation Distribution */}
      <section className="mb-8">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <BarChart3 className="w-5 h-5" />
          Conformité Technique — Répartition des Notations
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {notationCards.map((c) => (
            <Card key={c.label} className="overflow-hidden">
              <CardContent className="p-0">
                <div className={`${c.cls} h-1.5`} />
                <div className="p-4 flex items-center gap-3">
                  <c.icon className="w-7 h-7 text-muted-foreground shrink-0" />
                  <div>
                    <div className="text-xl font-bold">{c.count}</div>
                    <div className="text-xs text-muted-foreground">{c.label}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="mt-3 flex h-6 rounded-full overflow-hidden bg-muted">
          {dist.C > 0 && <div className="bg-green-500 transition-all" style={{ width: `${(dist.C / total) * 100}%` }} title={`C: ${dist.C}`} />}
          {dist.LC > 0 && <div className="bg-lime-500 transition-all" style={{ width: `${(dist.LC / total) * 100}%` }} title={`LC: ${dist.LC}`} />}
          {dist.PC > 0 && <div className="bg-orange-500 transition-all" style={{ width: `${(dist.PC / total) * 100}%` }} title={`PC: ${dist.PC}`} />}
          {dist.NC > 0 && <div className="bg-red-500 transition-all" style={{ width: `${(dist.NC / total) * 100}%` }} title={`NC: ${dist.NC}`} />}
        </div>
        <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-green-500 inline-block" /> C {Math.round((dist.C / total) * 100)}%</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-lime-500 inline-block" /> LC {Math.round((dist.LC / total) * 100)}%</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-orange-500 inline-block" /> PC {Math.round((dist.PC / total) * 100)}%</span>
          {dist.NC > 0 && <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" /> NC {Math.round((dist.NC / total) * 100)}%</span>}
        </div>
      </section>

      {/* Effectiveness Distribution */}
      <section className="mb-8">
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <TrendingUp className="w-5 h-5" />
          Évaluation de l&apos;Efficacité — Répartition
        </h2>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
          {effCards.map((c) => (
            <Card key={c.label} className="overflow-hidden">
              <CardContent className="p-0">
                <div className={`${c.cls} h-1.5`} />
                <div className="p-4 flex items-center gap-3">
                  <c.icon className="w-7 h-7 text-muted-foreground shrink-0" />
                  <div>
                    <div className="text-xl font-bold">{c.count}</div>
                    <div className="text-xs text-muted-foreground">{c.label}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        <div className="mt-3 flex h-6 rounded-full overflow-hidden bg-muted">
          {effDist['Élevé'] > 0 && <div className="bg-green-500 transition-all" style={{ width: `${(effDist['Élevé'] / 11) * 100}%` }} title={`Élevé: ${effDist['Élevé']}`} />}
          {effDist['Significatif'] > 0 && <div className="bg-lime-500 transition-all" style={{ width: `${(effDist['Significatif'] / 11) * 100}%` }} title={`Significatif: ${effDist['Significatif']}`} />}
          {effDist['Modéré'] > 0 && <div className="bg-orange-500 transition-all" style={{ width: `${(effDist['Modéré'] / 11) * 100}%` }} title={`Modéré: ${effDist['Modéré']}`} />}
          {effDist['Faible'] > 0 && <div className="bg-red-500 transition-all" style={{ width: `${(effDist['Faible'] / 11) * 100}%` }} title={`Faible: ${effDist['Faible']}`} />}
        </div>
        <div className="flex gap-4 mt-2 text-xs text-muted-foreground flex-wrap">
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-green-500 inline-block" /> Élevé {effDist['Élevé']}</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-lime-500 inline-block" /> Significatif {effDist['Significatif']}</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-orange-500 inline-block" /> Modéré {effDist['Modéré']}</span>
          <span className="flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-full bg-red-500 inline-block" /> Faible {effDist['Faible']}</span>
        </div>
      </section>

      {/* Effectiveness Detail by RI */}
      <section className="mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="w-5 h-5" />
              Détail de l&apos;Efficacité par Résultat Immédiat
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {resultatsImmédiats.map((ri) => {
                const eff = evaluation.efficacite[ri.id];
                const info = eff ? efficaciteInfo[eff] : null;
                return (
                  <div key={ri.id} className="flex items-center gap-3 py-2 border-b border-border last:border-0">
                    <span className="font-mono text-xs font-bold text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded shrink-0">
                      {ri.id}
                    </span>
                    <span className="text-sm flex-1 truncate">{ri.titre}</span>
                    {info && (
                      <Badge className={`${info.bgClass} ${info.textClass} border-0 text-xs shrink-0`}>
                        {info.label}
                      </Badge>
                    )}
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </section>

      {/* Quick Access */}
      <section>
        <h2 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5" />
          Accès Rapide
        </h2>
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="group cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('reco-list')}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <FileText className="w-4 h-4 text-emerald-600" />
                Recommandations (R.1 - R.40)
                <ArrowRight className="w-3.5 h-3.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Consultez les 40 Recommandations avec leurs critères d&apos;évaluation, 
                notations de conformité et notes aux évaluateurs pour le {evaluation.nom}.
              </p>
            </CardContent>
          </Card>
          <Card className="group cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('ri-list')}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <Target className="w-4 h-4 text-amber-600" />
                Résultats Immédiats (RI.1 - RI.11)
                <ArrowRight className="w-3.5 h-3.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Explorez les 11 Résultats Immédiats qui mesurent l&apos;efficacité du 
                système national de LBC/FT du {evaluation.nom}.
              </p>
            </CardContent>
          </Card>
          <Card className="group cursor-pointer hover:shadow-md transition-shadow" onClick={() => onNavigate('radar')}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-purple-600" />
                Comparaison Radar
                <ArrowRight className="w-3.5 h-3.5 ml-auto opacity-0 group-hover:opacity-100 transition-opacity" />
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-xs text-muted-foreground">
                Comparez l&apos;efficacité entre plusieurs pays grâce à un graphique radar 
                basé sur les 11 Résultats Immédiats.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>
    </motion.div>
  );
}

// ============ RECOMMANDATIONS LIST ============
function RecoListComponent({ searchQuery, onSelect, evaluation }: { searchQuery: string; onSelect: (id: string) => void; evaluation: PaysEvaluation }) {
  const [filterNotation, setFilterNotation] = useState<Notation | 'all'>('all');

  const recoWithNotation = useMemo(() =>
    recommandations.map(r => ({ ...r, notation: evaluation.notations[r.id] })),
    [evaluation]
  );

  const filtered = recoWithNotation.filter((r) => {
    const matchesSearch =
      !searchQuery ||
      r.titre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.texte.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesNotation = filterNotation === 'all' || r.notation === filterNotation;
    return matchesSearch && matchesNotation;
  });

  const dist = getNotationDistribution(evaluation);
  const filterOptions: { label: string; value: Notation | 'all' }[] = [
    { label: 'Toutes', value: 'all' },
    { label: 'Conforme', value: 'C' },
    { label: 'Largement Conforme', value: 'LC' },
    { label: 'Partiellement Conforme', value: 'PC' },
    { label: 'Non Conforme', value: 'NC' },
  ];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold">Recommandations</h1>
          <p className="text-sm text-muted-foreground">
            {evaluation.drapeau} {evaluation.nom} — R.1 à R.40
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {filterOptions.map((opt) => (
            <Button
              key={opt.value}
              variant={filterNotation === opt.value ? 'default' : 'outline'}
              size="sm"
              className="text-xs h-7"
              onClick={() => setFilterNotation(opt.value)}
            >
              {opt.label}
              {opt.value !== 'all' && (
                <span className="ml-1 opacity-60">({dist[opt.value as Notation]})</span>
              )}
            </Button>
          ))}
        </div>
      </div>

      <div className="grid gap-3">
        <AnimatePresence mode="popLayout">
          {filtered.map((r) => (
            <motion.div
              key={r.id}
              layout
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
              <Card
                className="cursor-pointer hover:shadow-md transition-all hover:border-primary/30 group"
                onClick={() => onSelect(r.id)}
              >
                <CardContent className="p-4 sm:p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="text-xs font-mono font-bold text-muted-foreground bg-muted px-2 py-0.5 rounded">
                          {r.id}
                        </span>
                        <NotationBadge notation={r.notation} />
                        <span className="text-xs text-muted-foreground">
                          {r.criteres.length} critères
                        </span>
                      </div>
                      <h3 className="font-medium text-sm leading-snug line-clamp-2 group-hover:text-primary transition-colors">
                        {r.titre}
                      </h3>
                    </div>
                    <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0 mt-1 group-hover:text-primary transition-colors" />
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Search className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p>Aucune recommandation trouvée</p>
        </div>
      )}
    </motion.div>
  );
}

// ============ RECOMMANDATION DETAIL ============
function RecoDetailComponent({ recoId, onNavigate, onBack, evaluation }: { recoId: string; onNavigate: (view: View) => void; onBack: () => void; evaluation: PaysEvaluation }) {
  const reco = recommandations.find((r) => r.id === recoId);
  const [showNotes, setShowNotes] = useState(false);
  const linkedRIs = reco ? resultatsImmédiats.filter((ri) => ri.recommandationsLiees.includes(reco.id)) : [];
  const countryNotation = evaluation.notations[recoId];

  if (!reco) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Recommandation non trouvée</p>
        <Button variant="outline" className="mt-4" onClick={onBack}>Retour</Button>
      </div>
    );
  }

  const info = countryNotation ? notationInfo[countryNotation] : null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        <button onClick={onBack} className="hover:text-foreground transition-colors">Recommandations</button>
        <ChevronRight className="w-4 h-4" />
        <span className="text-foreground font-medium">{reco.id}</span>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2 flex-wrap">
            <span className="text-lg font-mono font-bold text-primary">{reco.id}</span>
            <NotationBadge notation={countryNotation} />
            <span className="text-xs text-muted-foreground">{evaluation.drapeau} {evaluation.nom}</span>
            {evaluation.dateEvaluation && (
              <Badge variant="outline" className="text-[11px] font-normal px-2 py-0">
                Éval. {evaluation.dateEvaluation.substring(0, 4)}
              </Badge>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-bold leading-tight">{reco.titre}</h1>
        </div>
        {info && (
          <div className={`${info.bgClass} rounded-xl p-4 shrink-0 min-w-[160px]`}>
            <div className="text-2xl font-bold mb-1" style={{ color: info.color }}>{info.label}</div>
            <div className={`text-xs ${info.textClass}`}>{info.description}</div>
          </div>
        )}
      </div>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <BookOpen className="w-4 h-4" />
            Texte de la Recommandation
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm leading-relaxed text-muted-foreground">{reco.texte}</p>
        </CardContent>
      </Card>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ListChecks className="w-4 h-4" />
            Critères d&apos;évaluation ({reco.criteres.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="multiple" className="w-full">
            {reco.criteres.map((c) => (
              <AccordionItem key={c.id} value={c.id}>
                <AccordionTrigger className="text-sm hover:no-underline py-3">
                  <div className="flex items-center gap-3 text-left">
                    <span className="font-mono font-bold text-xs text-primary bg-primary/10 px-2 py-0.5 rounded shrink-0">
                      {c.id}
                    </span>
                    {c.fondamental && (
                      <Badge variant="secondary" className="text-xs shrink-0">Fondamental</Badge>
                    )}
                    <span className="line-clamp-2">{c.text}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-sm text-muted-foreground leading-relaxed pb-4">
                  {c.text}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>

      <Collapsible open={showNotes} onOpenChange={setShowNotes}>
        <Card className="mb-6">
          <CollapsibleTrigger asChild>
            <CardHeader className="cursor-pointer hover:bg-muted/50 transition-colors rounded-t-xl">
              <CardTitle className="text-base flex items-center gap-2">
                <Eye className="w-4 h-4" />
                Notes aux évaluateurs ({reco.notesEvaluateurs.length})
                {showNotes
                  ? <ChevronDown className="w-4 h-4 ml-auto text-muted-foreground" />
                  : <ChevronDown className="w-4 h-4 ml-auto text-muted-foreground -rotate-90" />
                }
              </CardTitle>
            </CardHeader>
          </CollapsibleTrigger>
          <CollapsibleContent>
            <CardContent className="pt-0 space-y-3">
              {reco.notesEvaluateurs.map((n) => (
                <div key={n.id} className="bg-muted/50 rounded-lg p-4">
                  <span className="text-xs font-mono font-bold text-muted-foreground">{n.id}</span>
                  <p className="text-sm text-muted-foreground mt-1 leading-relaxed">{n.text}</p>
                </div>
              ))}
            </CardContent>
          </CollapsibleContent>
        </Card>
      </Collapsible>

      {linkedRIs.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-base flex items-center gap-2">
              <Target className="w-4 h-4" />
              Résultats Immédiats liés
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {linkedRIs.map((ri) => {
                const eff = evaluation.efficacite[ri.id];
                return (
                  <button
                    key={ri.id}
                    className="flex items-center gap-3 p-3 rounded-lg hover:bg-muted transition-colors text-left group"
                    onClick={() => onNavigate('ri-detail')}
                  >
                    <span className="font-mono font-bold text-xs text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded shrink-0">
                      {ri.id}
                    </span>
                    <span className="text-sm flex-1 truncate">{ri.titre}</span>
                    <EfficaciteBadge efficacite={eff} />
                    <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0 group-hover:text-amber-500 transition-colors" />
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}
    </motion.div>
  );
}

// ============ RÉSULTATS IMMÉDIATS LIST ============
function RIListComponent({ searchQuery, onSelect, evaluation }: { searchQuery: string; onSelect: (id: string) => void; evaluation: PaysEvaluation }) {
  const filtered = resultatsImmédiats.filter((ri) => {
    if (!searchQuery) return true;
    return (
      ri.titre.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ri.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ri.id.toLowerCase().includes(searchQuery.toLowerCase())
    );
  });

  const riIcons = [Scale, Globe, Shield, Lock, Users, Building2, FileText, Eye, Search, CheckCircle2, AlertTriangle];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Résultats Immédiats</h1>
        <p className="text-sm text-muted-foreground">
          {evaluation.drapeau} {evaluation.nom} — Évaluation de l&apos;efficacité (RI.1 à RI.11)
        </p>
      </div>

      <div className="grid gap-3">
        <AnimatePresence mode="popLayout">
          {filtered.map((ri, idx) => {
            const Icon = riIcons[idx % riIcons.length];
            const linkedRecos = getRecommandationsByResultat(ri.id);
            const eff = evaluation.efficacite[ri.id];
            return (
              <motion.div
                key={ri.id}
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.15 }}
              >
                <Card
                  className="cursor-pointer hover:shadow-md transition-all hover:border-amber-300 group"
                  onClick={() => onSelect(ri.id)}
                >
                  <CardContent className="p-4 sm:p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                          <span className="text-xs font-mono font-bold text-amber-600 bg-amber-50 dark:bg-amber-900/20 px-2 py-0.5 rounded">
                            {ri.id}
                          </span>
                          <EfficaciteBadge efficacite={eff} />
                          <span className="text-xs text-muted-foreground">
                            {linkedRecos.length} reco. liée{linkedRecos.length > 1 ? 's' : ''}
                          </span>
                        </div>
                        <h3 className="font-medium text-sm leading-snug group-hover:text-amber-600 transition-colors flex items-center gap-2">
                          <Icon className="w-4 h-4 shrink-0 text-amber-500" />
                          {ri.titre}
                        </h3>
                      </div>
                      <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0 mt-1 group-hover:text-amber-500 transition-colors" />
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12 text-muted-foreground">
          <Search className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p>Aucun résultat immédiat trouvé</p>
        </div>
      )}
    </motion.div>
  );
}

// ============ RÉSULTAT IMMÉDIAT DETAIL ============
function RIDetailComponent({ riId, onNavigate, onBack, evaluation }: { riId: string; onNavigate: (view: View, recoId?: string) => void; onBack: () => void; evaluation: PaysEvaluation }) {
  const ri = resultatsImmédiats.find((r) => r.id === riId);

  if (!ri) {
    return (
      <div className="text-center py-12">
        <p className="text-muted-foreground">Résultat Immédiat non trouvé</p>
        <Button variant="outline" className="mt-4" onClick={onBack}>Retour</Button>
      </div>
    );
  }

  const linkedRecos = getRecommandationsByResultat(ri.id);
  const recoPrincipales = getRecommandationsPrincipalesByResultat(ri.id);
  const recoCertainsElements = getRecommandationsCertainsElementsByResultat(ri.id);
  const eff = evaluation.efficacite[riId];
  const effInfo = eff ? efficaciteInfo[eff] : null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="flex items-center gap-2 text-sm text-muted-foreground mb-6">
        <button onClick={onBack} className="hover:text-foreground transition-colors">Résultats Immédiats</button>
        <ChevronRight className="w-4 h-4" />
        <span className="text-foreground font-medium">{ri.id}</span>
      </div>

      <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-6">
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-2 flex-wrap">
            <span className="text-lg font-mono font-bold text-amber-600">{ri.id}</span>
            <Badge variant="secondary" className="bg-amber-50 text-amber-700 dark:bg-amber-900/20 dark:text-amber-400">
              Résultat Immédiat
            </Badge>
            <span className="text-xs text-muted-foreground">{evaluation.drapeau} {evaluation.nom}</span>
            {evaluation.dateEvaluation && (
              <Badge variant="outline" className="text-[11px] font-normal px-2 py-0">
                Éval. {evaluation.dateEvaluation.substring(0, 4)}
              </Badge>
            )}
          </div>
          <h1 className="text-xl sm:text-2xl font-bold leading-tight">{ri.titre}</h1>
        </div>
        {effInfo && (
          <div className={`${effInfo.bgClass} rounded-xl p-4 shrink-0 min-w-[160px]`}>
            <div className="text-xl font-bold mb-1" style={{ color: effInfo.color }}>{effInfo.label}</div>
            <div className={`text-xs ${effInfo.textClass}`}>{effInfo.description}</div>
          </div>
        )}
      </div>

      {/* 1. Description */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <FileText className="w-4 h-4" />
            Description
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm leading-relaxed text-muted-foreground">{ri.resume}</p>
        </CardContent>
      </Card>

      {/* 2. Caractéristiques d'un système efficace */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Target className="w-4 h-4" />
            Caractéristiques d&apos;un système efficace
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="space-y-4">
            {ri.caracteristiques.map((c, i) => (
              <li key={i} className="flex items-start gap-3">
                <span className="font-mono text-xs font-bold text-primary bg-primary/10 px-2 py-0.5 rounded mt-0.5 shrink-0">
                  {i + 1}
                </span>
                <p className="text-sm leading-relaxed text-muted-foreground">{c}</p>
              </li>
            ))}
          </ol>
        </CardContent>
      </Card>

      {/* 3. Questions essentielles */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <HelpCircle className="w-4 h-4" />
            Questions essentielles
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {ri.questionsEssentielles.map((q) => (
              <div key={q.id} className="flex items-start gap-3">
                <span className="font-mono text-xs text-muted-foreground bg-muted px-2 py-0.5 rounded mt-0.5 shrink-0">
                  {q.id}
                </span>
                <p className="text-sm leading-relaxed">{q.text}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* 4. Recommandations liées */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <ListChecks className="w-4 h-4" />
            Recommandations liées ({linkedRecos.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {/* 4a. Recommandations principales */}
          {recoPrincipales.length > 0 && (
            <div className="mb-4">
              <h4 className="text-sm font-semibold mb-2 text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-amber-500 shrink-0" />
                Principales ({recoPrincipales.length})
              </h4>
              <div className="grid gap-1.5">
                {recoPrincipales.map((r) => {
                  const countryN = evaluation.notations[r.id];
                  return (
                    <button
                      key={r.id}
                      className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted transition-colors text-left group"
                      onClick={() => onNavigate('reco-detail', r.id)}
                    >
                      <span className="font-mono font-bold text-xs text-primary bg-primary/10 px-2 py-0.5 rounded shrink-0">
                        {r.id}
                      </span>
                      <span className="text-sm flex-1">{r.titre}</span>
                      <NotationBadge notation={countryN} />
                      <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0 group-hover:text-primary transition-colors" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* 4b. Recommandations avec certains éléments */}
          {recoCertainsElements.length > 0 && (
            <div>
              <h4 className="text-sm font-semibold mb-2 text-blue-700 dark:text-blue-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-blue-500 shrink-0" />
                Avec certains éléments ({recoCertainsElements.length})
              </h4>
              <div className="grid gap-1.5">
                {recoCertainsElements.map((r) => {
                  const countryN = evaluation.notations[r.id];
                  return (
                    <button
                      key={r.id}
                      className="flex items-center gap-3 p-2.5 rounded-lg hover:bg-muted transition-colors text-left group"
                      onClick={() => onNavigate('reco-detail', r.id)}
                    >
                      <span className="font-mono font-bold text-xs text-primary bg-primary/10 px-2 py-0.5 rounded shrink-0">
                        {r.id}
                      </span>
                      <span className="text-sm flex-1">{r.titre}</span>
                      <NotationBadge notation={countryN} />
                      <ArrowRight className="w-4 h-4 text-muted-foreground shrink-0 group-hover:text-primary transition-colors" />
                    </button>
                  );
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* 5. Exemples d'informations */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Eye className="w-4 h-4" />
            Exemples d&apos;informations
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {ri.exemplesInformations.map((ex, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="text-primary mt-1 shrink-0">•</span>
                <span>{ex}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* 6. Exemples de facteurs spécifiques */}
      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Target className="w-4 h-4" />
            Exemples de facteurs spécifiques
          </CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {ri.exemplesFacteursSpecifiques.map((ex, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                <span className="text-primary mt-1 shrink-0">•</span>
                <span>{ex}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </motion.div>
  );
}


// ============ TEXTUAL COMPARISON ============
const COMP_COLORS = ['#3b82f6', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6', '#ec4899'];

function TextualComparisonComponent({ selectedCountry }: { selectedCountry: string }) {
  const [selectedCountries, setSelectedCountries] = useState<string[]>(() => {
    const initial = [selectedCountry];
    const second = selectedCountry !== 'FRA' ? 'FRA' : 'GBR';
    if (!initial.includes(second)) initial.push(second);
    return initial;
  });

  const [searchPays, setSearchPays] = useState('');
  const [showSelector, setShowSelector] = useState(false);
  const [hoveredRI, setHoveredRI] = useState<string | null>(null);

  const riLabels = useMemo(() => resultatsImmédiats.map(ri => ({ id: ri.id, numero: ri.numero, titre: ri.titre })), []);

  const toggleCountry = useCallback((code: string) => {
    setSelectedCountries(prev => {
      if (prev.includes(code)) {
        if (prev.length <= 1) return prev;
        return prev.filter(c => c !== code);
      }
      if (prev.length >= 6) return prev;
      return [...prev, code];
    });
  }, []);

  const removeCountry = useCallback((code: string) => {
    setSelectedCountries(prev => {
      if (prev.length <= 1) return prev;
      return prev.filter(c => c !== code);
    });
  }, []);

  const filteredPays = useMemo(() => {
    if (!searchPays) return paysEvaluations.slice(0, 30);
    const q = searchPays.toLowerCase();
    return paysEvaluations.filter(p => p.nom.toLowerCase().includes(q) || p.code.toLowerCase().includes(q));
  }, [searchPays]);

  const effOrder: Record<Efficacite, number> = { 'Élevé': 4, 'Significatif': 3, 'Modéré': 2, 'Faible': 1 };

  // Compute global scores per country
  const globalScores = useMemo(() => {
    const scores: Record<string, number> = {};
    selectedCountries.forEach(code => {
      const pays = paysEvaluations.find(p => p.code === code);
      if (!pays) { scores[code] = 0; return; }
      const effs = riLabels.map(ri => pays.efficacite[ri.id]).filter(Boolean) as Efficacite[];
      const avg = effs.length > 0 ? effs.reduce((sum, e) => sum + (effOrder[e] || 0), 0) / effs.length : 0;
      scores[code] = Math.round((avg / 4) * 100);
    });
    return scores;
  }, [selectedCountries, riLabels, effOrder]);

  // Radar chart helpers
  const radarSize = 380;
  const center = radarSize / 2;
  const maxRadius = 140;
  const levels = 4;
  const effScoreMap: Record<Efficacite, number> = { 'Élevé': 100, 'Significatif': 75, 'Modéré': 50, 'Faible': 25 };

  const getPoint = (index: number, value: number) => {
    const angle = (2 * Math.PI * index / riLabels.length) - Math.PI / 2;
    const r = (value / 100) * maxRadius;
    return { x: center + r * Math.cos(angle), y: center + r * Math.sin(angle) };
  };

  const getPolygonPoints = (countryCode: string) => {
    const pays = paysEvaluations.find(p => p.code === countryCode);
    if (!pays) return '';
    return riLabels.map((ri, i) => {
      const eff = pays.efficacite[ri.id];
      const score = eff ? effScoreMap[eff] : 0;
      const pt = getPoint(i, score);
      return `${pt.x},${pt.y}`;
    }).join(' ');
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.3 }}>
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Comparaison des profils d&apos;efficacité</h1>
        <p className="text-sm text-muted-foreground">
          Comparez les évaluations d&apos;efficacité par Résultat Immédiat entre pays
        </p>
      </div>

      {/* Country Tabs */}
      <div className="flex flex-wrap items-center gap-2 mb-6">
        {selectedCountries.map((code, idx) => {
          const pays = paysEvaluations.find(p => p.code === code);
          if (!pays) return null;
          const color = COMP_COLORS[idx % COMP_COLORS.length];
          return (
            <div
              key={code}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-full border-2 text-sm font-medium"
              style={{ borderColor: color, backgroundColor: `${color}15`, color }}
            >
              <span>{pays.drapeau}</span>
              <span className="font-bold">{pays.code}</span>
              <span className="text-xs opacity-80">{pays.nom}</span>
              {pays.dateEvaluation && (
                <span className="text-[10px] opacity-60 ml-1">({pays.dateEvaluation.substring(0, 4)})</span>
              )}
              {selectedCountries.length > 1 && (
                <button
                  onClick={() => removeCountry(code)}
                  className="ml-1 opacity-60 hover:opacity-100 transition-opacity"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              )}
            </div>
          );
        })}
        {selectedCountries.length < 6 && (
          <button
            onClick={() => setShowSelector(!showSelector)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-full border border-dashed border-muted-foreground/40 text-sm text-muted-foreground hover:border-primary hover:text-primary transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            Ajouter un pays
          </button>
        )}
      </div>

      {/* Country Selector Dropdown */}
      {showSelector && (
        <Card className="mb-6">
          <CardContent className="pt-4 pb-4">
            <div className="relative mb-3">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher un pays..."
                value={searchPays}
                onChange={(e) => setSearchPays(e.target.value)}
                className="pl-9"
              />
            </div>
            <div className="max-h-[240px] overflow-y-auto space-y-0.5">
              {filteredPays.map(p => {
                const isSelected = selectedCountries.includes(p.code);
                return (
                  <button
                    key={p.code}
                    onClick={() => { toggleCountry(p.code); setShowSelector(false); setSearchPays(''); }}
                    className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-left text-sm transition-colors ${
                      isSelected
                        ? 'bg-primary/10 text-primary'
                        : 'hover:bg-muted'
                    }`}
                  >
                    <span>{p.drapeau}</span>
                    <span className="font-medium">{p.nom}</span>
                    <span className="text-xs text-muted-foreground font-mono ml-auto">{p.code}</span>
                    {isSelected && <Check className="w-4 h-4 text-primary ml-1" />}
                  </button>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Score global en haut */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-6">
        {selectedCountries.map((code, idx) => {
          const pays = paysEvaluations.find(p => p.code === code);
          if (!pays) return null;
          const pct = globalScores[code] || 0;
          const color = COMP_COLORS[idx % COMP_COLORS.length];
          return (
            <Card key={code} className="relative overflow-hidden">
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-lg">{pays.drapeau}</span>
                  <span className="text-sm font-medium truncate">{pays.nom}</span>
                </div>
                <div className="flex items-baseline gap-1">
                  <span className="text-3xl font-bold font-mono" style={{ color }}>{pct}</span>
                  <span className="text-sm text-muted-foreground">%</span>
                </div>
                <div className="mt-2 w-full h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${pct}%`, backgroundColor: color }}
                  />
                </div>
              </CardContent>
              <div className="absolute top-0 left-0 w-1 h-full" style={{ backgroundColor: color }} />
            </Card>
          );
        })}
      </div>

      {/* Radar + Table grid */}
      <div className="grid lg:grid-cols-[400px_1fr] gap-6 items-start">
        {/* Interactive Radar Chart */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Radar comparatif</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="relative">
              <svg viewBox={`0 0 ${radarSize} ${radarSize}`} className="w-full">
                {/* Grid levels */}
                {Array.from({ length: levels }, (_, i) => {
                  const r = maxRadius * ((i + 1) / levels);
                  const points = riLabels.map((_, j) => {
                    const angle = (2 * Math.PI * j / riLabels.length) - Math.PI / 2;
                    return `${center + r * Math.cos(angle)},${center + r * Math.sin(angle)}`;
                  }).join(' ');
                  return (
                    <polygon key={`lv-${i}`} points={points} fill="none" stroke="hsl(var(--border))" strokeWidth="0.5" opacity={0.5} />
                  );
                })}
                {/* Axis lines */}
                {riLabels.map((_, i) => {
                  const angle = (2 * Math.PI * i / riLabels.length) - Math.PI / 2;
                  return (
                    <line key={`ax-${i}`} x1={center} y1={center}
                      x2={center + maxRadius * Math.cos(angle)} y2={center + maxRadius * Math.sin(angle)}
                      stroke="hsl(var(--border))" strokeWidth="0.5" opacity={0.3} />
                  );
                })}
                {/* Country polygons + points */}
                {selectedCountries.map((code, idx) => (
                  <g key={code}>
                    <polygon
                      points={getPolygonPoints(code)}
                      fill={COMP_COLORS[idx % COMP_COLORS.length]} fillOpacity={0.07}
                      stroke={COMP_COLORS[idx % COMP_COLORS.length]} strokeWidth={2}
                    />
                    {riLabels.map((ri, i) => {
                      const pays = paysEvaluations.find(p => p.code === code);
                      const eff = pays?.efficacite[ri.id];
                      const score = eff ? effScoreMap[eff] : 0;
                      const pt = getPoint(i, score);
                      const isHovered = hoveredRI === ri.id;
                      return (
                        <circle
                          key={`${code}-${ri.id}`}
                          cx={pt.x} cy={pt.y}
                          r={isHovered ? 5 : 3}
                          fill={COMP_COLORS[idx % COMP_COLORS.length]}
                          stroke="white" strokeWidth={1}
                          className="cursor-pointer transition-all"
                          onMouseEnter={() => setHoveredRI(ri.id)}
                          onMouseLeave={() => setHoveredRI(null)}
                        />
                      );
                    })}
                  </g>
                ))}
                {/* RI labels */}
                {riLabels.map((ri, i) => {
                  const angle = (2 * Math.PI * i / riLabels.length) - Math.PI / 2;
                  const labelR = maxRadius + 20;
                  const x = center + labelR * Math.cos(angle);
                  const y = center + labelR * Math.sin(angle);
                  const textAnchor = Math.abs(Math.cos(angle)) < 0.1 ? 'middle' : Math.cos(angle) > 0 ? 'start' : 'end';
                  const dominantBaseline = Math.abs(Math.sin(angle)) < 0.1 ? 'middle' : Math.sin(angle) > 0 ? 'hanging' : 'auto';
                  return (
                    <text key={ri.id} x={x} y={y} textAnchor={textAnchor} dominantBaseline={dominantBaseline}
                      className={`text-[9px] fill-muted-foreground font-mono font-medium transition-all ${hoveredRI === ri.id ? 'fill-foreground font-bold' : ''}`}>
                      {ri.id}
                    </text>
                  );
                })}
                {/* Level labels */}
                {Array.from({ length: levels }, (_, i) => {
                  const val = ((i + 1) / levels) * 100;
                  return (
                    <text key={`ll-${i}`} x={center + 4} y={center - (maxRadius * (i + 1) / levels) - 2}
                      className="text-[7px] fill-muted-foreground/60 font-mono">
                      {val}%
                    </text>
                  );
                })}
              </svg>
              {/* Hover tooltip on radar */}
              {hoveredRI && (
                <div className="absolute top-1 left-1 right-1 bg-popover border border-border rounded-lg px-3 py-2 shadow-lg text-xs z-10 pointer-events-none">
                  <div className="font-semibold mb-1">{hoveredRI}</div>
                  <div className="flex flex-wrap gap-2">
                    {selectedCountries.map((code, idx) => {
                      const pays = paysEvaluations.find(p => p.code === code);
                      const eff = pays?.efficacite[hoveredRI];
                      const info = eff ? efficaciteInfo[eff] : null;
                      return (
                        <span key={code} className="flex items-center gap-1">
                          <span className="w-2 h-2 rounded-full" style={{ backgroundColor: COMP_COLORS[idx % COMP_COLORS.length] }} />
                          <span style={{ color: COMP_COLORS[idx % COMP_COLORS.length] }}>{pays?.drapeau} {info?.label || 'N/A'}</span>
                        </span>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
            {/* Legend under radar */}
            <div className="mt-3 flex flex-wrap justify-center gap-3">
              {selectedCountries.map((code, idx) => {
                const pays = paysEvaluations.find(p => p.code === code);
                if (!pays) return null;
                return (
                  <div key={code} className="flex items-center gap-1.5 text-xs">
                    <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: COMP_COLORS[idx % COMP_COLORS.length] }} />
                    <span>{pays.drapeau} {pays.nom}</span>
                    <span className="text-muted-foreground font-mono">({globalScores[code]}%)</span>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>

        {/* Main Comparison Table */}
        <Card>
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-border bg-muted/30">
                    <th className="text-left py-3 px-4 font-semibold min-w-[200px] sticky left-0 bg-muted/30 z-10">
                      Résultat Immédiat
                    </th>
                    {selectedCountries.map((code, idx) => {
                      const pays = paysEvaluations.find(p => p.code === code);
                      const color = COMP_COLORS[idx % COMP_COLORS.length];
                      return (
                        <th key={code} className="text-center py-3 px-3 font-semibold min-w-[130px]" style={{ color }}>
                          <div className="flex flex-col items-center gap-0.5">
                            <span>{pays?.drapeau} {pays?.nom}</span>
                            {pays?.dateEvaluation && (
                              <span className="text-[10px] font-normal opacity-60">Éval. {pays.dateEvaluation.substring(0, 4)}</span>
                            )}
                          </div>
                        </th>
                      );
                    })}
                  </tr>
                </thead>
                <tbody>
                  {riLabels.map(ri => {
                    const rowEffs = selectedCountries.map(code => {
                      const pays = paysEvaluations.find(p => p.code === code);
                      return pays?.efficacite[ri.id] || null;
                    }).filter(Boolean) as Efficacite[];
                    const bestEff = rowEffs.length > 0 ? rowEffs.reduce((a, b) => (effOrder[a] || 0) >= (effOrder[b] || 0) ? a : b) : null;
                    const worstEff = rowEffs.length > 1 ? rowEffs.reduce((a, b) => (effOrder[a] || 0) <= (effOrder[b] || 0) ? a : b) : null;
                    const isRowHovered = hoveredRI === ri.id;

                    return (
                      <tr
                        key={ri.id}
                        className={`border-b border-border/50 transition-colors ${isRowHovered ? 'bg-primary/5' : 'hover:bg-muted/20'}`}
                        onMouseEnter={() => setHoveredRI(ri.id)}
                        onMouseLeave={() => setHoveredRI(null)}
                      >
                        <td className="py-3 px-4 sticky left-0 z-10" style={{ backgroundColor: isRowHovered ? 'hsl(var(--primary) / 0.03)' : 'hsl(var(--background))' }}>
                          <div className="flex items-center gap-2">
                            <span className="font-mono font-bold text-amber-600 text-xs">{ri.id}</span>
                            <span className="text-xs text-muted-foreground leading-tight">{ri.titre}</span>
                          </div>
                        </td>
                        {selectedCountries.map(code => {
                          const pays = paysEvaluations.find(p => p.code === code);
                          const eff = pays?.efficacite[ri.id];
                          const info = eff ? efficaciteInfo[eff] : null;
                          const isBest = eff && eff === bestEff && rowEffs.length > 1;
                          const isWorst = eff && eff === worstEff && rowEffs.length > 1 && bestEff !== worstEff;
                          return (
                            <td key={code} className="text-center py-3 px-3">
                              {info ? (
                                <div className="flex flex-col items-center gap-1">
                                  <Badge
                                    className={`${info.bgClass} ${info.textClass} border-0 text-xs px-2.5 py-0.5 ${isBest ? 'ring-2 ring-green-400/50' : ''} ${isWorst ? 'ring-2 ring-red-400/50' : ''}`}
                                  >
                                    {info.label}
                                  </Badge>
                                  {isBest && rowEffs.length > 1 && (
                                    <TrendingUp className="w-3 h-3 text-green-500" />
                                  )}
                                  {isWorst && (
                                    <TrendingDown className="w-3 h-3 text-red-500" />
                                  )}
                                </div>
                              ) : (
                                <span className="text-muted-foreground text-xs">N/A</span>
                              )}
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Legend */}
      <div className="mt-4 flex flex-wrap items-center justify-center gap-4 text-xs text-muted-foreground">
        <div className="flex items-center gap-1.5">
          <TrendingUp className="w-3.5 h-3.5 text-green-500" />
          <span>Meilleure note de la ligne</span>
        </div>
        <div className="flex items-center gap-1.5">
          <TrendingDown className="w-3.5 h-3.5 text-red-500" />
          <span>Note la plus faible de la ligne</span>
        </div>
      </div>
    </motion.div>
  );
}

// ============ MAIN APP ============
export default function Home() {
  const [view, setView] = useState<View>('home');
  const [selectedRecoId, setSelectedRecoId] = useState<string>('R1');
  const [selectedRIId, setSelectedRIId] = useState<string>('RI1');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<string>('CÔT');

  const evaluation = useMemo(
    () => paysEvaluations.find(p => p.code === selectedCountry) || paysEvaluations[0],
    [selectedCountry]
  );

  const navigateTo = useCallback((newView: View, recoId?: string) => {
    if (recoId && newView === 'reco-detail') {
      setSelectedRecoId(recoId);
    }
    setView(newView);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const selectReco = useCallback((id: string) => {
    setSelectedRecoId(id);
    setView('reco-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const selectRI = useCallback((id: string) => {
    setSelectedRIId(id);
    setView('ri-detail');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const goBack = useCallback(() => {
    setView(view === 'reco-detail' ? 'reco-list' : 'ri-list');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [view]);

  const handleCountryChange = useCallback((code: string) => {
    setSelectedCountry(code);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <NavBar
        currentView={view}
        onNavigate={navigateTo}
        searchQuery={searchQuery}
        onSearchChange={setSearchQuery}
        selectedCountry={selectedCountry}
        onCountryChange={handleCountryChange}
      />
      <main className="flex-1">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-10">
          <AnimatePresence mode="wait">
            {view === 'home' && (
              <HomePage key={`home-${selectedCountry}`} onNavigate={navigateTo} evaluation={evaluation} />
            )}
            {view === 'reco-list' && (
              <RecoListComponent key={`reco-list-${selectedCountry}`} searchQuery={searchQuery} onSelect={selectReco} evaluation={evaluation} />
            )}
            {view === 'reco-detail' && (
              <RecoDetailComponent
                key={`${selectedRecoId}-${selectedCountry}`}
                recoId={selectedRecoId}
                onNavigate={navigateTo}
                onBack={goBack}
                evaluation={evaluation}
              />
            )}
            {view === 'ri-list' && (
              <RIListComponent key={`ri-list-${selectedCountry}`} searchQuery={searchQuery} onSelect={selectRI} evaluation={evaluation} />
            )}
            {view === 'ri-detail' && (
              <RIDetailComponent
                key={`${selectedRIId}-${selectedCountry}`}
                riId={selectedRIId}
                onNavigate={navigateTo}
                onBack={goBack}
                evaluation={evaluation}
              />
            )}
            {view === 'radar' && (
              <TextualComparisonComponent key={`radar-${selectedCountry}`} selectedCountry={selectedCountry} />
            )}
          </AnimatePresence>
        </div>
      </main>
      <footer className="border-t border-border mt-auto">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <Image src="/gafi-logo.png" alt="GAFI" width={16} height={16} className="rounded" />
              <p>Bibliothèque Interactive — Recommandations du GAFI</p>
            </div>
            <p>40 Recommandations • 11 Résultats Immédiats • {paysEvaluations.length} pays</p>
          </div>
        </div>
      </footer>
    </div>
  );
}